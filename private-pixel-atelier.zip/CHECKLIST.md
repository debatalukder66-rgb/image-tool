# Move checklist (no terminal needed)

This app has **no Supabase Edge Functions**. All backend code (Runway, Enhance, account setup)
runs inside the app on your host, which keeps the secret keys. Supabase provides only the
database, sign-in and file storage.

## 1. Create the Supabase project
1. supabase.com → New project → name it, set a database password, pick a region near you → Create.
2. Project Settings → API Keys: copy the **Project URL**, the **publishable key**, and the **secret key**.

## 2. Run SETUP.sql
1. SQL Editor → New query → paste all of `SETUP.sql` → Run. You should see "Success".
2. Storage: the `generations` bucket (private) should now exist. If it doesn't, go to Storage →
   New bucket → name `generations`, Public OFF → Create, then run SETUP.sql again.

## 3. Secrets
No Edge Function secrets are needed in Supabase (there are no Edge Functions).
All secrets go on the host instead (step 7).

## 4. Edge functions
None to deploy.

## 5. Auth settings
1. Authentication → Sign In / Providers → **Allow new users to sign up: OFF**. Email: ON.
2. Authentication → Users → Add user → Create new user → your ALLOWED_EMAIL + a password,
   **Auto Confirm User: ON**.
3. Authentication → URL Configuration → Site URL: `https://<your-app-domain>`;
   Redirect URLs: add `https://<your-app-domain>/reset-password`.
   (Fill this in after step 7 when you know the domain.)

## 6. GitHub
In Lovable: Connectors → GitHub → connect and push this project to a repo.

## 7. Deploy on Cloudflare (free)
1. dash.cloudflare.com → Workers & Pages → Create → Import a repository → pick the repo.
2. Build command: `npm run build`. Deploy command: `npx wrangler deploy` (default).
3. Under build **Variables**, add (plain text):
   - `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`
4. Deploy. Then Worker → Settings → Variables and Secrets → add as **Secret**:
   - `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SERVICE_ROLE_KEY` (the secret key),
     `ALLOWED_EMAIL`, `RUNWAYML_API_SECRET`, `LOVABLE_API_KEY`
5. Deployments → Retry/redeploy so the secrets apply. Copy the `*.workers.dev` URL into step 5.3.

## 8. Setup Check
1. Sign in, then open Tools (wrench icon) → **Setup Check**.
2. Every row should be a check mark. Each red row shows a one-line fix (which secret to add, run SETUP.sql, etc.).
3. "Frontend backend address" and "Server backend address" must both show your NEW project's host.
4. Fix, redeploy if you changed secrets, then press **Run again**.

## 9. Final test
- [ ] Setup Check is all green.
- [ ] Open the site → /auth loads; sign in with your user.
- [ ] A different email can't sign in or sign up.
- [ ] Top bar shows your Runway credit balance.
- [ ] Image tab: one cheap generation succeeds and shows in the list.
- [ ] Reload: the image still shows (it's in your storage).
- [ ] Download, Favorite, Trash, Restore work.
- [ ] Usage page shows the credits.
- [ ] Enhance / Prompt Lab returns prompts (needs LOVABLE_API_KEY).
- [ ] Forgot password email arrives and the link opens /reset-password.
