import { expect, test } from "vitest";
import { ratioValuesFromError, summarizeRunwayError, tableRatio } from "@/lib/catalog";
test("parse", () => {
  const r = { error: "Validation of body failed", issues: [{ path: ["ratio"], code: "invalid_enum_value", message: "Invalid enum value", values: ["2048:880", "auto"] }] };
  expect(ratioValuesFromError(r)).toEqual(["2048:880", "auto"]);
  expect(summarizeRunwayError(400, r)).toContain("ratio: Invalid enum value — allowed: 2048:880, auto");
  expect(tableRatio("16:9", "Large")).toBe("3840:2160");
  expect(tableRatio("auto", "Small")).toBe("auto");
});
