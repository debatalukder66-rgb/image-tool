import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import MorphOrb from "@/components/ui/ai-thinking-orb-and-input";

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

function setupPhone() {
  vi.spyOn(HTMLCanvasElement.prototype, "getContext").mockReturnValue(null);
  vi.spyOn(window, "matchMedia").mockImplementation((query) => ({
    matches: query === "(pointer: coarse)", media: query, onchange: null,
    addListener: vi.fn(), removeListener: vi.fn(), addEventListener: vi.fn(),
    removeEventListener: vi.fn(), dispatchEvent: vi.fn(),
  }));
  const viewport = Object.assign(new EventTarget(), {
    width: 320, height: 568, offsetLeft: 0, offsetTop: 0,
  });
  vi.stubGlobal("visualViewport", viewport);
  return viewport;
}

describe("Prompt Lab phone layout", () => {
  it("does not automatically focus the input and open the phone keyboard", () => {
    setupPhone();
    render(<MorphOrb />);
    expect(screen.getByRole("textbox")).not.toHaveFocus();
  });

  it("fits the input to the visible viewport and updates after keyboard resizing", () => {
    const viewport = setupPhone();
    const { container } = render(<MorphOrb />);
    const root = container.querySelector<HTMLElement>(".mo-root");
    const actor = container.querySelector<HTMLElement>(".mo-actor");
    expect(root?.style.height).toBe("568px");
    expect(actor?.style.getPropertyValue("--w")).toBe("288px");
    viewport.height = 300;
    viewport.width = 280;
    viewport.offsetTop = 12;
    viewport.dispatchEvent(new Event("resize"));
    expect(root?.style.height).toBe("300px");
    expect(root?.style.top).toBe("12px");
    expect(actor?.style.getPropertyValue("--w")).toBe("248px");
  });
});