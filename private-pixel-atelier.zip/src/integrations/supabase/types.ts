export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      app_settings: {
        Row: {
          daily_credit_limit: number | null
          default_image_model: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          daily_credit_limit?: number | null
          default_image_model?: string | null
          updated_at?: string
          user_id?: string
        }
        Update: {
          daily_credit_limit?: number | null
          default_image_model?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      app_setup: {
        Row: {
          admin_created: boolean
          created_at: string
          id: number
        }
        Insert: {
          admin_created?: boolean
          created_at?: string
          id?: number
        }
        Update: {
          admin_created?: boolean
          created_at?: string
          id?: number
        }
        Relationships: []
      }
      generations: {
        Row: {
          created_at: string
          credits_estimated: number | null
          deleted_at: string | null
          endpoint: string | null
          error: string | null
          favorite: boolean
          id: string
          kind: string
          model: string | null
          output_paths: string[]
          params: Json
          project_id: string | null
          runway_task_ids: string[]
          status: string
          task_statuses: Json
          user_id: string
        }
        Insert: {
          created_at?: string
          credits_estimated?: number | null
          deleted_at?: string | null
          endpoint?: string | null
          error?: string | null
          favorite?: boolean
          id?: string
          kind: string
          model?: string | null
          output_paths?: string[]
          params?: Json
          project_id?: string | null
          runway_task_ids?: string[]
          status?: string
          task_statuses?: Json
          user_id: string
        }
        Update: {
          created_at?: string
          credits_estimated?: number | null
          deleted_at?: string | null
          endpoint?: string | null
          error?: string | null
          favorite?: boolean
          id?: string
          kind?: string
          model?: string | null
          output_paths?: string[]
          params?: Json
          project_id?: string | null
          runway_task_ids?: string[]
          status?: string
          task_statuses?: Json
          user_id?: string
        }
        Relationships: []
      }
      model_checks: {
        Row: {
          created_at: string
          credits_estimated: number | null
          details: Json
          duration_ms: number | null
          error: string | null
          generation_id: string | null
          id: string
          model: string
          quality: string | null
          ratio: string | null
          status: string
          thumbnail_path: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          credits_estimated?: number | null
          details?: Json
          duration_ms?: number | null
          error?: string | null
          generation_id?: string | null
          id?: string
          model: string
          quality?: string | null
          ratio?: string | null
          status: string
          thumbnail_path?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          credits_estimated?: number | null
          details?: Json
          duration_ms?: number | null
          error?: string | null
          generation_id?: string | null
          id?: string
          model?: string
          quality?: string | null
          ratio?: string | null
          status?: string
          thumbnail_path?: string | null
          user_id?: string
        }
        Relationships: []
      }
      model_config: {
        Row: {
          id: string
          max_outputs: number | null
          model: string
          quality: string | null
          ratios: string[]
          size: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          id?: string
          max_outputs?: number | null
          model: string
          quality?: string | null
          ratios?: string[]
          size?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          id?: string
          max_outputs?: number | null
          model?: string
          quality?: string | null
          ratios?: string[]
          size?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      projects: {
        Row: {
          color: string
          created_at: string
          id: string
          name: string
          user_id: string
        }
        Insert: {
          color?: string
          created_at?: string
          id?: string
          name: string
          user_id?: string
        }
        Update: {
          color?: string
          created_at?: string
          id?: string
          name?: string
          user_id?: string
        }
        Relationships: []
      }
      saved_prompts: {
        Row: {
          created_at: string
          id: string
          model: string | null
          prompt: string
          settings: Json
          title: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          model?: string | null
          prompt: string
          settings?: Json
          title: string
          user_id?: string
        }
        Update: {
          created_at?: string
          id?: string
          model?: string | null
          prompt?: string
          settings?: Json
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      style_presets: {
        Row: {
          created_at: string
          id: string
          name: string
          phrase: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          phrase: string
          user_id?: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          phrase?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
