import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Studio — Private AI Generation" },
      { name: "description", content: "Private image, video and audio generation studio." },
      { property: "og:title", content: "Studio — Private AI Generation" },
      { property: "og:description", content: "Private image, video and audio generation studio." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  beforeLoad: () => {
    throw redirect({ to: "/image" });
  },
});
