import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Fragment, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/studio/AppShell";
import { Panel } from "@/components/studio/ui";
import { ErrorBox, Json } from "@/components/studio/Json";
import { Button } from "@/components/ui/button";
import { useSignedUrls } from "@/lib/hooks";
import {
  baseImageConfig,
  IMAGE_MODELS,
  imageCost,
  learnedRatios,
  ratioValuesFromError,
  summarizeRunwayError,
} from "@/lib/catalog";
import { FINAL, runwayBalance, runwayCreate, runwayStatus, type Attempt } from "@/lib/runway.functions";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/model-check")({
  head: pageHead("Model Check", "Automatically test every image model end to end."),
  component: ModelCheckPage,
});

const PROMPT = "a small red apple on a white table";
const MODELS = IMAGE_MODELS.map((m) => m.id);
type Status = "Pending" | "Running" | "OK" | "Failed" | "Skipped";
type RowState = {
  status: Status;
  durationMs?: number | undefined;
  credits?: number | null;
  ratio?: string | undefined;
  quality?: string | null;
  thumb?: string | null;
  error?: string | null;
  note?: string | null;
  details?: Record<string, unknown>;
  generationId?: string | null;
};

const area = (r: string) => r.split(":").map(Number).reduce((a, b) => a * b, 1);

function cheapestRatio(model: string): string {
  const learned = learnedRatios.get(model)?.filter((r) => r !== "auto");
  if (learned?.length) return [...learned].sort((a, b) => area(a) - area(b))[0]!;
  if (model === "gen4_image" || model === "gen4_image_turbo") return "1280:720";
  return "1920:1920";
}

function estimate(model: string) {
  const v = imageCost(model, model === "gen4_image" ? "720p" : "1K", "low", 0, 1);
  return Number(v.split("–").pop()) || 0;
}

function findBalance(body: unknown): number | null {
  if (!body || typeof body !== "object") return null;
  const b = body as Record<string, unknown>;
  for (const k of ["creditBalance", "credit_balance", "credits", "balance"]) if (typeof b[k] === "number") return b[k] as number;
  return null;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function imageLoads(url: string) {
  return new Promise<boolean>((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img.naturalWidth > 0);
    img.onerror = () => resolve(false);
    img.src = url;
  });
}

function ModelCheckPage() {
  const qc = useQueryClient();
  const createFn = useServerFn(runwayCreate);
  const statusFn = useServerFn(runwayStatus);
  const balanceFn = useServerFn(runwayBalance);
  const [rows, setRows] = useState<Record<string, RowState>>(() => Object.fromEntries(MODELS.map((m) => [m, { status: "Pending" }])));
  const [selected, setSelected] = useState<Set<string>>(new Set(MODELS));
  const [open, setOpen] = useState<string | null>(null);
  const [running, setRunning] = useState(false);
  const [summary, setSummary] = useState<string | null>(null);
  const stopRef = useRef(false);

  // Load last saved result per model.
  const last = useQuery({
    queryKey: ["model-checks"],
    queryFn: async () => {
      const { data, error } = await supabase.from("model_checks").select("*").order("created_at", { ascending: false }).limit(300);
      if (error) throw new Error(error.message);
      const latest: Record<string, (typeof data)[number]> = {};
      for (const r of data) if (!latest[r.model]) latest[r.model] = r;
      return latest;
    },
  });
  useEffect(() => {
    if (!last.data) return;
    setRows((prev) => {
      const next = { ...prev };
      for (const [m, r] of Object.entries(last.data)) {
        if (next[m]?.status !== "Pending") continue;
        next[m] = {
          status: r.status as Status,
          durationMs: r.duration_ms ?? undefined,
          credits: r.credits_estimated,
          ratio: r.ratio ?? undefined,
          quality: r.quality,
          thumb: r.thumbnail_path,
          error: r.error,
          details: r.details as Record<string, unknown>,
          generationId: r.generation_id,
          note: `last run ${new Date(r.created_at).toLocaleString()}`,
        };
      }
      return next;
    });
  }, [last.data]);

  const thumbs = useSignedUrls(Object.values(rows).map((r) => r.thumb).filter(Boolean) as string[]);
  const update = (m: string, patch: Partial<RowState>) => setRows((p) => ({ ...p, [m]: { ...p[m]!, ...patch } }));

  async function checkModel(model: string, uid: string): Promise<boolean> {
    const start = Date.now();
    const cfg = baseImageConfig(model);
    const quality = cfg.qualities.length ? "low" : null;
    let ratio = cheapestRatio(model);
    const credits = estimate(model);
    const attempts: Attempt[] = [];
    const details: Record<string, unknown> = { attempts };
    let note: string | null = null;
    update(model, { status: "Running", ratio, quality, credits, error: null, note: null, thumb: null, details });

    const finish = async (status: Status, extra: Partial<RowState>) => {
      const durationMs = Date.now() - start;
      update(model, { status, durationMs, details, note, ...extra });
      const { error } = await supabase.from("model_checks").insert({
        user_id: uid, model, status, ratio, quality, duration_ms: durationMs, credits_estimated: credits,
        generation_id: extra.generationId ?? null, thumbnail_path: extra.thumb ?? null,
        error: extra.error ?? null, details: { ...details, note } as never,
      });
      if (error) toast.error(`Saving check result failed: ${error.message}`);
      return status === "OK";
    };

    const buildBody = () => {
      const b: Record<string, unknown> = { model, promptText: PROMPT, ratio };
      if (quality) b["quality"] = quality;
      return b;
    };

    let body = buildBody();
    details["request"] = body;
    let res = await createFn({ data: { kind: "image", endpoint: "text_to_image", body, count: 1, credits_estimated: credits } });
    attempts.push(...res.attempts);
    if (!res.ok) {
      const failed = [...res.attempts].reverse().find((a) => a.status >= 400);
      const values = failed?.status === 400 ? ratioValuesFromError(failed.response) : null;
      const onlyRatio = failed && (failed.response as { issues?: { path?: string[] }[] })?.issues?.every((i) => i.path?.join(".") === "ratio");
      if (values?.length && onlyRatio) {
        learnedRatios.set(model, values);
        const numeric = values.filter((v) => v !== "auto");
        ratio = numeric.length ? [...numeric].sort((a, b) => area(a) - area(b))[0]! : values[0]!;
        note = `ratio auto-fixed to ${ratio}`;
        body = buildBody();
        details["request"] = body;
        res = await createFn({ data: { kind: "image", endpoint: "text_to_image", body, count: 1, credits_estimated: credits } });
        attempts.push(...res.attempts);
      }
      if (!res.ok) {
        const f = [...res.attempts].reverse().find((a) => a.status >= 400) ?? failed;
        return finish("Failed", { error: f ? summarizeRunwayError(f.status, f.response) : res.error });
      }
    }

    const generationId = res.generation_id;
    details["task_ids"] = res.task_ids;
    update(model, { generationId, details, note });

    // Poll every 3s, up to 10 minutes.
    let gen: Awaited<ReturnType<typeof statusFn>>["generation"] | null = null;
    for (let i = 0; i < 200; i++) {
      await sleep(3000);
      try {
        const s = await statusFn({ data: { generation_id: generationId } });
        gen = s.generation;
        details["last_task_responses"] = s.raw;
        update(model, { details: { ...details } });
        if (FINAL.includes(gen.status)) break;
      } catch (e) {
        details["poll_error"] = (e as Error).message;
      }
    }
    details["final_status"] = gen?.status ?? "timeout";
    details["storage_paths"] = gen?.output_paths ?? [];
    if (!gen) return finish("Failed", { generationId, error: "No status received (polling failed or timed out)" });
    if (gen.status !== "SUCCEEDED") return finish("Failed", { generationId, error: gen.error ?? `Task ended ${gen.status}` });
    const path = gen.output_paths[0];
    if (!path) return finish("Failed", { generationId, error: "Task SUCCEEDED but no file was saved to storage" });

    const { data: rowCheck, error: rowErr } = await supabase.from("generations").select("id").eq("id", generationId).maybeSingle();
    if (rowErr || !rowCheck) return finish("Failed", { generationId, error: `Generation row missing: ${rowErr?.message ?? "not found"}` });

    const { data: signed, error: sErr } = await supabase.storage.from("generations").createSignedUrl(path, 3600);
    if (sErr || !signed) return finish("Failed", { generationId, error: `Signed URL failed: ${sErr?.message}` });
    if (!(await imageLoads(signed.signedUrl))) return finish("Failed", { generationId, thumb: path, error: "Stored file did not load in the browser" });

    const { error: cfgErr } = await supabase.from("model_config").upsert(
      { user_id: uid, model, ratios: [ratio], quality, size: null, max_outputs: null, updated_at: new Date().toISOString() },
      { onConflict: "user_id,model" },
    );
    if (cfgErr) toast.error(`Saving working settings failed: ${cfgErr.message}`);
    return finish("OK", { generationId, thumb: path, error: null });
  }

  async function run(models: string[]) {
    if (!models.length) { toast.error("Nothing selected"); return; }
    const total = models.reduce((a, m) => a + estimate(m), 0);
    if (!confirm(`This will spend roughly ${total} credits (${models.length} model${models.length > 1 ? "s" : ""}). Continue?`)) return;
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) { toast.error("Not signed in"); return; }
    stopRef.current = false;
    setRunning(true);
    setSummary(null);
    const before = findBalance((await balanceFn().catch(() => null))?.body);
    for (const m of models) update(m, { status: "Pending", note: null, error: null });
    let ok = 0;
    const failures: string[] = [];
    for (const m of models) {
      if (stopRef.current) { update(m, { status: "Skipped" }); continue; }
      try {
        if (await checkModel(m, u.user.id)) ok++;
        else failures.push(m);
      } catch (e) {
        failures.push(m);
        update(m, { status: "Failed", error: (e as Error).message });
      }
    }
    const after = findBalance((await balanceFn().catch(() => null))?.body);
    const used = before !== null && after !== null ? `${before - after} credits used (balance ${before} → ${after})` : `estimated ${total} credits (balance not readable)`;
    setSummary(`${ok}/${models.length} OK. ${failures.length ? `Failed: ${failures.join(", ")}.` : ""} ${used}`);
    setRunning(false);
    qc.invalidateQueries({ queryKey: ["model-checks"] });
    qc.invalidateQueries({ queryKey: ["model-config"] });
    qc.invalidateQueries({ queryKey: ["balance"] });
    qc.invalidateQueries({ queryKey: ["library"] });
  }

  const selectedTotal = [...selected].reduce((a, m) => a + estimate(m), 0);
  const failed = MODELS.filter((m) => rows[m]?.status === "Failed");

  return (
    <AppShell>
      <Panel className="mb-4 space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <h1 className="mr-2 text-lg font-semibold">Model Check</h1>
          <Button disabled={running} onClick={() => run(MODELS)}>Run all</Button>
          <Button variant="secondary" disabled={running} onClick={() => run(MODELS.filter((m) => selected.has(m)))}>Run selected</Button>
          <Button variant="secondary" disabled={running || !failed.length} onClick={() => run(failed)}>Retry failed ({failed.length})</Button>
          <Button variant="destructive" disabled={!running} onClick={() => { stopRef.current = true; toast.info("Will stop after the current model"); }}>Stop</Button>
          <Button
            variant="ghost"
            onClick={() => { localStorage.setItem("applyProvenConfig", "1"); toast.success("Image tab will now use only proven ratios where available"); }}
          >
            Apply working settings to Image tab
          </Button>
          <span className="ml-auto font-mono text-sm text-muted-foreground">selected ≈ {selectedTotal} credits</span>
        </div>
        <p className="text-xs text-muted-foreground">
          Prompt "{PROMPT}", 1 output, lowest quality, smallest known ratio, no references. Models run one at a time. A model counts as OK only if the task succeeded, the file is in storage, the row exists and the image loads.
        </p>
        {summary && <div className="rounded-md border bg-muted p-3 text-sm">{summary}</div>}
        {last.error && <ErrorBox>{(last.error as Error).message}</ErrorBox>}
      </Panel>

      <div className="overflow-x-auto rounded-xl border bg-card">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted-foreground">
            <tr className="border-b">
              <th className="p-2"><input type="checkbox" checked={selected.size === MODELS.length} onChange={(e) => setSelected(e.target.checked ? new Set(MODELS) : new Set())} /></th>
              <th className="p-2">Model</th><th className="p-2">Status</th><th className="p-2">Time</th><th className="p-2">Credits</th>
              <th className="p-2">Ratio</th><th className="p-2">Result</th><th className="p-2">Error</th><th className="p-2" />
            </tr>
          </thead>
          <tbody>
            {MODELS.map((m) => {
              const r = rows[m]!;
              const tone = r.status === "OK" ? "rounded-full bg-info/10 px-2 py-0.5 font-sans font-medium text-info" : r.status === "Failed" ? "rounded-full bg-destructive/10 px-2 py-0.5 font-sans font-medium text-destructive" : r.status === "Running" ? "rounded-full bg-warning/15 px-2 py-0.5 font-sans font-medium text-warning" : "text-muted-foreground";
              const url = r.thumb ? thumbs.data?.[r.thumb] : null;
              return (
                <Fragment key={m}>
                  <tr className="border-b align-top">
                    <td className="p-2">
                      <input type="checkbox" checked={selected.has(m)} onChange={(e) => {
                        const s = new Set(selected); if (e.target.checked) s.add(m); else s.delete(m); setSelected(s);
                      }} />
                    </td>
                    <td className="p-2 font-mono text-xs">{m}</td>
                    <td className="p-2 font-mono text-xs"><span className={`inline-block ${tone}`}>{r.status}</span>{r.note && <div className="text-muted-foreground">{r.note}</div>}</td>
                    <td className="p-2 font-mono text-xs">{r.durationMs ? `${(r.durationMs / 1000).toFixed(1)}s` : "—"}</td>
                    <td className="p-2 font-mono text-xs">{r.credits ?? estimate(m)}</td>
                    <td className="p-2 font-mono text-xs">{r.ratio ?? cheapestRatio(m)}</td>
                    <td className="p-2">{url ? <img src={url} alt={m} className="h-14 w-14 rounded object-cover" /> : "—"}</td>
                    <td className="max-w-xs whitespace-pre-wrap break-words p-2 text-xs text-destructive">{r.error}</td>
                    <td className="space-x-1 whitespace-nowrap p-2">
                      <Button size="sm" variant="ghost" disabled={running} onClick={() => run([m])}>Run</Button>
                      <Button size="sm" variant="ghost" onClick={() => setOpen(open === m ? null : m)}>Details</Button>
                    </td>
                  </tr>
                  {open === m && (
                    <tr className="border-b">
                      <td colSpan={9} className="p-2">
                        <Json value={{ generation_id: r.generationId, ...(r.details ?? {}) }} />
                      </td>
                    </tr>
                  )}
                </Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
