import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/studio/AppShell";
import { Panel } from "@/components/studio/ui";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/later")({
  head: pageHead("Coming later", "Planned tools for a later phase."),
  component: () => (
    <AppShell>
      <div className="grid gap-4 md:grid-cols-3">
        {["Video to video (aleph2)", "Image upscale", "Video upscale", "Lip sync / Act Two", "Voice dubbing", "Characters"].map((t) => (
          <Panel key={t} className="opacity-60">
            <h3 className="font-medium">{t}</h3>
            <p className="text-sm text-muted-foreground">Coming in a later phase.</p>
          </Panel>
        ))}
      </div>
    </AppShell>
  ),
});
