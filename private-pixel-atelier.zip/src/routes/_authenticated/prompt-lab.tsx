import { createFileRoute, Link } from "@tanstack/react-router";
import { X } from "lucide-react";
import MorphOrb from "@/components/ui/ai-thinking-orb-and-input";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/prompt-lab")({
  head: pageHead("Prompt Lab", "Turn a rough idea into a polished prompt with the thinking orb."),
  component: PromptLab,
});

const COPY = {
  placeholder: "Describe your idea...",
  labels: ["Reading your idea", "Adding style", "Adding lighting", "Composing"],
  done: "Ready",
  answerTitle: "Enhanced prompt",
  reset: "New idea",
};

// Step 1: fake answer after 3 seconds. The real Enhance function gets connected later.
const fakeSubmit = () =>
  new Promise<string>((res) => setTimeout(() => res("Prompt ready - your detailed prompt will appear here"), 3000));

function PromptLab() {
  return (
    <div className="fixed inset-0 z-[100]">
      <MorphOrb copy={COPY} maxLength={600} minThinkMs={1500} onSubmit={fakeSubmit} />
      <Link
        to="/image"
        aria-label="Close Prompt Lab"
        className="fixed right-4 top-4 z-[101] grid size-10 place-items-center rounded-full border border-white/15 bg-white/10 text-white/80 backdrop-blur transition hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60"
      >
        <X className="size-5" />
      </Link>
    </div>
  );
}
