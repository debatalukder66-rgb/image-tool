import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowUp, AudioLines, Image as ImageIcon, Paperclip, SlidersHorizontal, Video, Wand2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/studio/AppShell";
import { Field, NativeSelect, Segmented, StarLogo } from "@/components/studio/ui";
import { GenerationResult } from "@/components/studio/GenerationResult";
import { ErrorBox, Json } from "@/components/studio/Json";
import { useCreate } from "@/components/studio/useCreate";
import { PromptHelper } from "@/components/studio/PromptHelper";
import { combinePrompt, PromptsPopover, StylesPopover, type Style } from "@/components/studio/PromptTools";
import { CompareDialog } from "@/components/studio/CompareDialog";
import { Columns2 } from "lucide-react";
import { Workspace, type GenRow } from "@/components/studio/Workspace";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { useGenerationPoll } from "@/lib/hooks";
import { FINAL } from "@/lib/runway.functions";
import {
  baseImageConfig,
  IMAGE_MODELS,
  imageCost,
  isGpt,
  learnedRatios,
  ratioValuesFromError,
  SIZE_LABELS,
  SIZE_TIERS,
  summarizeRunwayError,
  TABLE_ASPECTS,
  tableRatio,
  tierToRes,
  type SizeTier,
} from "@/lib/catalog";
import { handoff } from "@/lib/image-utils";
import { GlobalDropOverlay, ImageTray, useDropZone, useImageInput, usePasteImages } from "@/components/studio/ImageInput";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/image")({
  head: pageHead("Image", "Generate images with reference tags."),
  component: ImagePage,
});


const pill =
  "inline-flex h-9 items-center gap-1.5 rounded-xl border bg-background px-3 text-sm transition-all duration-150 hover:bg-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";

function ImagePage() {
  const navigate = useNavigate();
  const [prompt, setPrompt] = useState("");
  const [model, setModel] = useState("gpt_image_2_5_sunburst");
  const [aspect, setAspect] = useState("1:1");
  const [tier, setTier] = useState<SizeTier>("Small");
  const [exactRatio, setExactRatio] = useState("");
  const [quality, setQuality] = useState("medium");
  const [count, setCount] = useState(1);
  const images = useImageInput({ max: 4 });
  const refs = images.ready;
  const [learned, setLearned] = useState<string[] | null>(null);
  const [errorSummary, setErrorSummary] = useState<string | null>(null);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [style, setStyle] = useState<Style | null>(null);
  const [compareOpen, setCompareOpen] = useState(false);
  const finalPrompt = combinePrompt(prompt, style);
  const qc = useQueryClient();
  const { create, busy, generationId, setGenerationId, attempts, error } = useCreate();
  const promptRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const config = baseImageConfig(model);
  const qualOptions = config.qualities;
  const [useProven, setUseProven] = useState(false);
  useEffect(() => setUseProven(localStorage.getItem("applyProvenConfig") === "1"), []);
  useEffect(() => {
    supabase.from("app_settings").select("default_image_model").maybeSingle().then(({ data }) => {
      if (data?.default_image_model && IMAGE_MODELS.some((m) => m.id === data.default_image_model)) setModel(data.default_image_model);
    });
  }, []);
  async function setDefaultModel(m: string) {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return;
    const { error } = await supabase.from("app_settings").upsert({ user_id: u.user.id, default_image_model: m, updated_at: new Date().toISOString() });
    if (error) return void toast.error(error.message);
    setModel(m);
    toast.success(`${IMAGE_MODELS.find((x) => x.id === m)?.label ?? m} is now your default model`);
  }
  const proven = useQuery({
    queryKey: ["model-config"],
    enabled: useProven,
    queryFn: async () => {
      const { data, error } = await supabase.from("model_config").select("model, ratios, quality");
      if (error) throw new Error(error.message);
      return Object.fromEntries(data.map((r) => [r.model, r]));
    },
  });
  const provenRatios = useProven ? proven.data?.[model]?.ratios : undefined;
  const exactRatios = provenRatios?.length ? provenRatios : (learned ?? config.ratios ?? null);

  useEffect(() => {
    setLearned(learnedRatios.get(model));
    if (qualOptions.length && !qualOptions.includes(quality)) setQuality("medium");
    if (count > config.maxOutputs) setCount(config.maxOutputs);
  }, [model]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (exactRatios && !exactRatios.includes(exactRatio)) setExactRatio(exactRatios[0] ?? "");
  }, [exactRatios, exactRatio]);

  useEffect(() => {
    const url = handoff.take("ref");
    if (url) addRef(url);
    const edit = handoff.take("edit");
    if (edit) startEdit(edit);
    const gen = handoff.take("loadGen");
    if (gen) {
      supabase.from("generations").select("id, kind, model, status, created_at, output_paths, params").eq("id", gen).single()
        .then(({ data }) => data && loadRecent(data));
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const addRef = (uri: string) => images.addUrl(uri, true);
  function startEdit(uri: string) {
    images.addUrl(uri, true, "edit");
    setSelectedId(null);
    setPrompt("@edit ");
    setTimeout(() => { const el = promptRef.current; el?.focus(); el?.setSelectionRange(6, 6); }, 50);
    toast.success("Image added as @edit — describe the change");
  }
  usePasteImages(images, promptRef);
  const zone = useDropZone(images);

  function insertTag(tag: string) {
    const el = promptRef.current;
    const at = el?.selectionStart ?? prompt.length;
    const end = el?.selectionEnd ?? at;
    const before = prompt.slice(0, at);
    const ins = `${before && !/\s$/.test(before) ? " " : ""}@${tag} `;
    setPrompt(before + ins + prompt.slice(end));
    setTimeout(() => { el?.focus(); el?.setSelectionRange(at + ins.length, at + ins.length); }, 0);
  }

  const ratio = exactRatios ? exactRatio : tableRatio(aspect, tier);
  const body = useMemo(() => {
    const b: Record<string, unknown> = { model, promptText: finalPrompt, ratio };
    if (refs.length) b["referenceImages"] = refs.map((r) => ({ uri: r.uri, tag: r.tag }));
    if (qualOptions.length) b["quality"] = quality;
    if (count > 1) b["outputCount"] = count;
    return b;
  }, [model, finalPrompt, ratio, refs, quality, count, qualOptions.length]);

  const longSide = Math.max(...ratio.split(":").map(Number).filter((n) => !Number.isNaN(n)), 0);
  const costRes = exactRatios
    ? model === "gen4_image"
      ? longSide >= 1920 ? "1080p" : "720p"
      : longSide >= 3000 ? "4K" : longSide >= 2400 ? "2K" : "1K"
    : tierToRes(tier);
  const cost = imageCost(model, costRes, quality, refs.length, count);

  async function generate() {
    if (busy || !prompt.trim()) return;
    setErrorSummary(null);
    const r = await create({ kind: "image", endpoint: "text_to_image", body, count, credits_estimated: Number(cost.split("–").pop()) || null });
    if (r.generationId) { setSelectedId(r.generationId); qc.invalidateQueries({ queryKey: ["library"] }); return; }
    const failed = [...r.attempts].reverse().find((a) => a.status >= 400);
    if (!failed) return;
    setErrorSummary(summarizeRunwayError(failed.status, failed.response));
    const values = failed.status === 400 ? ratioValuesFromError(failed.response) : null;
    if (values?.length) {
      learnedRatios.set(model, values);
      setLearned(values);
      toast.info(`Updated ratio options for ${model} from Runway`);
    }
  }

  function loadRecent(r: GenRow | { id: string; kind: string; params: unknown }) {
    setSelectedId(null);
    if (r.kind !== "image") {
      handoff.set("loadGen", r.id);
      navigate({ to: r.kind === "video" ? "/video" : r.kind === "audio" ? "/audio" : "/library" });
      return;
    }
    const p = (r.params ?? {}) as { body?: Record<string, unknown>; count?: number };
    const b = p.body ?? {};
    if (typeof b["promptText"] === "string") setPrompt(b["promptText"]);
    if (typeof b["model"] === "string") setModel(b["model"]);
    if (typeof b["quality"] === "string") setQuality(b["quality"]);
    if (typeof b["ratio"] === "string") setExactRatio(b["ratio"]);
    setCount(p.count ?? (typeof b["outputCount"] === "number" ? b["outputCount"] : 1));
    setErrorSummary(null);
    setGenerationId(r.id);
  }

  function reset() {
    setPrompt("");
    images.clear();
    setErrorSummary(null);
    setGenerationId(null);
    setSelectedId(null);
    setTimeout(() => promptRef.current?.focus(), 0);
  }

  const poll = useGenerationPoll(generationId);
  const running = busy || (!!generationId && !!poll.data && !FINAL.includes(poll.data.generation.status));

  const preview = { ...body, referenceImages: refs.map((r) => ({ tag: r.tag, uri: r.uri.slice(0, 40) + "…" })) };
  const modelLabel = IMAGE_MODELS.find((m) => m.id === model)?.label;

  const suggestions = [
    { icon: ImageIcon, title: "Generate image", desc: "Turn a description into pictures", go: () => promptRef.current?.focus() },
    { icon: Video, title: "Generate video", desc: "Animate an idea or a still image", go: () => navigate({ to: "/video" }) },
    { icon: AudioLines, title: "Text to speech", desc: "Give your words a natural voice", go: () => navigate({ to: "/audio" }) },
  ];

  return (
    <AppShell fullHeight>
      <Workspace
        selectedId={selectedId}
        onSelect={setSelectedId}
        onNew={reset}
        onLoadSettings={loadRecent}
        onUseAsRef={(u) => { addRef(u); setSelectedId(null); }}
        onEdit={startEdit}
        editor={<>
      <div className="px-4 pt-6 sm:px-6">
        <div className="mx-auto max-w-3xl space-y-5 pb-6">
            <div className="flex flex-col items-center pt-6 text-center sm:pt-10">
              <StarLogo size={56} pulsing={running} />
              <h1 className="mt-5 text-3xl font-semibold tracking-tight">Welcome back!</h1>
              <p className="mt-1 text-muted-foreground">What do you want to create today?</p>
              <div className="mt-8 grid w-full gap-3 sm:grid-cols-3">
                {suggestions.map((s) => (
                  <button
                    key={s.title}
                    type="button"
                    onClick={s.go}
                    className="lift rounded-[20px] border bg-background p-4 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <div className="grid size-9 place-items-center rounded-xl bg-muted"><s.icon className="size-4" /></div>
                    <p className="mt-3 text-sm font-semibold">{s.title}</p>
                    <p className="text-xs text-muted-foreground">{s.desc}</p>
                  </button>
                ))}
              </div>
            </div>
        </div>
      </div>
      </>}
        composer={<div className="mx-auto max-w-3xl space-y-3">
          {(errorSummary ?? error) && <ErrorBox details={attempts.length ? attempts : undefined}>{errorSummary ?? error}</ErrorBox>}
          {attempts.length > 0 && !(errorSummary ?? error) && (
            <details>
              <summary className="cursor-pointer text-xs text-muted-foreground">Raw Runway responses ({attempts.length})</summary>
              <Json value={attempts} className="mt-2" />
            </details>
          )}
        <div {...zone.props} className={`relative rounded-[20px] border bg-background p-3 shadow-pill transition-colors ${zone.over ? "border-foreground/60 ring-2 ring-foreground/15" : ""}`}>
          {zone.over && (
            <div className="pointer-events-none absolute inset-0 z-10 grid place-items-center rounded-[20px] bg-background/85 text-sm font-semibold">Drop to attach</div>
          )}
          <ImageTray input={images} onInsertTag={insertTag} />
          <textarea
            ref={promptRef}
            aria-label="Prompt"
            rows={2}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                e.preventDefault();
                generate();
              }
            }}
            placeholder="Describe what you want to create, use @tag for references..."
            className="max-h-48 min-h-[56px] w-full resize-none bg-transparent px-2 py-1 text-[15px] outline-none placeholder:text-muted-foreground"
          />
          {style && prompt.trim() && (
            <p className="mx-2 mb-1 line-clamp-2 rounded-xl bg-muted px-3 py-1.5 text-[13px] text-muted-foreground">
              <span className="font-medium text-foreground">Final prompt:</span> {finalPrompt}
            </p>
          )}
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <button type="button" className={pill} onClick={() => fileRef.current?.click()} disabled={images.full} aria-label="Attach reference images">
              <Paperclip className="size-4" /> Attach{images.items.length ? ` ${images.items.length}/4` : ""}
            </button>
            <input ref={fileRef} type="file" accept="image/*" multiple hidden onChange={(e) => { images.addFiles(e.target.files); e.target.value = ""; }} />

            <Popover>
              <PopoverTrigger asChild>
                <button type="button" className={pill}><SlidersHorizontal className="size-4" /> Settings</button>
              </PopoverTrigger>
              <PopoverContent align="start" className="w-80 space-y-3 rounded-[20px]">
                <Field label="Model">
                  <NativeSelect value={model} onChange={setModel} options={IMAGE_MODELS.map((m) => ({ value: m.id, label: m.label }))} />
                </Field>
                {exactRatios ? (
                  <Field label={`Ratio (${provenRatios?.length ? "proven by Model Check" : learned ? "from Runway" : "known for this model"})`}>
                    <NativeSelect value={exactRatio} onChange={setExactRatio} options={exactRatios} />
                  </Field>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="Aspect">
                      <NativeSelect value={aspect} onChange={setAspect} options={TABLE_ASPECTS.map((a) => ({ value: a, label: a === "auto" ? "Auto" : a }))} />
                    </Field>
                    <Field label="Size">
                      <NativeSelect value={tier} onChange={(v) => setTier(v as SizeTier)} options={SIZE_TIERS.map((t) => ({ value: t, label: SIZE_LABELS[t] }))} />
                    </Field>
                  </div>
                )}
                {qualOptions.length > 0 && (
                  <Field label="Quality">
                    <NativeSelect value={quality} onChange={setQuality} options={qualOptions} />
                  </Field>
                )}
                <Field label="Number of outputs">
                  <Segmented value={count} onChange={setCount} options={[1, 2, 3, 4].filter((n) => n <= config.maxOutputs)} />
                </Field>
                <p className="font-mono text-[11px] text-muted-foreground">
                  ratio sent: {ratio}
                  {useProven && (
                    <button type="button" className="ml-2 underline" onClick={() => { localStorage.removeItem("applyProvenConfig"); setUseProven(false); }}>
                      stop using proven settings
                    </button>
                  )}
                </p>
                <details>
                  <summary className="cursor-pointer text-xs text-muted-foreground">Request body</summary>
                  <Json value={preview} className="mt-2 max-h-48" />
                </details>
              </PopoverContent>
            </Popover>

            <PromptsPopover prompt={prompt} model={model} settings={{ ratio, quality, count }} onInsert={(p) => { setPrompt(p); promptRef.current?.focus(); }} />
            <StylesPopover active={style} onChange={setStyle} />
            <button type="button" className={pill} onClick={() => setCompareOpen(true)}><Columns2 className="size-4" /> Compare</button>

            <Popover>
              <PopoverTrigger asChild>
                <button type="button" className={pill}><Wand2 className="size-4" /> Enhance</button>
              </PopoverTrigger>
              <PopoverContent align="start" className="w-96 rounded-[20px] p-2">
                <PromptHelper model={model} modelLabel={modelLabel} refTags={refs.map((r) => r.tag)} onUse={(p) => { setPrompt(p); promptRef.current?.focus(); }} startOpen />
              </PopoverContent>
            </Popover>

            <Segmented
              value="image"
              onChange={(v) => v !== "image" && navigate({ to: v === "video" ? "/video" : "/audio" })}
              options={["image", "video", "audio"]}
            />

            <div className="ml-auto flex items-center gap-2">
              <span className="rounded-full bg-muted px-3 py-1 text-xs font-medium tabular-nums">
                ≈ {cost} credits{isGpt(model) && refs.length > 0 ? ` (+${refs.length})` : ""}
              </span>
              <button
                type="button"
                aria-label="Generate (Ctrl+Enter)"
                title="Generate (Ctrl/⌘+Enter)"
                disabled={busy || !prompt.trim()}
                onClick={generate}
                className="grid size-10 place-items-center rounded-full bg-primary text-primary-foreground transition hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-40 disabled:hover:scale-100"
              >
                <ArrowUp className={`size-5 ${busy ? "animate-pulse" : ""}`} />
              </button>
            </div>
          </div>
        </div>
      </div>}
      />
      <Dialog open={!!lightbox} onOpenChange={(o) => !o && setLightbox(null)}>
        <DialogContent className="max-w-5xl rounded-[24px] p-2">
          <DialogTitle className="sr-only">Image preview</DialogTitle>
          {lightbox && <img src={lightbox} alt="Generated output" className="max-h-[85vh] w-full rounded-[18px] object-contain" />}
        </DialogContent>
      </Dialog>
      <GlobalDropOverlay input={images} />
      <CompareDialog
        open={compareOpen}
        onOpenChange={setCompareOpen}
        prompt={finalPrompt}
        refs={refs.map((r) => ({ uri: r.uri, tag: r.tag }))}
        quality={quality}
        fallbackRatio={tableRatio(aspect, tier)}
        provenRatios={Object.fromEntries(Object.entries(proven.data ?? {}).map(([k, v]) => [k, (v as { ratios?: string[] }).ratios]))}
        onDefault={setDefaultModel}
      />
    </AppShell>
  );
}
