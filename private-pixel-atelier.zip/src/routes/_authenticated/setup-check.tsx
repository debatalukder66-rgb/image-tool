import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Check, RefreshCw, X } from "lucide-react";
import type { ReactNode } from "react";
import { AppShell } from "@/components/studio/AppShell";
import { Panel } from "@/components/studio/ui";
import { ErrorBox } from "@/components/studio/Json";
import { healthCheck } from "@/lib/setup.functions";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/setup-check")({
  head: pageHead("Setup Check", "Checks secrets, Runway, tables and storage for this deployment."),
  component: SetupCheck,
});

const WHERE = "your host's secrets (Cloudflare: Worker → Settings → Variables and Secrets), then redeploy";

function frontendHost() {
  try { return new URL(import.meta.env['VITE_SUPABASE_URL'] as string).host; } catch { return null; }
}

function Row({ ok, label, hint, children }: { ok: boolean | null; label: string; hint?: string; children?: ReactNode }) {
  return (
    <li className="flex items-start gap-3 border-b py-3 last:border-0">
      <span className={`mt-0.5 grid size-5 shrink-0 place-items-center rounded-full ${ok === null ? "bg-muted text-muted-foreground" : ok ? "bg-info/15 text-info" : "bg-destructive/15 text-destructive"}`}>
        {ok === false ? <X className="size-3.5" /> : <Check className="size-3.5" />}
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium">{label}</p>
        {children && <div className="text-[13px] text-muted-foreground">{children}</div>}
        {ok === false && hint && <p className="text-[13px] text-destructive">{hint}</p>}
      </div>
    </li>
  );
}

function SetupCheck() {
  const fn = useServerFn(healthCheck);
  const q = useQuery({ queryKey: ["health"], queryFn: () => fn(), staleTime: Infinity, retry: false });
  const h = q.data;
  const fe = frontendHost();
  return (
    <AppShell>
      <div className="mx-auto max-w-3xl space-y-4">
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm text-muted-foreground">Checks this deployment's configuration. Secret values are never shown.</p>
          <button type="button" onClick={() => q.refetch()} className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
            <RefreshCw className={`size-4 ${q.isFetching ? "animate-spin" : ""}`} /> Run again
          </button>
        </div>
        {q.error && <ErrorBox>{(q.error as Error).message}</ErrorBox>}

        <Panel>
          <h2 className="mb-1 font-semibold">Connection</h2>
          <ul>
            <Row ok={!!fe} label="Frontend backend address" hint="Set build variable VITE_SUPABASE_URL on your host, then rebuild.">{fe ?? "not set"}</Row>
            <Row ok={h ? !!h.serverHost : null} label="Server backend address" hint={`Add secret SUPABASE_URL in ${WHERE}.`}>{h ? h.serverHost ?? "not set" : "…"}</Row>
            {fe && h?.serverHost && (
              <Row ok={fe === h.serverHost} label="Frontend and server use the same project" hint="VITE_SUPABASE_URL and SUPABASE_URL point to different projects. Make both your new project's URL." />
            )}
          </ul>
        </Panel>

        <Panel>
          <h2 className="mb-1 font-semibold">Secrets</h2>
          <ul>
            {(h?.secrets ?? []).map((s) => (
              <Row key={s.name} ok={s.set ? true : s.optional ? null : false} label={s.name} hint={`Add secret ${s.name} in ${WHERE}.`}>
                {s.set ? "set" : s.optional ? "missing (optional: only Enhance / Prompt Lab need it)" : "missing"}
              </Row>
            ))}
            <Row ok={h ? h.emailMatches : null} label="Your email matches ALLOWED_EMAIL" hint={h?.emailMatches === null ? `Add secret ALLOWED_EMAIL in ${WHERE}.` : "Sign in with the allowed email, or change ALLOWED_EMAIL."}>
              {h ? (h.emailMatches === null ? "ALLOWED_EMAIL is not set" : h.emailMatches ? "yes" : "no") : "…"}
            </Row>
          </ul>
        </Panel>

        {h?.limited ? (
          <Panel><p className="text-sm text-muted-foreground">Runway, table and storage checks run once your email matches ALLOWED_EMAIL.</p></Panel>
        ) : (
          <>
            <Panel>
              <h2 className="mb-1 font-semibold">Runway</h2>
              <ul>
                <Row ok={h?.runway ? h.runway.ok : null} label="Runway connection" hint={h?.runway?.status === 401 ? "Runway rejected the key. Replace RUNWAYML_API_SECRET with a valid Dev API key." : "Check RUNWAYML_API_SECRET and try again."}>
                  {h?.runway ? `${h.runway.ok ? "ok" : "failed"} · HTTP ${h.runway.status} · ${h.runway.message}` : "…"}
                </Row>
              </ul>
            </Panel>
            <Panel>
              <h2 className="mb-1 font-semibold">Database and storage</h2>
              <ul>
                {(h?.tables ?? []).map((t) => (
                  <Row key={t.name} ok={t.ok} label={`Table ${t.name}`} hint="Run SETUP.sql in your Supabase SQL Editor.">{t.ok ? "exists and readable" : t.message}</Row>
                ))}
                <Row ok={h?.bucket ? h.bucket.ok : null} label="Storage bucket generations" hint="Run SETUP.sql, or create a private bucket named generations in Storage.">
                  {h?.bucket ? (h.bucket.ok ? "exists" : h.bucket.message) : "…"}
                </Row>
              </ul>
            </Panel>
          </>
        )}

        <Panel>
          <h2 className="mb-1 font-semibold">Edge functions</h2>
          <p className="text-sm text-muted-foreground">
            This app expects <b>no</b> Supabase Edge Functions, so nothing needs deploying in Supabase. Its server code runs inside your host:
          </p>
          <p className="mt-2 font-mono text-xs text-muted-foreground">{(h?.serverFunctions ?? []).join(", ")}</p>
        </Panel>
      </div>
    </AppShell>
  );
}
