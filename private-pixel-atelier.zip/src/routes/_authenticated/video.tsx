import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/studio/AppShell";
import { Field, NativeSelect, Panel, Segmented } from "@/components/studio/ui";
import { GenerationResult } from "@/components/studio/GenerationResult";
import { ErrorBox, Json } from "@/components/studio/Json";
import { useCreate } from "@/components/studio/useCreate";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { VIDEO_MODELS, videoCostPerSec, videoRatios } from "@/lib/catalog";
import { handoff } from "@/lib/image-utils";
import { GlobalDropOverlay, ImageTray, useDropZone, useImageInput, usePasteImages } from "@/components/studio/ImageInput";
import { useRef } from "react";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/video")({
  head: pageHead("Video", "Generate videos from text or a start image."),
  component: VideoPage,
});

type Mode = "Text to video" | "Image to video";

function VideoPage() {
  const [mode, setMode] = useState<Mode>("Text to video");
  const [model, setModel] = useState("gen4.5");
  const [prompt, setPrompt] = useState("");
  const start = useImageInput({ max: 1, replace: true });
  const image = start.ready[0]?.uri ?? null;
  const promptRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  usePasteImages(start, promptRef);
  const zone = useDropZone(start);
  const [ratio, setRatio] = useState("1280:720");
  const [duration, setDuration] = useState(5);
  const [resolution, setResolution] = useState("");
  const [audio, setAudio] = useState(false);
  const { create, busy, generationId, attempts, error } = useCreate();

  useEffect(() => {
    const url = handoff.take("videoStart");
    if (url) {
      start.addUrl(url, true);
      setMode("Image to video");
    }
  }, []);

  const m = mode === "Text to video" ? "t2v" : "i2v";
  const ratios = videoRatios(model, m);
  useEffect(() => {
    if (!ratios.includes(ratio)) setRatio(ratios[0]!);
  }, [model, mode]); // eslint-disable-line react-hooks/exhaustive-deps

  // gen4.5 text-only goes through image_to_video without promptImage.
  const endpoint = m === "i2v" || model === "gen4.5" ? "image_to_video" : "text_to_video";
  const isVeo = model.startsWith("veo");

  const body = useMemo(() => {
    const b: Record<string, unknown> = { model, promptText: prompt, ratio, duration };
    if (m === "i2v" && image) b["promptImage"] = image;
    if (resolution) b["resolution"] = resolution;
    if (isVeo) b["audio"] = audio;
    return b;
  }, [model, prompt, ratio, duration, image, m, resolution, isVeo, audio]);

  const per = videoCostPerSec(model, resolution || "720p", audio);
  const cost = per === null ? "?" : String(per * duration);

  return (
    <AppShell>
      <div className="grid gap-6 lg:grid-cols-[420px_1fr]">
        <Panel className="space-y-4">
          <Segmented value={mode} onChange={setMode} options={["Text to video", "Image to video"] as Mode[]} />
          <Field label="Model">
            <NativeSelect value={model} onChange={setModel} options={VIDEO_MODELS.map((v) => ({ value: v, label: v === "gen4_turbo" ? `${v} (image only)` : v }))} />
          </Field>
          <Field label="Prompt">
            <Textarea ref={promptRef} rows={4} value={prompt} onChange={(e) => setPrompt(e.target.value)} />
          </Field>
          {m === "i2v" && (
            <Field label="Start image">
              <div {...zone.props} className={`rounded-[20px] border-2 border-dashed p-3 transition-colors ${zone.over ? "border-foreground/60 bg-muted" : "border-border"}`}>
                <ImageTray input={start} showTags={false} />
                <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                  <Button type="button" variant="outline" size="sm" onClick={() => fileRef.current?.click()} aria-label="Choose start image">Attach</Button>
                  <span>{zone.over ? "Drop to attach" : "or drop / paste an image"}</span>
                </div>
                <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => { start.addFiles(e.target.files); e.target.value = ""; }} />
              </div>
            </Field>
          )}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Ratio">
              <NativeSelect value={ratio} onChange={setRatio} options={ratios} />
            </Field>
            <Field label="Duration (s)">
              <Input type="number" min={1} max={20} value={duration} onChange={(e) => setDuration(Number(e.target.value) || 5)} />
            </Field>
            <Field label="Resolution">
              <NativeSelect value={resolution} onChange={setResolution} options={[{ value: "", label: "(not sent)" }, "720p", "1080p"]} />
            </Field>
            {isVeo && (
              <label className="flex items-end gap-2 pb-2 text-sm">
                <input type="checkbox" checked={audio} onChange={(e) => setAudio(e.target.checked)} /> Audio
              </label>
            )}
          </div>
          <div className="flex items-center gap-3 pt-2">
            <Button
              disabled={busy || (m === "i2v" && !image) || (model === "gen4_turbo" && !image)}
              onClick={() => create({ kind: "video", endpoint, body, credits_estimated: per === null ? null : per * duration })}
            >
              {busy ? "Sending…" : "Generate"}
            </Button>
            <span className="font-mono text-sm text-muted-foreground">≈ {cost} credits {per !== null && `(${per}/s)`}</span>
          </div>
          <details>
            <summary className="cursor-pointer text-xs text-muted-foreground">Request · POST /v1/{endpoint}</summary>
            <Json value={{ ...body, promptImage: image ? image.slice(0, 40) + "…" : undefined }} className="mt-2" />
          </details>
        </Panel>
        <div className="space-y-4">
          {error && <ErrorBox>{error}</ErrorBox>}
          {generationId ? (
            <GenerationResult id={generationId} />
          ) : (
            <div className="flex h-64 items-center justify-center rounded-xl border border-dashed text-sm text-muted-foreground">
              Your video will appear here
            </div>
          )}
          {attempts.length > 0 && (
            <details>
              <summary className="cursor-pointer text-xs text-muted-foreground">Raw Runway responses</summary>
              <Json value={attempts} className="mt-2" />
            </details>
          )}
        </div>
      </div>
      <GlobalDropOverlay input={start} label="Drop an image to use as the start frame" />
    </AppShell>
  );
}
