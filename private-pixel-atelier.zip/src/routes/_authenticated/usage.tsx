import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/studio/AppShell";
import { IMAGE_MODELS } from "@/lib/catalog";
import { useSpendLimit, utcDayStart } from "@/lib/usage";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/usage")({
  head: pageHead("Usage", "Credits spent per day, model and kind, with a daily spend limit."),
  component: UsagePage,
});

const axis = { fontSize: 12, fill: "var(--muted-foreground)" };
const tip = { contentStyle: { borderRadius: 12, border: "1px solid var(--border)", fontSize: 13 } };

function Card({ title, children, className = "" }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <section className={`rounded-[20px] border p-5 ${className}`}>
      <h2 className="mb-3 text-sm font-semibold">{title}</h2>
      {children}
    </section>
  );
}

function UsagePage() {
  const qc = useQueryClient();
  const limit = useSpendLimit();
  const [limitInput, setLimitInput] = useState("");
  useEffect(() => setLimitInput(limit.data?.limit != null ? String(limit.data.limit) : ""), [limit.data?.limit]);

  const rows = useQuery({
    queryKey: ["library", "usage30"],
    queryFn: async () => {
      const since = utcDayStart();
      since.setUTCDate(since.getUTCDate() - 29);
      const { data, error } = await supabase
        .from("generations")
        .select("created_at, model, kind, credits_estimated")
        .gte("created_at", since.toISOString())
        .limit(5000);
      if (error) throw new Error(error.message);
      return data;
    },
  });

  const stats = useMemo(() => {
    const data = rows.data ?? [];
    const days: { day: string; credits: number }[] = [];
    const start = utcDayStart();
    for (let i = 29; i >= 0; i--) {
      const d = new Date(start);
      d.setUTCDate(d.getUTCDate() - i);
      days.push({ day: d.toISOString().slice(0, 10), credits: 0 });
    }
    const byDay = Object.fromEntries(days.map((d) => [d.day, d]));
    const byModel: Record<string, number> = {};
    const byKind: Record<string, number> = {};
    let total = 0;
    for (const r of data) {
      const c = Number(r.credits_estimated) || 0;
      total += c;
      const d = byDay[r.created_at.slice(0, 10)];
      if (d) d.credits += c;
      const m = IMAGE_MODELS.find((x) => x.id === r.model)?.label ?? r.model ?? "unknown";
      byModel[m] = (byModel[m] ?? 0) + c;
      byKind[r.kind] = (byKind[r.kind] ?? 0) + c;
    }
    const sortEntries = (o: Record<string, number>) => Object.entries(o).map(([name, credits]) => ({ name, credits })).sort((a, b) => b.credits - a.credits);
    return { days, models: sortEntries(byModel), kinds: sortEntries(byKind), total };
  }, [rows.data]);

  async function saveLimit() {
    const v = limitInput.trim() === "" ? null : Number(limitInput);
    if (v !== null && (!Number.isFinite(v) || v < 0)) return void toast.error("Enter a positive number, or leave empty for no limit");
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return;
    const { error } = await supabase.from("app_settings").upsert({ user_id: u.user.id, daily_credit_limit: v, updated_at: new Date().toISOString() });
    if (error) return void toast.error(error.message);
    toast.success(v === null ? "Daily limit removed" : `Daily limit set to ${v} credits`);
    qc.invalidateQueries({ queryKey: ["library", "spend-limit"] });
  }

  const today = limit.data?.used ?? 0;
  const lim = limit.data?.limit ?? null;
  const pct = lim ? Math.min(100, (today / lim) * 100) : 0;

  return (
    <AppShell>
      <div className="mx-auto max-w-6xl space-y-5">
        <div className="grid gap-4 sm:grid-cols-3">
          <Card title="Today (UTC)">
            <p className="text-3xl font-semibold tabular-nums">{today}</p>
            <p className="text-[13px] text-muted-foreground">{lim ? `of ${lim} credit limit` : "no daily limit"}</p>
            {lim ? (
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
                <div className={`h-full rounded-full ${pct >= 100 ? "bg-destructive" : pct >= 80 ? "bg-warning" : "bg-primary"}`} style={{ width: `${pct}%` }} />
              </div>
            ) : null}
          </Card>
          <Card title="Last 30 days">
            <p className="text-3xl font-semibold tabular-nums">{stats.total}</p>
            <p className="text-[13px] text-muted-foreground">estimated credits</p>
          </Card>
          <Card title="Daily spend limit">
            <div className="flex gap-2">
              <input
                aria-label="Daily credit limit"
                inputMode="numeric"
                value={limitInput}
                onChange={(e) => setLimitInput(e.target.value)}
                placeholder="No limit"
                className="h-10 min-w-0 flex-1 rounded-xl border px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
              />
              <button type="button" onClick={saveLimit} className="h-10 rounded-full bg-primary px-4 text-sm text-primary-foreground">Save</button>
            </div>
            <p className="mt-2 text-[13px] text-muted-foreground">Requests that would go over this are blocked before reaching Runway. Resets at midnight UTC.</p>
          </Card>
        </div>

        <Card title="Credits per day">
          <div className="h-64">
            <ResponsiveContainer>
              <BarChart data={stats.days}>
                <CartesianGrid vertical={false} stroke="var(--border)" />
                <XAxis dataKey="day" tick={axis} tickFormatter={(d: string) => d.slice(5)} interval={4} axisLine={false} tickLine={false} />
                <YAxis tick={axis} axisLine={false} tickLine={false} width={40} />
                <Tooltip {...tip} cursor={{ fill: "var(--muted)" }} />
                <Bar dataKey="credits" fill="var(--primary)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <div className="grid gap-5 lg:grid-cols-2">
          <Card title="By model">
            <div style={{ height: Math.max(160, stats.models.length * 34) }}>
              <ResponsiveContainer>
                <BarChart data={stats.models} layout="vertical" margin={{ left: 10 }}>
                  <XAxis type="number" tick={axis} axisLine={false} tickLine={false} />
                  <YAxis type="category" dataKey="name" tick={axis} width={140} axisLine={false} tickLine={false} />
                  <Tooltip {...tip} cursor={{ fill: "var(--muted)" }} />
                  <Bar dataKey="credits" fill="var(--primary)" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
          <Card title="By kind">
            <div className="space-y-3">
              {stats.kinds.map((k) => (
                <div key={k.name}>
                  <div className="flex justify-between text-sm"><span className="capitalize">{k.name}</span><span className="tabular-nums text-muted-foreground">{k.credits}</span></div>
                  <div className="mt-1 h-2 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${stats.total ? (k.credits / stats.total) * 100 : 0}%` }} />
                  </div>
                </div>
              ))}
              {!stats.kinds.length && <p className="text-[13px] text-muted-foreground">Nothing spent in the last 30 days.</p>}
            </div>
          </Card>
        </div>
        <p className="text-[13px] text-subtle-foreground">Based on the estimated credits recorded for each generation (including items in Trash), not Runway's invoice.</p>
      </div>
    </AppShell>
  );
}
