import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { Check, Download, RefreshCw, Trash2, Wrench } from "lucide-react";
import { Workspace } from "@/components/studio/Workspace";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/studio/AppShell";
import { Segmented } from "@/components/studio/ui";
import { MediaGrid, StatusBadge } from "@/components/studio/GenerationResult";
import { ErrorBox, Json } from "@/components/studio/Json";
import { Button } from "@/components/ui/button";
import { deleteGeneration, FINAL, prepareRepair, runwayCreate, runwayStatus } from "@/lib/runway.functions";
import { pageHead } from "@/lib/seo";

function timeAgo(iso: string) {
  const s = Math.max(1, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

export const Route = createFileRoute("/_authenticated/library")({
  head: pageHead("Library", "All your generated images, videos and audio."),
  component: LibraryPage,
});

const KINDS = ["all", "image", "video", "audio", "tool"] as const;

async function countBucketFiles(uid: string) {
  const { data: folders, error } = await supabase.storage.from("generations").list(uid, { limit: 1000 });
  if (error) throw error;
  let n = 0;
  for (const f of folders ?? []) {
    const { data: files, error: e2 } = await supabase.storage.from("generations").list(`${uid}/${f.name}`, { limit: 1000 });
    if (e2) throw e2;
    n += files?.length ?? 0;
  }
  return n;
}

function LibraryPage() {
  const [kind, setKind] = useState<(typeof KINDS)[number]>("all");
  const qc = useQueryClient();
  const del = useServerFn(deleteGeneration);
  const rerun = useServerFn(runwayCreate);
  const poll = useServerFn(runwayStatus);
  const repairFn = useServerFn(prepareRepair);
  const [repairing, setRepairing] = useState(false);
  const [repairLog, setRepairLog] = useState<unknown>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [view, setView] = useState<"list" | "grid">("list");
  const [sel, setSel] = useState<string | null>(null);
  const navigateLib = useNavigate();
  const toggle = (id: string) => setSelected((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const list = useQuery({
    queryKey: ["library", kind],
    refetchOnMount: "always",
    queryFn: async () => {
      const { data: u, error: uErr } = await supabase.auth.getUser();
      if (uErr || !u.user) throw new Error(`Not signed in: ${uErr?.message ?? ""}`);
      let q = supabase
        .from("generations")
        .select("*")
        .eq("user_id", u.user.id)
        .order("created_at", { ascending: false })
        .limit(200);
      if (kind !== "all") q = q.eq("kind", kind);
      const { data, error } = await q;
      if (error) throw new Error(`${error.code ?? ""} ${error.message} ${error.details ?? ""} ${error.hint ?? ""}`);
      return { rows: data, uid: u.user.id };
    },
  });

  const diag = useQuery({
    queryKey: ["library-diag", list.data?.uid],
    enabled: !!list.data?.uid,
    queryFn: async () => {
      const uid = list.data!.uid;
      const all = await supabase.from("generations").select("id, output_paths, status").eq("user_id", uid);
      if (all.error) throw new Error(all.error.message);
      return {
        rows: all.data.length,
        emptyOutputs: all.data.filter((r) => !r.output_paths?.length).length,
        notFinal: all.data.filter((r) => !FINAL.includes(r.status)).length,
        bucketFiles: await countBucketFiles(uid),
      };
    },
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["library"] });
    qc.invalidateQueries({ queryKey: ["library-diag"] });
  };

  // Finalize any rows left PENDING/RUNNING/THROTTLED (e.g. the tab was closed while polling).
  const finalizing = useRef(false);
  useEffect(() => {
    const pending = list.data?.rows.filter((r) => !FINAL.includes(r.status)) ?? [];
    if (!pending.length || finalizing.current) return;
    finalizing.current = true;
    (async () => {
      for (const r of pending) {
        try {
          await poll({ data: { generation_id: r.id } });
        } catch (e) {
          toast.error(`Status check failed for ${r.id.slice(0, 8)}: ${(e as Error).message}`);
        }
      }
      finalizing.current = false;
      refresh();
    })();
  }, [list.data]); // eslint-disable-line react-hooks/exhaustive-deps

  async function repair() {
    setRepairing(true);
    try {
      const { report } = await repairFn();
      const results: unknown[] = [];
      for (const r of report) {
        try {
          const s = await poll({ data: { generation_id: r.id } });
          results.push({ ...r, status: s.generation.status, files: s.generation.output_paths.length, error: s.generation.error });
        } catch (e) {
          results.push({ ...r, error: (e as Error).message });
        }
      }
      setRepairLog(results.length ? results : "Nothing to repair — every row's files are in storage.");
      toast.success(`Repair checked ${report.length} row(s)`);
      refresh();
    } catch (e) {
      toast.error((e as Error).message);
      setRepairLog(String(e));
    } finally {
      setRepairing(false);
    }
  }

  const rows = list.data?.rows;

  async function bulkDelete() {
    if (!confirm(`Delete ${selected.size} generation(s) and their files?`)) return;
    for (const id of selected) {
      try { await del({ data: { id } }); } catch (e) { toast.error((e as Error).message); }
    }
    setSelected(new Set());
    refresh();
  }
  async function bulkDownload() {
    const paths = (rows ?? []).filter((r) => selected.has(r.id)).flatMap((r) => r.output_paths ?? []);
    if (!paths.length) { toast.info("No files in the selection"); return; }
    for (const p of paths) {
      const { data, error } = await supabase.storage.from("generations").createSignedUrl(p, 600, { download: true });
      if (error || !data) { toast.error(error?.message ?? "Download failed"); continue; }
      const a = document.createElement("a");
      a.href = data.signedUrl;
      a.click();
      await new Promise((r) => setTimeout(r, 400));
    }
  }

  if (view === "list")
    return (
      <AppShell fullHeight>
        <Workspace selectedId={sel} onSelect={setSel} onNew={() => navigateLib({ to: "/image" })} toolbarExtra={<Segmented value={view} onChange={setView} options={["list", "grid"]} />} />
      </AppShell>
    );

  return (
    <AppShell>
      <div className="mb-5 flex justify-end"><Segmented value={view} onChange={setView} options={["list", "grid"]} /></div>
      <div className="mb-5 flex flex-wrap items-center gap-3">
        
        <Segmented value={kind} onChange={setKind} options={[...KINDS]} />
        <div className="ml-auto flex flex-wrap gap-2 pr-10 lg:pr-0">
          {selected.size > 0 && (
            <>
              <Button size="sm" variant="secondary" onClick={bulkDownload}><Download /> Download ({selected.size})</Button>
              <Button size="sm" variant="destructive" onClick={bulkDelete}><Trash2 /> Delete ({selected.size})</Button>
              <Button size="sm" variant="ghost" onClick={() => setSelected(new Set())}>Clear</Button>
            </>
          )}
          <Button size="sm" variant="secondary" onClick={refresh}><RefreshCw /> Reload</Button>
          <Button size="sm" variant="secondary" onClick={repair} disabled={repairing}><Wrench /> {repairing ? "Repairing…" : "Repair"}</Button>
        </div>
      </div>

      <details className="mb-5 rounded-[20px] border p-3 text-sm">
        <summary className="cursor-pointer text-xs text-muted-foreground">Library diagnostics</summary>
        <div className="mt-2 space-y-2">
          {diag.data && (
            <div className="grid grid-cols-2 gap-2 font-mono text-xs sm:grid-cols-4">
              <span>rows: {diag.data.rows}</span>
              <span>empty outputs: {diag.data.emptyOutputs}</span>
              <span>not final: {diag.data.notFinal}</span>
              <span>files in storage: {diag.data.bucketFiles}</span>
            </div>
          )}
          {diag.error && <ErrorBox>Diagnostics failed: {(diag.error as Error).message}</ErrorBox>}
          {repairLog !== null && <Json value={repairLog} />}
          <p className="text-xs text-muted-foreground">Repair re-downloads missing files from Runway. Runway keeps outputs only 24–48h; older files can't be recovered.</p>
        </div>
      </details>

      {list.error && <ErrorBox>Library query failed: {(list.error as Error).message}</ErrorBox>}
      {list.isLoading && (
        <div className="columns-1 gap-4 sm:columns-2 xl:columns-3">
          {Array.from({ length: 6 }, (_, i) => <div key={i} className="mb-4 h-56 break-inside-avoid animate-pulse rounded-[20px] bg-muted" />)}
        </div>
      )}
      <div className="columns-1 gap-4 sm:columns-2 xl:columns-3">
        {rows?.map((g) => {
          const params = (g.params ?? {}) as { endpoint?: string; body?: Record<string, unknown>; count?: number };
          const promptText = String(params.body?.["promptText"] ?? params.body?.["text"] ?? "");
          const isSel = selected.has(g.id);
          return (
            <div key={g.id} className={`mb-4 break-inside-avoid space-y-3 rounded-[20px] border bg-background p-3 transition ${isSel ? "ring-2 ring-ring" : ""}`}>
              <div className="flex min-w-0 items-center gap-2 text-xs">
                <button
                  type="button"
                  aria-label={isSel ? "Deselect" : "Select"}
                  aria-pressed={isSel}
                  onClick={() => toggle(g.id)}
                  className={`grid size-5 place-items-center rounded-full border transition ${isSel ? "bg-primary text-primary-foreground" : "bg-background"}`}
                >
                  {isSel && <Check className="size-3" />}
                </button>
                <StatusBadge status={g.status} />
                <span className="min-w-0 truncate rounded-full bg-muted px-2 py-0.5">{g.model ?? "?"}</span>
                <span className="ml-auto shrink-0 text-muted-foreground" title={new Date(g.created_at).toLocaleString()}>{timeAgo(g.created_at)}</span>
              </div>
              <MediaGrid paths={g.output_paths ?? []} prompt={promptText} onOpen={setLightbox} />
              {promptText && <p className="line-clamp-3 text-sm">{promptText}</p>}
              {g.error && <ErrorBox details={g.task_statuses}>{g.error}</ErrorBox>}
              <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                <span>{g.kind}</span>·<span>{g.credits_estimated ?? "?"} credits est.</span>
                <div className="ml-auto flex gap-1">
                  {!FINAL.includes(g.status) && (
                    <Button size="sm" variant="ghost" onClick={async () => {
                      try { await poll({ data: { generation_id: g.id } }); } catch (e) { toast.error((e as Error).message); }
                      refresh();
                    }}>
                      Refresh
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={async () => {
                      if (!params.endpoint || !params.body) { toast.error("No stored request to re-run"); return; }
                      if (JSON.stringify(params.body).includes("chars)")) toast.warning("Uploaded images weren't stored; re-run may fail");
                      const r = await rerun({ data: { kind: g.kind as "image", endpoint: params.endpoint, body: params.body, count: params.count, credits_estimated: g.credits_estimated } });
                      if (!r.ok) toast.error(r.error);
                      else toast.success("Re-run started");
                      refresh();
                    }}
                  >
                    Re-run
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={async () => {
                      if (!confirm("Delete this generation and its files?")) return;
                      try {
                        await del({ data: { id: g.id } });
                        refresh();
                      } catch (e) {
                        toast.error((e as Error).message);
                      }
                    }}
                  >
                    Delete
                  </Button>
                </div>
              </div>
              <details>
                <summary className="cursor-pointer text-xs text-muted-foreground">Params</summary>
                <Json value={g.params} className="mt-2" />
              </details>
            </div>
          );
        })}
      </div>
      {rows?.length === 0 && (
        <div className="rounded-[20px] border border-dashed p-10 text-center text-sm text-muted-foreground">Nothing here yet — generate something and it will appear here.</div>
      )}

      <Dialog open={!!lightbox} onOpenChange={(o) => !o && setLightbox(null)}>
        <DialogContent className="max-w-5xl rounded-[24px] p-2">
          <DialogTitle className="sr-only">Image preview</DialogTitle>
          {lightbox && <img src={lightbox} alt="Generated output" className="max-h-[85vh] w-full rounded-[18px] object-contain" />}
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
