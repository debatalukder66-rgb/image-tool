import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/studio/AppShell";
import { Field, NativeSelect, Panel, Segmented } from "@/components/studio/ui";
import { GenerationResult } from "@/components/studio/GenerationResult";
import { ErrorBox, Json } from "@/components/studio/Json";
import { useCreate } from "@/components/studio/useCreate";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { sfxCost, TTS_MODELS, ttsCost } from "@/lib/catalog";
import { runwayVoices } from "@/lib/runway.functions";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/audio")({
  head: pageHead("Audio", "Text to speech and sound effects."),
  component: AudioPage,
});

type Mode = "Text to speech" | "Sound effect";

/** Best-effort mapping of the /v1/voices response into {id,label}. */
function mapVoices(body: unknown): { value: string; label: string }[] {
  const list = Array.isArray(body) ? body : ((body as { data?: unknown[]; voices?: unknown[] })?.data ?? (body as { voices?: unknown[] })?.voices ?? []);
  return (list as Record<string, unknown>[]).map((v) => {
    const id = String(v["id"] ?? v["presetId"] ?? v["voiceId"] ?? v["name"] ?? "");
    return { value: id, label: String(v["name"] ?? id) };
  }).filter((v) => v.value);
}

function AudioPage() {
  const [mode, setMode] = useState<Mode>("Text to speech");
  const [model, setModel] = useState("eleven_multilingual_v2");
  const [text, setText] = useState("");
  const [voice, setVoice] = useState("");
  const [voiceType, setVoiceType] = useState("runway-preset");
  const [duration, setDuration] = useState<string>("");
  const voicesFn = useServerFn(runwayVoices);
  const voices = useQuery({ queryKey: ["voices"], queryFn: () => voicesFn() });
  const voiceOptions = voices.data?.ok ? mapVoices(voices.data.body) : [];
  const { create, busy, generationId, attempts, error } = useCreate();

  const tts = mode === "Text to speech";
  const body = useMemo(() => {
    if (tts) return { model, promptText: text, voice: { type: voiceType, presetId: voice } };
    const b: Record<string, unknown> = { model: "eleven_text_to_sound_v2", promptText: text };
    if (duration) b["duration"] = Number(duration);
    return b;
  }, [tts, model, text, voice, voiceType, duration]);
  const cost = tts ? ttsCost(model, text.length) : String(sfxCost(duration ? Number(duration) : undefined));

  return (
    <AppShell>
      <div className="grid gap-6 lg:grid-cols-[420px_1fr]">
        <Panel className="space-y-4">
          <Segmented value={mode} onChange={setMode} options={["Text to speech", "Sound effect"] as Mode[]} />
          {tts && (
            <>
              <Field label="Model">
                <NativeSelect value={model} onChange={setModel} options={TTS_MODELS} />
              </Field>
              <Field label="Voice">
                {voiceOptions.length ? (
                  <NativeSelect value={voice} onChange={setVoice} options={[{ value: "", label: "Choose…" }, ...voiceOptions]} />
                ) : (
                  <Input value={voice} onChange={(e) => setVoice(e.target.value)} placeholder="voice id (list failed / empty, see below)" />
                )}
              </Field>
              <Field label="Voice type field">
                <Input value={voiceType} onChange={(e) => setVoiceType(e.target.value)} />
              </Field>
            </>
          )}
          <Field label={tts ? `Text (${text.length} chars)` : "Describe the sound"}>
            <Textarea rows={5} value={text} onChange={(e) => setText(e.target.value)} />
          </Field>
          {!tts && (
            <Field label="Duration (s, optional)">
              <Input type="number" min={0.5} max={30} step={0.5} value={duration} onChange={(e) => setDuration(e.target.value)} />
            </Field>
          )}
          <div className="flex items-center gap-3 pt-2">
            <Button
              disabled={busy || !text.trim() || (tts && !voice)}
              onClick={() => create({ kind: "audio", endpoint: tts ? "text_to_speech" : "sound_effect", body, credits_estimated: Number(cost) || null })}
            >
              {busy ? "Sending…" : "Generate"}
            </Button>
            <span className="font-mono text-sm text-muted-foreground">≈ {cost} credits</span>
          </div>
          <details>
            <summary className="cursor-pointer text-xs text-muted-foreground">Request body</summary>
            <Json value={body} className="mt-2" />
          </details>
          <details>
            <summary className="cursor-pointer text-xs text-muted-foreground">Raw /v1/voices response {voices.data && `(${voices.data.status})`}</summary>
            <Json value={voices.data?.body ?? (voices.error as Error)?.message ?? "loading…"} className="mt-2" />
          </details>
        </Panel>
        <div className="space-y-4">
          {error && <ErrorBox>{error}</ErrorBox>}
          {generationId ? (
            <GenerationResult id={generationId} />
          ) : (
            <div className="flex h-40 items-center justify-center rounded-xl border border-dashed text-sm text-muted-foreground">
              Your audio will appear here
            </div>
          )}
          {attempts.length > 0 && <Json value={attempts} />}
        </div>
      </div>
    </AppShell>
  );
}
