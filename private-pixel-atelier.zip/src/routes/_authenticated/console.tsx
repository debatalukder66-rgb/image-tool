import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/studio/AppShell";
import { Field, NativeSelect, Panel } from "@/components/studio/ui";
import { GenerationResult } from "@/components/studio/GenerationResult";
import { ErrorBox, Json } from "@/components/studio/Json";
import { useCreate } from "@/components/studio/useCreate";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useGenerationPoll } from "@/lib/hooks";
import { runwayBalance, runwayVoices } from "@/lib/runway.functions";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/console")({
  head: pageHead("Test Console", "Send raw requests and inspect raw responses."),
  component: ConsolePage,
});

const TEMPLATES: Record<string, object> = {
  text_to_image: { model: "gpt_image_2_5_sunburst", promptText: "a red fox in snow", ratio: "1024:1024", quality: "low" },
  text_to_video: { model: "veo3.1_fast", promptText: "waves at sunset", ratio: "1280:720", duration: 4 },
  image_to_video: { model: "gen4.5", promptText: "slow push in", ratio: "1280:720", duration: 5 },
  text_to_speech: { model: "eleven_multilingual_v2", promptText: "Hello there", voice: { type: "runway-preset", presetId: "" } },
  sound_effect: { model: "eleven_text_to_sound_v2", promptText: "thunder rumble", duration: 3 },
};

function ConsolePage() {
  const [endpoint, setEndpoint] = useState("text_to_image");
  const [custom, setCustom] = useState("");
  const [json, setJson] = useState(JSON.stringify(TEMPLATES["text_to_image"], null, 2));
  const [check, setCheck] = useState<unknown>(null);
  const { create, busy, generationId, attempts, error } = useCreate();
  const balance = useServerFn(runwayBalance);
  const voices = useServerFn(runwayVoices);
  const poll = useGenerationPoll(generationId);
  const ep = custom.trim() || endpoint;

  async function send() {
    let body: Record<string, unknown>;
    try {
      body = JSON.parse(json);
    } catch (e) {
      toast.error(`Invalid JSON: ${(e as Error).message}`);
      return;
    }
    void create({ kind: "tool", endpoint: ep, body });
  }

  return (
    <AppShell>
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" onClick={async () => setCheck({ "GET /v1/organization": await balance().catch((e) => String(e)) })}>
              Check connection
            </Button>
            <Button variant="secondary" onClick={async () => setCheck({ "GET /v1/voices": await voices().catch((e) => String(e)) })}>
              List voices
            </Button>
          </div>
          {check !== null && <Json value={check} />}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Endpoint">
              <NativeSelect
                value={endpoint}
                onChange={(v) => {
                  setEndpoint(v);
                  setJson(JSON.stringify(TEMPLATES[v], null, 2));
                }}
                options={Object.keys(TEMPLATES)}
              />
            </Field>
            <Field label="…or custom path">
              <Input value={custom} onChange={(e) => setCustom(e.target.value)} placeholder="e.g. image_upscale" />
            </Field>
          </div>
          <Field label={`Body → POST /v1/${ep}`}>
            <Textarea rows={14} className="font-mono text-xs" value={json} onChange={(e) => setJson(e.target.value)} />
          </Field>
          <Button onClick={send} disabled={busy}>{busy ? "Sending…" : "Send"}</Button>
        </Panel>
        <div className="space-y-4">
          {error && <ErrorBox>{error}</ErrorBox>}
          {attempts.length > 0 && (
            <Panel className="space-y-2">
              <h3 className="text-sm font-medium">Request / response</h3>
              <Json value={attempts} />
            </Panel>
          )}
          {generationId && (
            <Panel className="space-y-3">
              <h3 className="text-sm font-medium">Polling (every 3s)</h3>
              <GenerationResult id={generationId} />
              <h4 className="text-xs text-muted-foreground">Last raw task responses</h4>
              <Json value={poll.data?.raw ?? "…"} />
              <h4 className="text-xs text-muted-foreground">Generation row</h4>
              <Json value={poll.data?.generation ?? "…"} />
            </Panel>
          )}
        </div>
      </div>
    </AppShell>
  );
}
