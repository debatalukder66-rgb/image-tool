import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Field, Panel } from "@/components/studio/ui";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Set password — Studio" },
      { name: "description", content: "Set the password for your studio account." },
      { property: "og:title", content: "Set password — Studio" },
      { property: "og:description", content: "Set the password for your studio account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPage,
});

function ResetPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState<boolean | null>(null);

  useEffect(() => {
    const hashError = new URLSearchParams(window.location.hash.slice(1)).get("error_description");
    if (hashError) toast.error(hashError);
    const { data } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session) setReady(true);
    });
    supabase.auth.getSession().then(({ data: s }) => {
      if (s.session) setReady(true);
      else setTimeout(() => setReady((r) => r ?? false), 1500);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) { toast.error("Use at least 8 characters"); return; }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) { toast.error(error.message, { duration: 10000 }); return; }
    toast.success("Password saved");
    navigate({ to: "/image" });
  }

  if (ready === false) {
    return (
      <div className="flex min-h-screen items-center justify-center px-4">
        <Panel className="w-full max-w-sm space-y-3 text-center">
          <h1 className="text-lg font-semibold">This link has expired</h1>
          <p className="text-sm text-muted-foreground">Each link works once. Request a new one from the sign-in page and open only the newest email.</p>
          <Button onClick={() => navigate({ to: "/auth" })}>Back to sign in</Button>
        </Panel>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <Panel className="w-full max-w-sm space-y-5">
        <h1 className="text-xl font-semibold">Set your password</h1>
        <form onSubmit={save} className="space-y-4">
          <Field label="New password">
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </Field>
          <Button type="submit" className="w-full" disabled={busy}>Save password</Button>
        </form>
      </Panel>
    </div>
  );
}
