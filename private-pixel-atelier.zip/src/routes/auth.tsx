import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { createAdminAccount, getSetupStatus, sendSetupLink } from "@/lib/runway.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Field, Panel } from "@/components/studio/ui";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — Studio" },
      { name: "description", content: "Sign in to your private generation studio." },
      { property: "og:title", content: "Sign in — Studio" },
      { property: "og:description", content: "Sign in to your private generation studio." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const setup = useServerFn(sendSetupLink);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const statusFn = useServerFn(getSetupStatus);
  const createFn = useServerFn(createAdminAccount);
  const status = useQuery({ queryKey: ["setup-status"], queryFn: () => statusFn() });

  async function createAdmin(ev: React.MouseEvent<HTMLButtonElement>) {
    // Read straight from the inputs so browser autofill is picked up too.
    const form = ev.currentTarget.form!;
    const email = (form.elements.namedItem("email") as HTMLInputElement).value.trim();
    const password = (form.elements.namedItem("password") as HTMLInputElement).value;
    if (!email || password.length < 8) { toast.error("Enter your email and a password (8+ characters)"); return; }
    setBusy(true);
    try {
      const r = await createFn({ data: { email, password } });
      if (!r.ok) { toast.error(r.error ?? "Failed"); return; }
      await status.refetch();
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) { toast.error(error.message); return; }
      toast.success("Admin account created");
      navigate({ to: "/image" });
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }


  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    navigate({ to: "/image" });
  }

  async function sendLink() {
    if (!email) { toast.error("Enter your email first"); return; }
    setBusy(true);
    try {
      const r = await setup({ data: { email, redirectTo: `${window.location.origin}/reset-password` } });
      toast.success(r.message);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <Panel className="w-full max-w-sm space-y-5">
        <div>
          <h1 className="text-xl font-semibold">Studio</h1>
          <p className="text-sm text-muted-foreground">Private access only.</p>
        </div>
        <form onSubmit={signIn} className="space-y-4">
          <Field label="Email">
            <Input name="email" autoComplete="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </Field>
          <Field label="Password">
            <Input name="password" autoComplete="current-password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </Field>
          <Button type="submit" className="w-full" disabled={busy}>Sign in</Button>
          {status.data?.needsSetup && (
            <Button type="button" variant="secondary" className="w-full" disabled={busy} onClick={createAdmin}>
              Create admin account
            </Button>
          )}
        </form>
        <button type="button" onClick={sendLink} disabled={busy} className="w-full text-center text-xs text-muted-foreground underline hover:text-foreground">
          First time / forgot password? Email me a setup link
        </button>
      </Panel>
    </div>
  );
}
