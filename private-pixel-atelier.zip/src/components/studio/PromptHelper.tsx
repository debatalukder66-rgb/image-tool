import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { enhancePrompt, type PromptOption } from "@/lib/prompt.functions";

export function PromptHelper({
  model,
  modelLabel,
  refTags,
  onUse,
  startOpen = false,
}: {
  model: string;
  modelLabel?: string | undefined;
  refTags: string[];
  onUse: (p: string) => void;
  startOpen?: boolean;
}) {
  const [open, setOpen] = useState(startOpen);
  const [idea, setIdea] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [options, setOptions] = useState<PromptOption[]>([]);

  const run = async () => {
    setBusy(true);
    setErr(null);
    try {
      const r = await enhancePrompt({ data: { idea, model, modelLabel, refTags } });
      if (r.ok) setOptions(r.options);
      else setErr(`${r.error} (${r.status})`);
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  if (!open)
    return (
      <Button type="button" variant="outline" size="sm" onClick={() => setOpen(true)}>
        Help me write a prompt
      </Button>
    );

  return (
    <div className={`space-y-2 p-3 ${startOpen ? "" : "rounded-[20px] border"}`}>
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">Prompt helper · tailored to {modelLabel ?? model}</span>
        {!startOpen && (
          <button type="button" className="text-xs text-muted-foreground hover:text-foreground" onClick={() => setOpen(false)}>
            Close
          </button>
        )}
      </div>
      <Textarea rows={2} value={idea} onChange={(e) => setIdea(e.target.value)} placeholder="Rough idea, e.g. cat astronaut, retro poster" />
      <Button type="button" size="sm" disabled={busy || !idea.trim()} onClick={run}>
        {busy ? "Writing…" : options.length ? "Regenerate options" : "Generate options"}
      </Button>
      {err && <p className="text-xs text-destructive">{err}</p>}
      {options.map((o, i) => (
        <div key={i} className="space-y-1 rounded-2xl border bg-muted/40 p-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-sm font-medium">{o.title}</span>
            <Button type="button" size="sm" variant="secondary" onClick={() => onUse(o.prompt)}>
              Use
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">{o.why}</p>
          <p className="text-xs whitespace-pre-wrap">{o.prompt}</p>
        </div>
      ))}
    </div>
  );
}
