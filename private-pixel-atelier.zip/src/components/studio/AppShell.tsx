import { Link, useRouter, useRouterState } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState, type ReactNode } from "react";
import {
  Asterisk,
  BarChart3,
  TriangleAlert,
  AudioLines,
  FlaskConical,
  Home,
  Image as ImageIcon,
  LayoutGrid,
  LogOut,
  RefreshCw,
  Sparkle,
  Terminal,
  Video,
  Wrench,
  ShieldCheck,
  X,
  type LucideIcon,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { runwayBalance } from "@/lib/runway.functions";
import { useSpendLimit } from "@/lib/usage";
import { healthCheck, problems } from "@/lib/setup.functions";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

type NavItem = { to: string; label: string; icon: LucideIcon };
const MAIN: NavItem[] = [
  { to: "/image", label: "Home", icon: Home },
  { to: "/image", label: "Image", icon: ImageIcon },
  { to: "/video", label: "Video", icon: Video },
  { to: "/audio", label: "Audio", icon: AudioLines },
  { to: "/library", label: "Library", icon: LayoutGrid },
  { to: "/usage", label: "Usage", icon: BarChart3 },
];
const TOOLS: NavItem[] = [
  { to: "/model-check", label: "Model Check", icon: FlaskConical },
  { to: "/prompt-lab", label: "Prompt Lab", icon: Sparkle },
  { to: "/console", label: "Test Console", icon: Terminal },
  { to: "/setup-check", label: "Setup Check", icon: ShieldCheck },
  { to: "/later", label: "Coming later", icon: Sparkle },
];
const TITLES: Record<string, { label: string; icon: LucideIcon }> = {
  "/image": { label: "Image", icon: ImageIcon },
  "/video": { label: "Video", icon: Video },
  "/audio": { label: "Audio", icon: AudioLines },
  "/library": { label: "Library", icon: LayoutGrid },
  "/usage": { label: "Usage", icon: BarChart3 },
  "/model-check": { label: "Model Check", icon: FlaskConical },
  "/console": { label: "Test Console", icon: Terminal },
  "/setup-check": { label: "Setup Check", icon: ShieldCheck },
  "/later": { label: "Coming later", icon: Sparkle },
};

function findBalance(body: unknown): number | null {
  if (!body || typeof body !== "object") return null;
  const b = body as Record<string, unknown>;
  for (const k of ["creditBalance", "credit_balance", "credits", "balance"]) {
    if (typeof b[k] === "number") return b[k] as number;
  }
  return null;
}

const railBtn =
  "grid size-12 place-items-center rounded-xl border border-transparent text-muted-foreground transition-all duration-150 hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";
const railActive = { className: "!border-border bg-background !text-foreground shadow-pill" };

function RailLink({ item, exact }: { item: NavItem; exact?: boolean }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Link to={item.to} aria-label={item.label} className={railBtn} activeProps={exact ? {} : railActive}>
          <item.icon className="size-[22px]" strokeWidth={1.75} />
        </Link>
      </TooltipTrigger>
      <TooltipContent side="right">{item.label}</TooltipContent>
    </Tooltip>
  );
}

export function AppShell({ children, fullHeight = false }: { children: ReactNode; fullHeight?: boolean }) {
  const router = useRouter();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const title = TITLES[path] ?? { label: "Studio", icon: Asterisk };
  const balanceFn = useServerFn(runwayBalance);
  const balance = useQuery({ queryKey: ["balance"], queryFn: () => balanceFn(), refetchInterval: 60000 });
  const credits = balance.data?.ok ? findBalance(balance.data.body) : null;
  const total = useQuery({
    queryKey: ["library", "count"],
    queryFn: async () => {
      const { count } = await supabase.from("generations").select("id", { count: "exact", head: true }).is("deleted_at", null);
      return count ?? 0;
    },
  });
  const usedToday = useQuery({
    queryKey: ["library", "usedToday"],
    queryFn: async () => {
      const start = new Date();
      start.setHours(0, 0, 0, 0);
      const { data } = await supabase.from("generations").select("credits_estimated").gte("created_at", start.toISOString());
      return (data ?? []).reduce((n, r) => n + (Number(r.credits_estimated) || 0), 0);
    },
  });
  const spend = useSpendLimit();
  const lim = spend.data?.limit;
  const nearLimit = lim && spend.data ? spend.data.used / lim : 0;
  const [email, setEmail] = useState("");
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? ""));
  }, []);
  const creditText = balance.isLoading ? "…" : credits !== null ? credits.toLocaleString() : "unavailable";
  const healthFn = useServerFn(healthCheck);
  const health = useQuery({ queryKey: ["health"], queryFn: () => healthFn(), staleTime: Infinity, retry: false });
  const missing = problems(health.data);
  const [setupDismissed, setSetupDismissed] = useState(false);
  useEffect(() => setSetupDismissed(sessionStorage.getItem("setup-banner-dismissed") === "1"), []);
  const toolsActive = TOOLS.some((t) => t.to === path);

  const avatar = (
    <Popover>
      <PopoverTrigger asChild>
        <button type="button" aria-label="Account" className="grid size-9 shrink-0 place-items-center rounded-full bg-primary text-xs font-semibold uppercase text-primary-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          {email.slice(0, 1) || "?"}
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-60 space-y-2 rounded-[20px] p-3">
        <p className="truncate text-sm">{email}</p>
        <button
          type="button"
          onClick={async () => {
            await supabase.auth.signOut();
            router.navigate({ to: "/auth" });
          }}
          className="flex w-full items-center gap-2 rounded-xl px-2 py-2 text-sm text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <LogOut className="size-4" /> Sign out
        </button>
      </PopoverContent>
    </Popover>
  );

  return (
    <TooltipProvider delayDuration={150}>
      <div className="min-h-[100dvh] bg-page p-0 sm:p-5">
        <div className="mx-auto flex h-[100dvh] max-w-[1680px] overflow-hidden bg-background sm:h-[calc(100dvh-40px)] sm:rounded-[28px] sm:border sm:shadow-glass">
          {/* Icon rail */}
          <aside className="hidden w-[76px] shrink-0 flex-col items-center gap-2 border-r py-4 md:flex">
            <Link to="/image" aria-label="Studio home" className="mb-3 grid size-11 place-items-center rounded-xl bg-primary text-primary-foreground">
              <Asterisk className="size-6" strokeWidth={2.25} />
            </Link>
            {MAIN.map((n, i) => <RailLink key={n.label} item={n} exact={i === 0} />)}
            <Popover>
              <Tooltip>
                <TooltipTrigger asChild>
                  <PopoverTrigger asChild>
                    <button type="button" aria-label="Tools" className={`${railBtn} ${toolsActive ? "!border-border bg-background !text-foreground shadow-pill" : ""}`}>
                      <Wrench className="size-[22px]" strokeWidth={1.75} />
                    </button>
                  </PopoverTrigger>
                </TooltipTrigger>
                <TooltipContent side="right">Tools</TooltipContent>
              </Tooltip>
              <PopoverContent side="right" align="start" className="w-48 rounded-[20px] p-1.5">
                {TOOLS.map((t) => (
                  <Link key={t.to} to={t.to} className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm text-muted-foreground hover:bg-muted hover:text-foreground" activeProps={{ className: "bg-muted !text-foreground" }}>
                    <t.icon className="size-4" /> {t.label}
                  </Link>
                ))}
              </PopoverContent>
            </Popover>
            <div className="mt-auto flex flex-col items-center gap-3">
              <Tooltip>
                <TooltipTrigger asChild>
                  <button type="button" onClick={() => balance.refetch()} aria-label={`Runway credits: ${creditText}`} className="group/c flex h-8 min-w-12 items-center justify-center rounded-full border px-2 text-[11px] font-semibold tabular-nums transition-all duration-150 hover:bg-muted">
                    {credits !== null ? new Intl.NumberFormat(undefined, { notation: "compact", maximumFractionDigits: 1 }).format(credits) : "—"}
                  </button>
                </TooltipTrigger>
                <TooltipContent side="right">Runway credits: {creditText}</TooltipContent>
              </Tooltip>
              {avatar}
            </div>
          </aside>

          <div className="flex min-w-0 flex-1 flex-col">
            {/* Top bar */}
            <header className="flex h-16 shrink-0 items-center gap-3 border-b px-4 sm:px-6">
              <title.icon className="size-5 shrink-0" strokeWidth={1.75} />
              <h1 className="truncate text-lg font-semibold">{title.label}</h1>
              <span className="size-1 shrink-0 rounded-full bg-subtle-foreground" />
              <span className="shrink-0 rounded-full bg-muted px-2.5 py-0.5 text-xs text-muted-foreground">
                {total.data ?? "…"} generations
              </span>
              <span className="hidden truncate text-[13px] text-subtle-foreground lg:inline">
                Credits used today: {usedToday.data ?? "…"}
              </span>
              <div className="ml-auto flex items-center gap-3">
                <span className="hidden text-sm text-muted-foreground sm:inline">
                  Credits: <span className="font-semibold text-foreground tabular-nums">{creditText}</span>
                </span>
                <button type="button" aria-label="Refresh credits" onClick={() => balance.refetch()} className="grid size-8 place-items-center rounded-xl border text-muted-foreground hover:text-foreground">
                  <RefreshCw className={`size-4 ${balance.isFetching ? "animate-spin" : ""}`} />
                </button>
                {avatar}
              </div>
            </header>
            {missing.length > 0 && !setupDismissed && path !== "/setup-check" && (
              <div className="flex shrink-0 items-center gap-2 border-b bg-destructive/10 px-4 py-2 text-[13px] text-destructive sm:px-6">
                <TriangleAlert className="size-4 shrink-0" />
                <span className="min-w-0 flex-1">
                  Setup incomplete: {missing.join("; ")}.{" "}
                  <Link to="/setup-check" className="font-medium underline">Open Setup Check</Link>
                </span>
                <button type="button" aria-label="Dismiss" onClick={() => { sessionStorage.setItem("setup-banner-dismissed", "1"); setSetupDismissed(true); }} className="grid size-6 place-items-center rounded-lg hover:bg-destructive/10">
                  <X className="size-4" />
                </button>
              </div>
            )}
            {nearLimit >= 0.8 && (
              <Link to="/usage" className={`flex shrink-0 items-center gap-2 border-b px-4 py-2 text-[13px] sm:px-6 ${nearLimit >= 1 ? "bg-destructive/10 text-destructive" : "bg-warning/10 text-warning"}`}>
                <TriangleAlert className="size-4" />
                {nearLimit >= 1 ? "Daily spend limit reached" : "Close to your daily spend limit"}: {spend.data!.used} of {lim} credits used today. Manage on the Usage page.
              </Link>
            )}
            <main className={`relative min-h-0 flex-1 pb-16 md:pb-0 ${fullHeight ? "flex flex-col" : "overflow-y-auto"}`}>
              {fullHeight ? children : <div className="p-4 sm:p-6">{children}</div>}
            </main>
          </div>
        </div>

        {/* Mobile bottom bar */}
        <nav aria-label="Mobile" className="fixed inset-x-0 bottom-0 z-30 flex justify-around border-t bg-background py-2 md:hidden">
          {[...MAIN.slice(1), TOOLS[0]!].map((n) => (
            <Link key={n.to} to={n.to} aria-label={n.label} className="flex flex-col items-center gap-0.5 rounded-xl px-3 py-1 text-[11px] text-muted-foreground" activeProps={{ className: "!text-foreground" }}>
              <n.icon className="size-5" strokeWidth={1.75} /> {n.label}
            </Link>
          ))}
        </nav>
      </div>
    </TooltipProvider>
  );
}
