import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { ImagePlus, Pencil, X } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { fileToDataUri } from "@/lib/image-utils";
import {
  hasDroppable,
  isImageUrl,
  nameFromUrl,
  REORDER_TYPE,
  slugTag,
  sourcesFromDataTransfer,
  urlToBlob,
  type Source,
} from "@/lib/image-input";

export type ImageItem = { id: string; uri: string | null; preview: string | null; tag: string; name: string; status: "loading" | "ready" };

function uniqueTag(base: string, taken: string[], index: number) {
  let t = /^[a-z0-9]+$/.test(base) && base ? base : `ref${index}`;
  let n = 2;
  const root = t;
  while (taken.includes(t)) t = `${root}${n++}`;
  return t;
}

/** One image-input state machine shared by every upload spot. Nothing is uploaded until Generate. */
export function useImageInput({ max = 4, replace = false }: { max?: number; replace?: boolean } = {}) {
  const [items, setItems] = useState<ImageItem[]>([]);
  const itemsRef = useRef(items);
  itemsRef.current = items;

  const update = (id: string, patch: Partial<ImageItem>) =>
    setItems((xs) => xs.map((x) => (x.id === id ? { ...x, ...patch } : x)));

  const addSources = useCallback(
    async (sources: Source[], forcedTag?: string) => {
      if (!sources.length) return;
      let list = sources;
      if (replace) {
        list = sources.slice(0, 1);
        setItems([]);
        itemsRef.current = [];
      }
      const free = max - itemsRef.current.length;
      if (free <= 0) return void toast.error(`Max ${max} reference${max > 1 ? "s" : ""} — remove one first`);
      if (list.length > free) {
        toast.warning(`Only ${free} more allowed (max ${max}); ${list.length - free} ignored`);
        list = list.slice(0, free);
      }
      const taken = itemsRef.current.map((x) => x.tag);
      const fresh: ImageItem[] = list.map((s, i) => {
        const name = s.kind === "file" ? s.file.name || "pasted-image" : nameFromUrl(s.url);
        const tag = uniqueTag(forcedTag && i === 0 ? forcedTag : slugTag(name), taken, itemsRef.current.length + i + 1);
        taken.push(tag);
        const preview = s.kind === "file" ? URL.createObjectURL(s.file) : s.url;
        return { id: crypto.randomUUID(), uri: null, preview, tag, name, status: "loading" };
      });
      itemsRef.current = [...itemsRef.current, ...fresh];
      setItems((xs) => [...xs, ...fresh]);

      await Promise.all(
        list.map(async (s, i) => {
          const it = fresh[i]!;
          try {
            let uri: string;
            if (s.kind === "internal") uri = s.url; // our own signed URL, no re-download
            else uri = await fileToDataUri(s.kind === "file" ? s.file : await urlToBlob(s.url));
            update(it.id, { uri, preview: uri, status: "ready" });
          } catch (e) {
            toast.error(`${it.name}: ${(e as Error).message}`);
            setItems((xs) => xs.filter((x) => x.id !== it.id));
          } finally {
            if (s.kind === "file" && it.preview) URL.revokeObjectURL(it.preview);
          }
        }),
      );
    },
    [max, replace],
  );

  const addFiles = (files: FileList | File[] | null) =>
    addSources(Array.from(files ?? []).map((file) => ({ kind: "file" as const, file })));
  const addUrl = (url: string, internal = false, tag?: string) => addSources([{ kind: internal ? "internal" : "url", url }], tag);
  const addFromDataTransfer = (dt: DataTransfer) => {
    const s = sourcesFromDataTransfer(dt);
    if (!s.length) toast.error("Nothing usable was dropped — drop an image file or image.");
    return addSources(s);
  };

  return {
    items,
    ready: items.filter((x) => x.status === "ready" && x.uri) as (ImageItem & { uri: string })[],
    max,
    full: items.length >= max,
    addFiles,
    addUrl,
    addFromDataTransfer,
    clear: () => setItems([]),
    remove: (id: string) => setItems((xs) => xs.filter((x) => x.id !== id)),
    rename: (id: string, raw: string) => {
      const tag = raw.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20);
      if (!tag) return void toast.error("Tag needs at least one letter or number");
      if (itemsRef.current.some((x) => x.id !== id && x.tag === tag)) return void toast.error(`@${tag} is already used`);
      update(id, { tag });
    },
    move: (from: number, to: number) =>
      setItems((xs) => {
        const c = [...xs];
        const [m] = c.splice(from, 1);
        c.splice(to, 0, m!);
        return c;
      }),
  };
}
export type ImageInput = ReturnType<typeof useImageInput>;

/** Props for a local drop target (prompt bar) + whether something is hovering. */
export function useDropZone(input: ImageInput) {
  const [over, setOver] = useState(false);
  const depth = useRef(0);
  return {
    over,
    props: {
      onDragEnter: (e: React.DragEvent) => {
        if (!hasDroppable(e.dataTransfer)) return;
        depth.current++;
        setOver(true);
      },
      onDragOver: (e: React.DragEvent) => {
        if (!hasDroppable(e.dataTransfer)) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = "copy";
      },
      onDragLeave: () => {
        depth.current = Math.max(0, depth.current - 1);
        if (!depth.current) setOver(false);
      },
      onDrop: (e: React.DragEvent) => {
        if (!hasDroppable(e.dataTransfer)) return;
        e.preventDefault();
        e.stopPropagation();
        depth.current = 0;
        setOver(false);
        window.dispatchEvent(new Event("studio-drop-done"));
        input.addFromDataTransfer(e.dataTransfer);
      },
    },
  };
}

/** Full-window overlay; dropping anywhere adds to the active generator. Esc closes. */
export function GlobalDropOverlay({ input, label = "Drop images to add as references" }: { input: ImageInput; label?: string }) {
  const [show, setShow] = useState(false);
  const inputRef = useRef(input);
  inputRef.current = input;
  useEffect(() => {
    let depth = 0;
    const hide = () => { depth = 0; setShow(false); };
    const enter = (e: DragEvent) => { if (hasDroppable(e.dataTransfer)) { depth++; setShow(true); } };
    const leave = () => { depth = Math.max(0, depth - 1); if (!depth) setShow(false); };
    const over = (e: DragEvent) => { if (hasDroppable(e.dataTransfer)) e.preventDefault(); };
    const drop = (e: DragEvent) => {
      const dt = e.dataTransfer;
      hide();
      if (!dt || !hasDroppable(dt)) return;
      e.preventDefault();
      inputRef.current.addFromDataTransfer(dt);
    };
    const key = (e: KeyboardEvent) => e.key === "Escape" && hide();
    window.addEventListener("dragenter", enter);
    window.addEventListener("dragleave", leave);
    window.addEventListener("dragover", over);
    window.addEventListener("drop", drop);
    window.addEventListener("dragend", hide);
    window.addEventListener("keydown", key);
    window.addEventListener("studio-drop-done", hide);
    return () => {
      window.removeEventListener("dragenter", enter);
      window.removeEventListener("dragleave", leave);
      window.removeEventListener("dragover", over);
      window.removeEventListener("drop", drop);
      window.removeEventListener("dragend", hide);
      window.removeEventListener("keydown", key);
      window.removeEventListener("studio-drop-done", hide);
    };
  }, []);
  if (!show) return null;
  return (
    <div role="status" aria-live="polite" className="pointer-events-none fixed inset-0 z-[60] grid place-items-center bg-background/70 p-6 backdrop-blur-sm">
      <div className="grid size-full place-items-center rounded-[28px] border-2 border-dashed border-foreground/40">
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="grid size-14 place-items-center rounded-2xl bg-muted"><ImagePlus className="size-6" /></div>
          <p className="text-lg font-semibold">{label}</p>
          <p className="text-sm text-muted-foreground">{input.items.length}/{input.max} used · JPEG, PNG, WebP</p>
        </div>
      </div>
    </div>
  );
}

/**
 * Paste images (Ctrl/Cmd+V) into the prompt box, or anywhere when no other field is focused.
 * Plain text pastes normally; an image link offers to import.
 */
export function usePasteImages(input: ImageInput, promptRef: React.RefObject<HTMLElement | null>) {
  const inputRef = useRef(input);
  inputRef.current = input;
  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      const t = e.target as HTMLElement | null;
      const inPrompt = !!promptRef.current && t === promptRef.current;
      const editable = t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable);
      if (!inPrompt && editable) return;
      const cd = e.clipboardData;
      if (!cd) return;
      const files = Array.from(cd.items).filter((i) => i.kind === "file" && i.type.startsWith("image/")).map((i) => i.getAsFile()).filter(Boolean) as File[];
      if (files.length) {
        e.preventDefault();
        inputRef.current.addFiles(files);
        return;
      }
      const text = cd.getData("text/plain").trim();
      if (text && isImageUrl(text) && /\.(jpe?g|png|webp|gif|avif)(\?|$)/i.test(text)) {
        toast("Add this image as reference?", {
          description: text.length > 60 ? text.slice(0, 60) + "…" : text,
          action: { label: "Add", onClick: () => inputRef.current.addUrl(text) },
        });
      } else if (!inPrompt && !text && cd.types.length) {
        toast.error("The clipboard has no image. Copy an image or screenshot and try again.");
      }
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, [promptRef]);
}

/** Thumbnails with shimmer, remove, editable @tag chip, preview and drag-to-reorder. */
export function ImageTray({ input, onInsertTag, showTags = true }: { input: ImageInput; onInsertTag?: (tag: string) => void; showTags?: boolean }) {
  const [preview, setPreview] = useState<string | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [dragFrom, setDragFrom] = useState<number | null>(null);
  if (!input.items.length) return null;
  return (
    <>
      <div className="mb-2 flex flex-wrap items-end gap-2.5">
        {input.items.map((it, i) => (
          <div
            key={it.id}
            draggable={it.status === "ready"}
            onDragStart={(e) => { e.dataTransfer.setData(REORDER_TYPE, String(i)); e.dataTransfer.effectAllowed = "move"; setDragFrom(i); }}
            onDragOver={(e) => { if (e.dataTransfer.types.includes(REORDER_TYPE)) { e.preventDefault(); e.stopPropagation(); } }}
            onDrop={(e) => {
              if (!e.dataTransfer.types.includes(REORDER_TYPE)) return;
              e.preventDefault();
              e.stopPropagation();
              if (dragFrom !== null && dragFrom !== i) input.move(dragFrom, i);
              setDragFrom(null);
            }}
            onDragEnd={() => setDragFrom(null)}
            className={`flex flex-col items-center gap-1 ${dragFrom === i ? "opacity-40" : ""}`}
          >
            <div className="relative">
              <button
                type="button"
                aria-label={`Preview ${it.name}`}
                disabled={it.status !== "ready"}
                onClick={() => setPreview(it.uri)}
                className="relative block size-14 overflow-hidden rounded-[14px] border bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {it.preview && <img src={it.preview} alt={it.name} className="size-full object-cover" draggable={false} />}
                {it.status === "loading" && <span className="absolute inset-0 animate-pulse bg-background/60" />}
              </button>
              <button
                type="button"
                aria-label={`Remove ${it.name}`}
                onClick={() => input.remove(it.id)}
                className="absolute -right-1.5 -top-1.5 grid size-5 place-items-center rounded-full border bg-background shadow-sm hover:bg-muted"
              >
                <X className="size-3" />
              </button>
            </div>
            {showTags && (editing === it.id ? (
              <input
                autoFocus
                aria-label={`Rename tag for ${it.name}`}
                defaultValue={it.tag}
                onBlur={(e) => { input.rename(it.id, e.target.value); setEditing(null); }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                  if (e.key === "Escape") setEditing(null);
                }}
                className="h-6 w-16 rounded-full border bg-background px-2 text-[11px] outline-none focus:ring-2 focus:ring-ring"
              />
            ) : (
              <div className="flex items-center rounded-full bg-muted text-[11px]">
                <button type="button" title="Insert into prompt" onClick={() => onInsertTag?.(it.tag)} className="rounded-l-full py-0.5 pl-2 pr-1 font-medium hover:bg-foreground/10">
                  @{it.tag}
                </button>
                <button type="button" aria-label={`Rename @${it.tag}`} onClick={() => setEditing(it.id)} className="rounded-r-full py-1 pl-0.5 pr-1.5 text-muted-foreground hover:bg-foreground/10">
                  <Pencil className="size-2.5" />
                </button>
              </div>
            ))}
          </div>
        ))}
        <span className="mb-1 ml-1 rounded-full bg-muted px-2 py-0.5 text-[11px] tabular-nums text-muted-foreground">{input.items.length}/{input.max}</span>
      </div>
      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="max-w-4xl rounded-[24px] p-2">
          <DialogTitle className="sr-only">Reference preview</DialogTitle>
          {preview && <img src={preview} alt="Reference" className="max-h-[85vh] w-full rounded-[18px] object-contain" />}
        </DialogContent>
      </Dialog>
    </>
  );
}
