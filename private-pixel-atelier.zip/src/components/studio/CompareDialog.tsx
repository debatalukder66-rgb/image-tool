import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Check, Columns2, Loader2, Star } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { FINAL, runwayCreate, runwayStatus } from "@/lib/runway.functions";
import { baseImageConfig, IMAGE_MODELS, imageCost, summarizeRunwayError } from "@/lib/catalog";
import { GenerationResult } from "./GenerationResult";

type Run = { model: string; status: string; id?: string; ms?: number; credits: number; error?: string | undefined };
const maxCost = (c: string) => Number(c.split("–").pop()) || 0;

export function CompareDialog({
  open,
  onOpenChange,
  prompt,
  refs,
  quality,
  fallbackRatio,
  provenRatios,
  onDefault,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  prompt: string;
  refs: { uri: string; tag: string }[];
  quality: string;
  fallbackRatio: string;
  provenRatios: Record<string, string[] | undefined>;
  onDefault: (model: string) => void;
}) {
  const create = useServerFn(runwayCreate);
  const status = useServerFn(runwayStatus);
  const qc = useQueryClient();
  const [picked, setPicked] = useState<string[]>([]);
  const [parallel, setParallel] = useState(false);
  const [runs, setRuns] = useState<Run[]>([]);
  const [kept, setKept] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);

  const plan = picked.map((m) => {
    const cfg = baseImageConfig(m);
    const ratio = provenRatios[m]?.[0] ?? cfg.ratios?.[0] ?? fallbackRatio;
    const q = cfg.qualities.length ? (cfg.qualities.includes(quality) ? quality : cfg.qualities[0]!) : undefined;
    const body: Record<string, unknown> = { model: m, promptText: prompt, ratio };
    if (refs.length) body["referenceImages"] = refs;
    if (q) body["quality"] = q;
    return { model: m, body, credits: maxCost(imageCost(m, "1K", q ?? "medium", refs.length, 1)) };
  });
  const total = plan.reduce((n, p) => n + p.credits, 0);
  const label = (m: string) => IMAGE_MODELS.find((x) => x.id === m)?.label ?? m;
  const set = (m: string, patch: Partial<Run>) => setRuns((rs) => rs.map((r) => (r.model === m ? { ...r, ...patch } : r)));

  async function runOne(p: (typeof plan)[number]) {
    const t0 = performance.now();
    set(p.model, { status: "SENDING" });
    const r = await create({ data: { kind: "image", endpoint: "text_to_image", body: p.body, credits_estimated: p.credits } });
    if (!r.ok) {
      const last = r.attempts[r.attempts.length - 1];
      return set(p.model, { status: "FAILED", error: last ? summarizeRunwayError(last.status, last.response) : r.error, ms: performance.now() - t0 });
    }
    set(p.model, { id: r.generation_id, status: "PENDING" });
    // Poll until final; THROTTLED just means Runway queued it, so keep waiting.
    for (;;) {
      await new Promise((res) => setTimeout(res, 3000));
      try {
        const s = await status({ data: { generation_id: r.generation_id } });
        set(p.model, { status: s.generation.status, error: s.generation.error ?? undefined });
        if (FINAL.includes(s.generation.status)) break;
      } catch (e) {
        set(p.model, { status: "FAILED", error: (e as Error).message });
        break;
      }
    }
    set(p.model, { ms: performance.now() - t0 });
  }

  async function start() {
    if (picked.length < 2) return void toast.error("Pick 2–4 models");
    if (!prompt.trim()) return void toast.error("Write a prompt first");
    if (!confirm(`Run ${picked.length} models (${parallel ? "in parallel" : "one after another"})?\nEstimated cost: about ${total} credits.`)) return;
    setBusy(true);
    setKept(new Set());
    setRuns(plan.map((p) => ({ model: p.model, status: "WAITING", credits: p.credits })));
    if (parallel) await Promise.all(plan.map(runOne));
    else for (const p of plan) await runOne(p);
    setBusy(false);
    qc.invalidateQueries({ queryKey: ["library"] });
  }

  async function close(o: boolean) {
    if (o) return onOpenChange(true);
    if (busy && !confirm("Models are still running. Close anyway? They'll finish in the background and show in your list.")) return;
    const discard = runs.filter((r) => r.id && !kept.has(r.id)).map((r) => r.id!);
    if (discard.length && !busy) {
      await supabase.from("generations").update({ deleted_at: new Date().toISOString() }).in("id", discard);
      toast.info(`${discard.length} result(s) not kept were moved to Trash`);
      qc.invalidateQueries({ queryKey: ["library"] });
    }
    setRuns([]);
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={close}>
      <DialogContent className="max-h-[92vh] max-w-6xl overflow-y-auto rounded-[24px]">
        <DialogTitle className="flex items-center gap-2"><Columns2 className="size-5" /> Compare models</DialogTitle>
        <p className="line-clamp-2 text-sm text-muted-foreground">Prompt: {prompt || "(empty)"}</p>
        <div className="flex flex-wrap gap-1.5">
          {IMAGE_MODELS.map((m) => {
            const on = picked.includes(m.id);
            return (
              <button
                key={m.id}
                type="button"
                disabled={busy || (!on && picked.length >= 4)}
                onClick={() => setPicked(on ? picked.filter((x) => x !== m.id) : [...picked, m.id])}
                className={`rounded-full border px-3 py-1.5 text-[13px] transition disabled:opacity-40 ${on ? "border-foreground bg-primary text-primary-foreground" : "hover:bg-muted"}`}
              >
                {m.label}
              </button>
            );
          })}
        </div>
        <div className="flex flex-wrap items-center gap-3 text-sm">
          <label className="flex items-center gap-2"><input type="checkbox" checked={parallel} onChange={(e) => setParallel(e.target.checked)} disabled={busy} className="accent-primary" /> Run in parallel</label>
          <span className="text-muted-foreground">{picked.length}/4 picked · ≈ {total} credits</span>
          <button type="button" onClick={start} disabled={busy || picked.length < 2} className="ml-auto inline-flex h-9 items-center gap-2 rounded-full bg-primary px-4 text-primary-foreground disabled:opacity-40">
            {busy && <Loader2 className="size-4 animate-spin" />} Start compare
          </button>
        </div>
        {runs.length > 0 && (
          <div className={`grid gap-4 ${runs.length > 2 ? "lg:grid-cols-4 sm:grid-cols-2" : "sm:grid-cols-2"}`}>
            {runs.map((r) => (
              <div key={r.model} className="space-y-2 rounded-[20px] border p-3">
                <div className="flex items-center gap-2">
                  <p className="min-w-0 flex-1 truncate font-semibold">{label(r.model)}</p>
                  <span className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${r.status === "SUCCEEDED" ? "bg-info/15 text-info" : r.status === "FAILED" ? "bg-destructive/15 text-destructive" : "bg-warning/15 text-warning"}`}>{r.status.toLowerCase()}</span>
                </div>
                <p className="text-[13px] text-muted-foreground">
                  {r.ms != null ? `${(r.ms / 1000).toFixed(1)}s` : "…"} · ≈ {r.credits} credits
                </p>
                {r.id ? <GenerationResult id={r.id} /> : <div className="grid aspect-square place-items-center rounded-[16px] bg-muted text-[13px] text-muted-foreground">{r.status === "WAITING" ? "Waiting" : r.error ? "" : "Sending…"}</div>}
                {r.error && <p className="text-[13px] text-destructive">{r.error}</p>}
                {r.id && r.status === "SUCCEEDED" && (
                  <div className="flex gap-2">
                    <button type="button" onClick={() => setKept((k) => new Set(k).add(r.id!))} disabled={kept.has(r.id)} className="inline-flex h-8 flex-1 items-center justify-center gap-1.5 rounded-full border text-[13px] hover:bg-muted disabled:opacity-60">
                      <Check className="size-3.5" /> {kept.has(r.id) ? "Kept" : "Keep"}
                    </button>
                    <button type="button" onClick={() => onDefault(r.model)} className="inline-flex h-8 flex-1 items-center justify-center gap-1.5 rounded-full border text-[13px] hover:bg-muted">
                      <Star className="size-3.5" /> Use as default
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
        {runs.length > 0 && !busy && <p className="text-[13px] text-muted-foreground">Results you don't keep go to Trash when you close this window.</p>}
      </DialogContent>
    </Dialog>
  );
}
