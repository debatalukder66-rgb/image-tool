import { dragImageProps } from "@/lib/image-input";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Copy, Download, ImagePlus, Clapperboard, Maximize2 } from "lucide-react";
import { useGenerationPoll, useSignedUrls } from "@/lib/hooks";
import { mediaType } from "@/lib/catalog";
import { handoff } from "@/lib/image-utils";
import { ErrorBox } from "./Json";

export function StatusBadge({ status }: { status: string }) {
  const tone =
    status === "SUCCEEDED"
      ? "bg-info/10 text-info"
      : status === "FAILED" || status === "CANCELLED"
        ? "bg-destructive/10 text-destructive"
        : "bg-warning/15 text-warning";
  const label = status.charAt(0) + status.slice(1).toLowerCase();
  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${tone}`}>{label}</span>;
}

function IconBtn({ label, onClick, href, children }: { label: string; onClick?: () => void; href?: string; children: React.ReactNode }) {
  const cls = "grid size-8 place-items-center rounded-full bg-background/90 text-foreground shadow-pill transition hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";
  return href ? (
    <a href={href} aria-label={label} title={label} className={cls}>{children}</a>
  ) : (
    <button type="button" aria-label={label} title={label} onClick={onClick} className={cls}>{children}</button>
  );
}

export function MediaGrid({
  paths,
  onUseAsRef,
  prompt,
  onOpen,
  large = false,
}: {
  paths: string[];
  onUseAsRef?: ((url: string) => void) | undefined;
  prompt?: string | undefined;
  onOpen?: ((url: string, urls?: string[]) => void) | undefined;
  large?: boolean;
}) {
  const urls = useSignedUrls(paths);
  const navigate = useNavigate();
  if (!paths.length) return null;
  const all = paths.map((x) => urls.data?.[x]).filter((u): u is string => !!u && mediaType(paths[0]!) === "image");
  return (
    <div className={`grid gap-3 ${paths.length > 1 ? "grid-cols-2" : ""}`}>
      {paths.map((p) => {
        const url = urls.data?.[p];
        const type = mediaType(p);
        return (
          <div key={p} className={`group relative overflow-hidden border bg-card ${large ? "rounded-[20px] shadow-glass" : "rounded-[18px]"}`}>
            {!url ? (
              <div className="aspect-square animate-pulse bg-muted" />
            ) : type === "image" ? (
              <img
                {...dragImageProps(url)}
                src={url}
                alt={prompt || "Generated output"}
                onClick={onOpen ? () => onOpen(url, all) : undefined}
                className={`w-full ${large ? `${paths.length > 1 ? "max-h-[38vh] min-h-[20vh]" : "max-h-[60vh] min-h-[40vh]"} cursor-zoom-in bg-muted object-contain` : ""}`}
              />
            ) : type === "video" ? (
              <video src={url} controls className="w-full" />
            ) : type === "audio" ? (
              <audio src={url} controls className="w-full p-3" />
            ) : (
              <a href={url} className="block p-3 text-sm underline">Open file</a>
            )}
            {url && (
              <div className="absolute right-2 top-2 flex gap-1.5 opacity-0 transition-opacity duration-150 focus-within:opacity-100 group-hover:opacity-100">
                {type === "image" && onOpen && (
                  <IconBtn label="View larger" onClick={() => onOpen(url, all)}><Maximize2 className="size-3.5" /></IconBtn>
                )}
                <IconBtn label="Download" href={`${url}&download=`}><Download className="size-3.5" /></IconBtn>
                {type === "image" && (
                  <>
                    <IconBtn
                      label="Use as reference"
                      onClick={() => {
                        if (onUseAsRef) onUseAsRef(url);
                        else {
                          handoff.set("ref", url);
                          navigate({ to: "/image" });
                        }
                        toast.success("Added as reference");
                      }}
                    >
                      <ImagePlus className="size-3.5" />
                    </IconBtn>
                    <IconBtn
                      label="Make video from this"
                      onClick={() => {
                        handoff.set("videoStart", url);
                        navigate({ to: "/video" });
                      }}
                    >
                      <Clapperboard className="size-3.5" />
                    </IconBtn>
                  </>
                )}
                {prompt && (
                  <IconBtn label="Copy prompt" onClick={() => { navigator.clipboard.writeText(prompt); toast.success("Prompt copied"); }}>
                    <Copy className="size-3.5" />
                  </IconBtn>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

const FINAL_S = ["SUCCEEDED", "FAILED", "CANCELLED"];

export function GenerationResult({
  id,
  onUseAsRef,
  expected = 1,
  onOpen,
  large = false,
}: {
  id: string;
  onUseAsRef?: ((url: string) => void) | undefined;
  expected?: number;
  onOpen?: ((url: string, urls?: string[]) => void) | undefined;
  large?: boolean;
}) {
  const q = useGenerationPoll(id);
  const g = q.data?.generation;
  const status = g?.status ?? "PENDING";
  const running = !FINAL_S.includes(status);
  const params = (g?.params ?? {}) as { body?: Record<string, unknown>; count?: number };
  const prompt = String(params.body?.["promptText"] ?? params.body?.["text"] ?? "");
  const n = Math.max(1, Math.min(4, params.count ?? expected));
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3 text-sm">
        <StatusBadge status={status} />
        {running && (
          <span className="text-muted-foreground">
            {status === "THROTTLED" ? "Queued at Runway…" : status === "PENDING" ? "Pending…" : "Running…"}{" "}
            {q.data?.progress ? `${Math.round(q.data.progress * 100)}%` : ""}
          </span>
        )}
        <span className="ml-auto font-mono text-xs text-muted-foreground">{id.slice(0, 8)}</span>
      </div>
      {q.error && <ErrorBox>Polling failed: {(q.error as Error).message}</ErrorBox>}
      {g?.error && <ErrorBox details={g.task_statuses}>{g.error}</ErrorBox>}
      {running && !(g?.output_paths ?? []).length ? (
        <div className={`grid gap-3 ${n > 1 ? "grid-cols-2" : ""}`}>
          {Array.from({ length: n }, (_, i) => (
            <div key={i} className={`animate-pulse rounded-[20px] bg-muted ${large && n === 1 ? "h-[50vh]" : "aspect-square"}`} />
          ))}
        </div>
      ) : (
        <MediaGrid paths={g?.output_paths ?? []} onUseAsRef={onUseAsRef} prompt={prompt} onOpen={onOpen} large={large} />
      )}
    </div>
  );
}
