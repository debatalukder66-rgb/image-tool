import { Asterisk } from "lucide-react";
import type { ReactNode } from "react";

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

export function NativeSelect({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: (string | { value: string; label: string })[];
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="h-9 w-full rounded-xl border bg-background px-3 text-sm outline-none transition focus:ring-2 focus:ring-ring"
    >
      {options.map((o) => {
        const v = typeof o === "string" ? o : o.value;
        const l = typeof o === "string" ? o : o.label;
        return (
          <option key={v} value={v} className="bg-popover">
            {l}
          </option>
        );
      })}
    </select>
  );
}

export function Segmented<T extends string | number>({
  value,
  onChange,
  options,
  labels,
}: {
  value: T;
  onChange: (v: T) => void;
  options: T[];
  labels?: Partial<Record<string, ReactNode>>;
}) {
  return (
    <div className="inline-flex rounded-full border bg-muted/70 p-0.5">
      {options.map((o) => (
        <button
          key={String(o)}
          type="button"
          aria-pressed={o === value}
          onClick={() => onChange(o)}
          className={`rounded-full px-3 py-1 text-sm capitalize transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${o === value ? "bg-background text-foreground shadow-pill" : "text-muted-foreground hover:text-foreground"}`}
        >
          {labels?.[String(o)] ?? o}
        </button>
      ))}
    </div>
  );
}

export function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-[20px] border bg-card p-4 shadow-sm ${className}`}>{children}</div>;
}

/** Dark tile logo with asterisk; pulses while generating. */
export function StarLogo({ size = 40, pulsing = false }: { size?: number; pulsing?: boolean }) {
  return (
    <span aria-hidden style={{ width: size, height: size }} className={`grid place-items-center rounded-[30%] bg-primary text-primary-foreground ${pulsing ? "star-pulse" : ""}`}>
      <Asterisk style={{ width: size * 0.55, height: size * 0.55 }} strokeWidth={2.25} />
    </span>
  );
}
