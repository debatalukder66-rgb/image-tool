import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Bookmark, BookmarkPlus, History, Palette, Pencil, Plus, Search, Trash2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { GENERATIONS_QUERY, fetchGenerations, promptOf } from "./Workspace";

const pill =
  "inline-flex h-9 items-center gap-1.5 rounded-xl border bg-background px-3 text-sm transition-all duration-150 hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";

type Saved = { id: string; title: string; prompt: string; model: string | null; settings: unknown; created_at: string };

/** "Prompts" popover: recent prompts (from generations) + saved prompts, search, insert, save current. */
export function PromptsPopover({
  prompt,
  model,
  settings,
  onInsert,
}: {
  prompt: string;
  model: string;
  settings: Record<string, unknown>;
  onInsert: (p: string) => void;
}) {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const gens = useQuery({ queryKey: GENERATIONS_QUERY, queryFn: fetchGenerations, enabled: open });
  const saved = useQuery({
    queryKey: ["saved-prompts"],
    enabled: open,
    queryFn: async () => {
      const { data, error } = await supabase.from("saved_prompts").select("*").order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return data as Saved[];
    },
  });
  const recent = useMemo(() => {
    const seen = new Set<string>();
    const out: string[] = [];
    for (const g of gens.data ?? []) {
      const p = promptOf(g).trim();
      if (p && !seen.has(p)) { seen.add(p); out.push(p); }
      if (out.length >= 30) break;
    }
    return out;
  }, [gens.data]);
  const match = (s: string) => !q.trim() || s.toLowerCase().includes(q.toLowerCase());

  async function saveCurrent() {
    if (!prompt.trim()) return void toast.info("Type a prompt first");
    const title = window.prompt("Name this prompt", prompt.slice(0, 40))?.trim();
    if (!title) return;
    const { error } = await supabase.from("saved_prompts").insert({ title, prompt, model, settings: settings as never });
    if (error) return void toast.error(error.message);
    toast.success("Prompt saved");
    qc.invalidateQueries({ queryKey: ["saved-prompts"] });
  }
  async function del(id: string) {
    const { error } = await supabase.from("saved_prompts").delete().eq("id", id);
    if (error) return void toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["saved-prompts"] });
  }
  const use = (p: string) => { onInsert(p); setOpen(false); };

  return (
    <>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button type="button" className={pill}><History className="size-4" /> Prompts</button>
        </PopoverTrigger>
        <PopoverContent align="start" className="w-[380px] rounded-[20px] p-0">
          <label className="flex items-center gap-2 border-b px-3 py-2.5">
            <Search className="size-4 text-muted-foreground" />
            <input autoFocus aria-label="Search prompts" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search prompts" className="flex-1 bg-transparent text-sm outline-none" />
          </label>
          <div className="max-h-[420px] overflow-y-auto p-2">
            <p className="px-2 pb-1 pt-1 text-[11px] font-semibold uppercase tracking-wide text-subtle-foreground">Saved</p>
            {(saved.data ?? []).filter((s) => match(s.title + " " + s.prompt)).map((s) => (
              <div key={s.id} className="group flex items-start gap-2 rounded-xl px-2 py-2 hover:bg-muted">
                <button type="button" onClick={() => use(s.prompt)} className="min-w-0 flex-1 text-left">
                  <p className="truncate text-sm font-medium">{s.title}</p>
                  <p className="line-clamp-2 text-[13px] text-muted-foreground">{s.prompt}</p>
                </button>
                <button type="button" aria-label={`Delete saved prompt ${s.title}`} onClick={() => del(s.id)} className="opacity-0 transition group-hover:opacity-100 focus:opacity-100">
                  <Trash2 className="size-3.5 text-muted-foreground hover:text-destructive" />
                </button>
              </div>
            ))}
            {saved.data?.length === 0 && <p className="px-2 py-1 text-[13px] text-muted-foreground">No saved prompts yet — use the bookmark button.</p>}
            <p className="px-2 pb-1 pt-3 text-[11px] font-semibold uppercase tracking-wide text-subtle-foreground">Recent</p>
            {recent.filter(match).map((p) => (
              <button key={p} type="button" onClick={() => use(p)} className="block w-full rounded-xl px-2 py-2 text-left text-[13px] hover:bg-muted">
                <span className="line-clamp-2">{p}</span>
              </button>
            ))}
            {gens.data && recent.length === 0 && <p className="px-2 py-1 text-[13px] text-muted-foreground">No prompts yet.</p>}
          </div>
        </PopoverContent>
      </Popover>
      <button type="button" aria-label="Save current prompt" title="Save prompt" onClick={saveCurrent} className="grid size-9 place-items-center rounded-xl border bg-background transition hover:bg-muted">
        <BookmarkPlus className="size-4" />
      </button>
    </>
  );
}

export type Style = { id: string; name: string; phrase: string; builtin?: boolean };
export const BUILTIN_STYLES: Style[] = [
  { id: "b-cinematic", name: "Cinematic", phrase: "cinematic film still, dramatic lighting, shallow depth of field, anamorphic lens, rich color grading", builtin: true },
  { id: "b-anime", name: "Anime", phrase: "anime style, clean cel shading, expressive characters, vibrant colors, detailed background art", builtin: true },
  { id: "b-product", name: "Product photo", phrase: "professional product photography, seamless studio backdrop, softbox lighting, crisp focus, commercial catalog look", builtin: true },
  { id: "b-portrait", name: "Studio portrait", phrase: "studio portrait, 85mm lens, soft key light with rim light, neutral backdrop, natural skin texture", builtin: true },
  { id: "b-watercolor", name: "Watercolor", phrase: "watercolor painting, soft washes, visible paper texture, gentle bleeding edges, pastel palette", builtin: true },
  { id: "b-3d", name: "3D render", phrase: "3D render, octane style, global illumination, smooth materials, high detail", builtin: true },
  { id: "b-noir", name: "Film noir", phrase: "film noir, black and white, high contrast, hard shadows, venetian blind light, 1940s mood", builtin: true },
  { id: "b-flat", name: "Minimal flat", phrase: "minimal flat illustration, simple geometric shapes, limited color palette, clean vector look", builtin: true },
];

export const combinePrompt = (prompt: string, style: Style | null) =>
  style ? `${prompt.trim().replace(/[.,\s]+$/, "")}${prompt.trim() ? ", " : ""}${style.phrase}` : prompt;

/** "Styles" popover: built-in + own presets (create/edit/delete). One active style is appended at Generate. */
export function StylesPopover({ active, onChange }: { active: Style | null; onChange: (s: Style | null) => void }) {
  const qc = useQueryClient();
  const [editing, setEditing] = useState<{ id?: string; name: string; phrase: string } | null>(null);
  const mine = useQuery({
    queryKey: ["style-presets"],
    queryFn: async () => {
      const { data, error } = await supabase.from("style_presets").select("id, name, phrase").order("created_at");
      if (error) throw new Error(error.message);
      return data as Style[];
    },
  });
  async function save() {
    if (!editing?.name.trim() || !editing.phrase.trim()) return void toast.error("Give the style a name and a phrase");
    const row = { name: editing.name.trim(), phrase: editing.phrase.trim() };
    const { error } = editing.id
      ? await supabase.from("style_presets").update(row).eq("id", editing.id)
      : await supabase.from("style_presets").insert(row);
    if (error) return void toast.error(error.message);
    if (editing.id && active?.id === editing.id) onChange({ id: editing.id, ...row });
    setEditing(null);
    qc.invalidateQueries({ queryKey: ["style-presets"] });
  }
  async function remove(id: string) {
    if (!confirm("Delete this style?")) return;
    const { error } = await supabase.from("style_presets").delete().eq("id", id);
    if (error) return void toast.error(error.message);
    if (active?.id === id) onChange(null);
    qc.invalidateQueries({ queryKey: ["style-presets"] });
  }
  const chip = (s: Style) => (
    <div key={s.id} className={`group flex items-center rounded-full border text-[13px] ${active?.id === s.id ? "border-foreground bg-primary text-primary-foreground" : "hover:bg-muted"}`}>
      <button type="button" title={s.phrase} onClick={() => onChange(active?.id === s.id ? null : s)} className="py-1.5 pl-3 pr-2">{s.name}</button>
      {!s.builtin && (
        <>
          <button type="button" aria-label={`Edit ${s.name}`} onClick={() => setEditing({ id: s.id, name: s.name, phrase: s.phrase })} className="pr-1"><Pencil className="size-3" /></button>
          <button type="button" aria-label={`Delete ${s.name}`} onClick={() => remove(s.id)} className="pr-2"><Trash2 className="size-3" /></button>
        </>
      )}
    </div>
  );
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button type="button" className={`${pill} ${active ? "border-foreground" : ""}`}>
          <Palette className="size-4" /> {active ? active.name : "Styles"}
          {active && (
            <span role="button" tabIndex={0} aria-label="Clear style" onClick={(e) => { e.stopPropagation(); onChange(null); }} className="-mr-1 rounded-full p-0.5 hover:bg-muted"><X className="size-3" /></span>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-[380px] space-y-3 rounded-[20px]">
        <div>
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-subtle-foreground">Built-in</p>
          <div className="flex flex-wrap gap-1.5">{BUILTIN_STYLES.map(chip)}</div>
        </div>
        <div>
          <div className="mb-2 flex items-center">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-subtle-foreground">My styles</p>
            <button type="button" onClick={() => setEditing({ name: "", phrase: "" })} className="ml-auto inline-flex items-center gap-1 text-[13px] text-muted-foreground hover:text-foreground"><Plus className="size-3.5" /> New</button>
          </div>
          <div className="flex flex-wrap gap-1.5">{(mine.data ?? []).map(chip)}</div>
          {mine.data?.length === 0 && !editing && <p className="text-[13px] text-muted-foreground">None yet.</p>}
        </div>
        {editing && (
          <div className="space-y-2 rounded-[16px] border p-3">
            <input aria-label="Style name" autoFocus value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} placeholder="Name" className="h-9 w-full rounded-xl border px-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
            <textarea aria-label="Style phrase" value={editing.phrase} onChange={(e) => setEditing({ ...editing, phrase: e.target.value })} placeholder="Phrase appended to the prompt" rows={3} className="w-full resize-none rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring" />
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setEditing(null)} className="h-8 rounded-full px-3 text-sm text-muted-foreground hover:bg-muted">Cancel</button>
              <button type="button" onClick={save} className="inline-flex h-8 items-center gap-1.5 rounded-full bg-primary px-3 text-sm text-primary-foreground"><Bookmark className="size-3.5" /> Save</button>
            </div>
          </div>
        )}
        {active && <p className="rounded-xl bg-muted px-3 py-2 text-[13px] text-muted-foreground">Adds: “{active.phrase}”</p>}
      </PopoverContent>
    </Popover>
  );
}
