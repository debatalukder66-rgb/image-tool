import { dragImageProps } from "@/lib/image-input";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  ArrowLeft,
  AudioLines,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Clapperboard,
  Copy,
  Download,
  Filter,
  FolderInput,
  FolderPlus,
  ImagePlus,
  Pencil,
  Shuffle,
  Undo2,
  Image as ImageIcon,
  Layers,
  Loader2,
  Plus,
  RotateCcw,
  Search,
  SlidersHorizontal,
  Star,
  Trash2,
  Video,
  Wand2,
  X,
  XCircle,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { deleteGeneration, FINAL, runwayCreate } from "@/lib/runway.functions";
import { useSignedUrls } from "@/lib/hooks";
import { handoff } from "@/lib/image-utils";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { GenerationResult } from "./GenerationResult";
import { Json } from "./Json";

export type GenRow = {
  id: string;
  kind: string;
  model: string | null;
  status: string;
  created_at: string;
  output_paths: string[];
  params: unknown;
  credits_estimated: number | null;
  error: string | null;
  favorite: boolean;
  deleted_at: string | null;
  project_id: string | null;
};
export type Project = { id: string; name: string; color: string };
const TRASH_DAYS = 30;
/** Models whose Runway schema accepts a `seed` field. */
const SEED_MODELS = ["gen4_image", "gen4_image_turbo"];
type Params = { endpoint?: string; body?: Record<string, unknown>; count?: number };

export const paramsOf = (r: { params: unknown }) => (r.params ?? {}) as Params;
export const promptOf = (r: { params: unknown }) => {
  const b = paramsOf(r).body;
  return String(b?.["promptText"] ?? b?.["text"] ?? "");
};
function timeLabel(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  return d.toDateString() === now.toDateString()
    ? d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })
    : d.toLocaleDateString([], { month: "long", day: "numeric" });
}
function dateGroup(iso: string) {
  const d = new Date(iso);
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const diff = (start.getTime() - new Date(d).setHours(0, 0, 0, 0)) / 86400000;
  if (diff <= 0) return "Today";
  if (diff === 1) return "Yesterday";
  if (diff < 7) return "Earlier this week";
  return "Older";
}

export const GENERATIONS_QUERY = ["library", "workspace"] as const;
export async function fetchGenerations() {
  const { data: u } = await supabase.auth.getUser();
  if (!u.user) return [] as GenRow[];
  const { data, error } = await supabase
    .from("generations")
    .select("id, kind, model, status, created_at, output_paths, params, credits_estimated, error, favorite, deleted_at, project_id")
    .eq("user_id", u.user.id)
    .order("created_at", { ascending: false })
    .limit(300);
  if (error) throw new Error(error.message);
  return data as GenRow[];
}

const FAV_KEY = "studio:favorites";
/** One-time move of old browser-only favorites into the database. */
async function migrateLocalFavorites() {
  const ids = JSON.parse(localStorage.getItem(FAV_KEY) ?? "[]") as string[];
  if (!ids.length) return false;
  const { error } = await supabase.from("generations").update({ favorite: true }).in("id", ids);
  if (!error) localStorage.removeItem(FAV_KEY);
  return !error;
}

export function useProjects() {
  return useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const { data, error } = await supabase.from("projects").select("id, name, color").order("created_at");
      if (error) throw new Error(error.message);
      return data as Project[];
    },
  });
}
const PROJECT_COLORS = ["#3b82f6", "#f59e0b", "#10b981", "#ef4444", "#8b5cf6", "#ec4899", "#71717a"];
export async function createProject(name: string) {
  const color = PROJECT_COLORS[Math.floor(Math.random() * PROJECT_COLORS.length)]!;
  const { data, error } = await supabase.from("projects").insert({ name, color }).select("id, name, color").single();
  if (error) throw new Error(error.message);
  return data as Project;
}

export function StatusDot({ status }: { status: string }) {
  if (status === "SUCCEEDED")
    return (
      <span aria-label="Succeeded" className="grid size-[18px] shrink-0 place-items-center rounded-full bg-info text-primary-foreground">
        <Check className="size-3" strokeWidth={3} />
      </span>
    );
  if (status === "FAILED" || status === "CANCELLED")
    return <XCircle aria-label="Failed" className="size-[18px] shrink-0 text-destructive" />;
  return <Loader2 aria-label={status.toLowerCase()} className="size-[18px] shrink-0 animate-spin text-warning" />;
}

function IconAction({ label, onClick, children, active, danger }: { label: string; onClick: () => void; children: ReactNode; active?: boolean; danger?: boolean }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          aria-label={label}
          onClick={onClick}
          className={`grid size-10 place-items-center rounded-xl border bg-background transition-all duration-150 hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${danger ? "hover:text-destructive" : ""} ${active ? "text-warning" : ""}`}
        >
          {children}
        </button>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  );
}

const TABS = [
  { id: "all", label: "All", icon: Layers },
  { id: "image", label: "Images", icon: ImageIcon },
  { id: "video", label: "Videos", icon: Video },
  { id: "audio", label: "Audio", icon: AudioLines },
  { id: "fav", label: "Favorites", icon: Star },
  { id: "failed", label: "Failed", icon: XCircle },
  { id: "trash", label: "Trash", icon: Trash2 },
] as const;
type Tab = (typeof TABS)[number]["id"];

export function Workspace({
  selectedId,
  onSelect,
  onNew,
  editor,
  composer,
  onLoadSettings,
  onUseAsRef,
  onEdit,
  defaultTab = "all",
  toolbarExtra,
}: {
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onNew: () => void;
  editor?: ReactNode;
  composer?: ReactNode;
  onLoadSettings?: ((r: GenRow) => void) | undefined;
  onUseAsRef?: ((url: string) => void) | undefined;
  onEdit?: ((url: string) => void) | undefined;
  defaultTab?: Tab;
  toolbarExtra?: ReactNode;
}) {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const del = useServerFn(deleteGeneration);
  const rerun = useServerFn(runwayCreate);
  const [tab, setTab] = useState<Tab>(defaultTab);
  const [q, setQ] = useState("");
  const [checked, setChecked] = useState<Set<string>>(new Set());
  const [tipHidden, setTipHidden] = useState(true);
  const [mobileDetail, setMobileDetail] = useState(false);
  const [lightbox, setLightbox] = useState<{ urls: string[]; i: number } | null>(null);
  const [newestFirst, setNewestFirst] = useState(true);
  const [composerOpen, setComposerOpen] = useState(true);
  const [projectFilter, setProjectFilter] = useState<string>("all");
  const projects = useProjects();
  const projectById = useMemo(() => Object.fromEntries((projects.data ?? []).map((p) => [p.id, p])), [projects.data]);
  const listRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const autoSelected = useRef(false);
  useEffect(() => setTipHidden(localStorage.getItem("studio:enhanceTipHidden") === "1"), []);

  const list = useQuery({ queryKey: GENERATIONS_QUERY, refetchInterval: 10000, queryFn: fetchGenerations });
  const everything = list.data ?? [];
  const all = useMemo(() => everything.filter((g) => !g.deleted_at && (projectFilter === "all" || (projectFilter === "none" ? !g.project_id : g.project_id === projectFilter))), [everything, projectFilter]);
  const trash = useMemo(() => everything.filter((g) => g.deleted_at), [everything]);

  // Move old local favorites into the database, and purge trash older than 30 days (once per load).
  const housekept = useRef(false);
  useEffect(() => {
    if (housekept.current || !list.data) return;
    housekept.current = true;
    migrateLocalFavorites().then((moved) => { if (moved) refresh(); });
    const cutoff = Date.now() - TRASH_DAYS * 86400000;
    const old = list.data.filter((g) => g.deleted_at && new Date(g.deleted_at).getTime() < cutoff);
    if (old.length) Promise.all(old.map((g) => del({ data: { id: g.id } }).catch(() => null))).then(refresh);
  }, [list.data]); // eslint-disable-line react-hooks/exhaustive-deps

  // Auto-select newest generation once on load.
  useEffect(() => {
    if (autoSelected.current || !list.data) return;
    autoSelected.current = true;
    if (selectedId === null && list.data[0]) onSelect(list.data[0].id);
  }, [list.data]); // eslint-disable-line react-hooks/exhaustive-deps

  // "/" focuses search.
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (e.key === "/" && !["INPUT", "TEXTAREA", "SELECT"].includes(t.tagName) && !t.isContentEditable) {
        e.preventDefault();
        searchRef.current?.focus();
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  const counts: Record<Tab, number> = {
    all: all.length,
    image: all.filter((r) => r.kind === "image").length,
    video: all.filter((r) => r.kind === "video").length,
    audio: all.filter((r) => r.kind === "audio").length,
    fav: all.filter((r) => r.favorite).length,
    failed: all.filter((r) => r.status === "FAILED" || r.status === "CANCELLED").length,
    trash: trash.length,
  };
  const rows = useMemo(() => {
    let r = (tab === "trash" ? trash : all).filter((g) =>
      tab === "all" || tab === "trash" ? true : tab === "fav" ? g.favorite : tab === "failed" ? g.status === "FAILED" || g.status === "CANCELLED" : g.kind === tab,
    );
    if (q.trim()) r = r.filter((g) => promptOf(g).toLowerCase().includes(q.toLowerCase()));
    return newestFirst ? r : [...r].reverse();
  }, [all, trash, tab, q, newestFirst]);
  const thumbs = useSignedUrls(rows.filter((r) => r.kind === "image" && r.output_paths[0]).map((r) => r.output_paths[0]!));
  const selected = everything.find((r) => r.id === selectedId) ?? null;
  const refresh = () => qc.invalidateQueries({ queryKey: ["library"] });

  const open = (id: string) => {
    onSelect(id);
    setMobileDetail(true);
  };
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
    e.preventDefault();
    const i = rows.findIndex((r) => r.id === selectedId);
    const next = rows[Math.max(0, Math.min(rows.length - 1, i + (e.key === "ArrowDown" ? 1 : -1)))];
    if (next) {
      onSelect(next.id);
      listRef.current?.querySelector<HTMLElement>(`[data-id="${next.id}"]`)?.focus();
    }
  };

  async function downloadPaths(paths: string[]) {
    if (!paths.length) { toast.info("No files to download"); return; }
    for (const p of paths) {
      const { data, error } = await supabase.storage.from("generations").createSignedUrl(p, 600, { download: true });
      if (error || !data) {
        toast.error(error?.message ?? "Download failed");
        continue;
      }
      const a = document.createElement("a");
      a.href = data.signedUrl;
      a.click();
      await new Promise((r) => setTimeout(r, 400));
    }
  }
  const patchLocal = (ids: string[], patch: Partial<GenRow>) =>
    qc.setQueryData<GenRow[]>(GENERATIONS_QUERY, (xs) => xs?.map((x) => (ids.includes(x.id) ? { ...x, ...patch } : x)));
  async function update(ids: string[], patch: { favorite?: boolean; deleted_at?: string | null; project_id?: string | null }) {
    patchLocal(ids, patch);
    const { error } = await supabase.from("generations").update(patch).in("id", ids);
    if (error) toast.error(error.message);
    refresh();
    return !error;
  }
  const afterRemove = (ids: string[]) => {
    if (selectedId && ids.includes(selectedId)) onSelect(rows.find((r) => !ids.includes(r.id))?.id ?? null);
    setChecked(new Set());
  };
  async function remove(ids: string[]) {
    if (tab === "trash") return purge(ids);
    if (await update(ids, { deleted_at: new Date().toISOString() })) {
      toast.success(`Moved ${ids.length} to Trash`, { action: { label: "Undo", onClick: () => update(ids, { deleted_at: null }) } });
      afterRemove(ids);
    }
  }
  async function purge(ids: string[]) {
    if (!confirm(`Permanently delete ${ids.length} generation(s) and their files? This can't be undone.`)) return;
    for (const id of ids) {
      try {
        await del({ data: { id } });
      } catch (e) {
        toast.error((e as Error).message);
      }
    }
    afterRemove(ids);
    refresh();
  }
  async function restore(ids: string[]) {
    if (await update(ids, { deleted_at: null })) { toast.success(`Restored ${ids.length}`); afterRemove(ids); }
  }
  async function toggleFavs(ids: string[], value?: boolean) {
    const v = value ?? !everything.find((g) => g.id === ids[0])?.favorite;
    await update(ids, { favorite: v });
  }
  async function moveTo(ids: string[], projectId: string | null | "new") {
    let pid = projectId;
    if (pid === "new") {
      const name = prompt("New project name")?.trim();
      if (!name) return;
      try {
        pid = (await createProject(name)).id;
        qc.invalidateQueries({ queryKey: ["projects"] });
      } catch (e) {
        return void toast.error((e as Error).message);
      }
    }
    if (await update(ids, { project_id: pid })) toast.success(pid ? `Moved to ${projectById[pid]?.name ?? "project"}` : "Removed from project");
    setChecked(new Set());
  }
  async function downloadZip(gs: GenRow[]) {
    const paths = gs.flatMap((g) => g.output_paths);
    if (!paths.length) return void toast.info("No files to download");
    const t = toast.loading(`Zipping ${paths.length} file(s)…`);
    try {
      const { default: JSZip } = await import("jszip");
      const zip = new JSZip();
      const { data, error } = await supabase.storage.from("generations").createSignedUrls(paths, 600);
      if (error) throw error;
      let failed = 0;
      for (const [i, d] of (data ?? []).entries()) {
        if (!d.signedUrl) { failed++; continue; }
        const res = await fetch(d.signedUrl);
        if (!res.ok) { failed++; continue; }
        zip.file(paths[i]!.split("/").slice(-2).join("_"), await res.blob());
      }
      const blob = await zip.generateAsync({ type: "blob" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `studio-${new Date().toISOString().slice(0, 10)}.zip`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      toast.success(failed ? `Downloaded, but ${failed} file(s) failed` : "Zip downloaded", { id: t });
    } catch (e) {
      toast.error(`Zip failed: ${(e as Error).message}`, { id: t });
    }
  }
  async function variation(g: GenRow) {
    const p = paramsOf(g);
    if (!p.endpoint || !p.body) return void toast.error("No stored request to re-run");
    const seeded = SEED_MODELS.includes(g.model ?? "");
    const body = seeded ? { ...p.body, seed: Math.floor(Math.random() * 4294967295) } : p.body;
    const r = await rerun({ data: { kind: g.kind as "image", endpoint: p.endpoint, body, count: p.count, credits_estimated: g.credits_estimated } });
    if (!r.ok) toast.error(r.error);
    else { toast.success(seeded ? "Variation started with a new seed" : "This model has no seed setting — re-running the same prompt"); onSelect(r.generation_id); }
    refresh();
  }

  async function reRun(g: GenRow) {
    const p = paramsOf(g);
    if (!p.endpoint || !p.body) { toast.error("No stored request to re-run"); return; }
    if (JSON.stringify(p.body).includes("chars)")) toast.warning("Uploaded images weren't stored; re-run may fail");
    const r = await rerun({ data: { kind: g.kind as "image", endpoint: p.endpoint, body: p.body, count: p.count, credits_estimated: g.credits_estimated } });
    if (!r.ok) toast.error(r.error);
    else {
      toast.success("Re-run started");
      onSelect(r.generation_id);
    }
    refresh();
  }
  async function firstImageUrl(g: GenRow) {
    const p = g.output_paths[0];
    if (!p) return null;
    const { data } = await supabase.storage.from("generations").createSignedUrl(p, 3600);
    return data?.signedUrl ?? null;
  }

  const allChecked = rows.length > 0 && rows.every((r) => checked.has(r.id));
  const selecting = checked.size > 0;
  let lastGroup = "";

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      {/* Toolbar */}
      <div className="flex shrink-0 items-center gap-3 overflow-x-auto px-4 py-4 sm:px-6">
        <button type="button" onClick={() => { onNew(); setMobileDetail(true); }} className="inline-flex h-10 shrink-0 items-center gap-2 rounded-full bg-primary px-4 text-sm font-medium text-primary-foreground transition hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          <Plus className="size-4" /> New generation
        </button>
        <span className="h-6 w-px shrink-0 bg-border" />
        <div role="tablist" className="flex shrink-0 gap-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              role="tab"
              type="button"
              aria-selected={tab === t.id}
              onClick={() => setTab(t.id)}
              className={`inline-flex h-9 items-center gap-1.5 rounded-full px-3 text-sm transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${tab === t.id ? "bg-muted font-semibold text-foreground" : "text-muted-foreground hover:text-foreground"}`}
            >
              <t.icon className="size-4" strokeWidth={1.75} /> {t.label}
              {counts[t.id] > 0 && <span className="text-xs tabular-nums text-subtle-foreground">{counts[t.id]}</span>}
            </button>
          ))}
        </div>
        <div className="ml-auto flex shrink-0 items-center gap-2">
          {toolbarExtra}
          <label className="flex h-9 w-60 items-center gap-2 rounded-full border px-3 transition focus-within:ring-2 focus-within:ring-ring">
            <Search className="size-4 text-muted-foreground" />
            <input ref={searchRef} aria-label="Search prompts" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search" className="min-w-0 flex-1 bg-transparent text-sm outline-none" />
            <kbd className="rounded-md border px-1.5 text-[11px] text-subtle-foreground">/</kbd>
          </label>
          <button type="button" aria-label={newestFirst ? "Sort oldest first" : "Sort newest first"} onClick={() => setNewestFirst(!newestFirst)} className="grid size-9 place-items-center rounded-xl border text-muted-foreground transition hover:text-foreground">
            <Filter className="size-4" />
          </button>
        </div>
      </div>

      <div className="flex min-h-0 flex-1 gap-5 px-4 pb-4 sm:px-6 sm:pb-6">
        {/* List */}
        <section className={`${mobileDetail ? "hidden" : "flex"} w-full min-w-0 flex-col overflow-hidden rounded-[20px] border md:flex md:w-[400px] md:shrink-0`}>
          <div className="flex items-center gap-3 border-b px-4 py-3">
            <input
              type="checkbox"
              aria-label="Select all"
              checked={allChecked}
              onChange={() => setChecked(allChecked ? new Set() : new Set(rows.map((r) => r.id)))}
              className="size-4 accent-primary"
            />
            <span className="text-[15px] font-semibold">{tab === "trash" ? "Trash" : "Generations"}</span>
            {selecting ? (
              <div className="ml-auto flex items-center gap-1">
                <span className="mr-1 text-[13px] text-muted-foreground">{checked.size} selected</span>
                {tab === "trash" ? (
                  <>
                    <button type="button" aria-label="Restore selected" title="Restore" onClick={() => restore([...checked])} className="grid size-8 place-items-center rounded-xl hover:bg-muted"><Undo2 className="size-4" /></button>
                    <button type="button" aria-label="Delete selected forever" title="Delete forever" onClick={() => purge([...checked])} className="grid size-8 place-items-center rounded-xl hover:bg-muted hover:text-destructive"><Trash2 className="size-4" /></button>
                  </>
                ) : (
                  <>
                    <button type="button" aria-label="Download selected as zip" title="Download zip" onClick={() => downloadZip(everything.filter((r) => checked.has(r.id)))} className="grid size-8 place-items-center rounded-xl hover:bg-muted"><Download className="size-4" /></button>
                    <button type="button" aria-label="Favorite selected" title="Favorite" onClick={() => toggleFavs([...checked], true)} className="grid size-8 place-items-center rounded-xl hover:bg-muted"><Star className="size-4" /></button>
                    <MoveMenu projects={projects.data ?? []} onMove={(pid) => moveTo([...checked], pid)} />
                    <button type="button" aria-label="Move selected to Trash" title="Move to Trash" onClick={() => remove([...checked])} className="grid size-8 place-items-center rounded-xl hover:bg-muted hover:text-destructive"><Trash2 className="size-4" /></button>
                  </>
                )}
              </div>
            ) : tab === "trash" ? (
              <button type="button" disabled={!trash.length} onClick={() => purge(trash.map((g) => g.id))} className="ml-auto rounded-full px-3 py-1 text-[13px] text-destructive hover:bg-muted disabled:opacity-40">
                Empty trash
              </button>
            ) : (
              <select
                aria-label="Filter by project"
                value={projectFilter}
                onChange={(e) => {
                  if (e.target.value === "__new") {
                    const name = prompt("New project name")?.trim();
                    if (name) createProject(name).then((p) => { qc.invalidateQueries({ queryKey: ["projects"] }); setProjectFilter(p.id); }).catch((err) => toast.error(err.message));
                    return;
                  }
                  setProjectFilter(e.target.value);
                }}
                className="ml-auto h-8 max-w-[170px] rounded-xl border bg-background px-2 text-[13px] outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="all">All projects</option>
                <option value="none">No project</option>
                {(projects.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                <option value="__new">+ New project</option>
              </select>
            )}
          </div>
          <div ref={listRef} onKeyDown={onKey} className="min-h-0 flex-1 overflow-y-auto">
            {!tipHidden && (
              <div className="relative m-3 h-[110px] overflow-hidden rounded-[16px] border">
                <div className="absolute inset-0 bg-soft" />
                <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-background to-transparent" />
                <button type="button" aria-label="Dismiss tip" onClick={() => { setTipHidden(true); localStorage.setItem("studio:enhanceTipHidden", "1"); }} className="absolute right-2 top-2 grid size-7 place-items-center rounded-full text-muted-foreground transition hover:bg-background">
                  <X className="size-3.5" />
                </button>
                <div className="relative flex h-full items-end gap-3 p-4">
                  <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-background shadow-pill"><Wand2 className="size-5" /></div>
                  <div className="min-w-0">
                    <p className="text-[15px] font-semibold">Try Enhance</p>
                    <p className="text-[13px] text-muted-foreground">Turn a short idea into a detailed prompt</p>
                  </div>
                </div>
              </div>
            )}
            {list.error && <p className="p-4 text-sm text-destructive">{(list.error as Error).message}</p>}
            {list.isLoading &&
              Array.from({ length: 6 }, (_, i) => (
                <div key={i} className="flex gap-3 border-b px-4 py-4">
                  <div className="size-16 animate-pulse rounded-[14px] bg-muted" />
                  <div className="flex-1 space-y-2 pt-1"><div className="h-3.5 w-2/3 animate-pulse rounded bg-muted" /><div className="h-3 w-1/2 animate-pulse rounded bg-muted" /><div className="h-3 w-3/4 animate-pulse rounded bg-muted" /></div>
                </div>
              ))}
            {!list.isLoading && rows.length === 0 && (
              <div className="flex flex-col items-center px-6 py-14 text-center">
                <div className="grid size-12 place-items-center rounded-2xl bg-muted"><Layers className="size-5 text-muted-foreground" /></div>
                <p className="mt-3 text-sm font-medium">{q ? "No matches" : "Nothing here yet"}</p>
                <p className="text-[13px] text-muted-foreground">{q ? "Try a different search." : "Start a new generation and it will appear here."}</p>
              </div>
            )}
            {rows.map((r) => {
              const thumbPath = r.output_paths[0];
              const thumb = r.kind === "image" ? thumbs.data?.[thumbPath ?? ""] : undefined;
              const Icon = r.kind === "video" ? Video : r.kind === "audio" ? AudioLines : ImageIcon;
              const b = paramsOf(r).body ?? {};
              const prompt = promptOf(r);
              const isSel = r.id === selectedId;
              const isChk = checked.has(r.id);
              const group = newestFirst ? dateGroup(r.created_at) : "";
              const header = group && group !== lastGroup ? group : null;
              lastGroup = group;
              const preview = r.error ?? (prompt.length > 60 ? prompt : r.kind === "image" ? "" : prompt);
              return (
                <div key={r.id}>
                  {header && (
                    <div className="sticky top-0 z-10 border-b bg-background/95 px-4 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-subtle-foreground backdrop-blur">
                      {header}
                    </div>
                  )}
                  <div
                    data-id={r.id}
                    role="button"
                    tabIndex={0}
                    aria-current={isSel}
                    onClick={() => open(r.id)}
                    onKeyDown={(e) => e.key === "Enter" && open(r.id)}
                    className={`group relative flex min-h-[96px] cursor-pointer items-center gap-3.5 border-b px-4 py-3.5 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring ${isSel ? "bg-muted" : "hover:bg-muted/50"}`}
                  >
                    {isSel && <span className="absolute inset-y-0 left-0 w-[3px] bg-primary" />}
                    <div className="relative size-16 shrink-0">
                      <div className="grid size-16 place-items-center overflow-hidden rounded-[14px] bg-muted">
                        {thumb ? (
                          <img {...(r.kind === "image" ? dragImageProps(thumb) : {})} src={thumb} alt="" className="size-full object-cover" />
                        ) : r.kind === "image" && thumbPath ? (
                          <div className="size-full animate-pulse bg-muted" />
                        ) : (
                          <Icon className="size-5 text-muted-foreground" />
                        )}
                      </div>
                      <input
                        type="checkbox"
                        aria-label="Select generation"
                        checked={isChk}
                        onClick={(e) => e.stopPropagation()}
                        onChange={() => setChecked((s) => { const n = new Set(s); if (n.has(r.id)) n.delete(r.id); else n.add(r.id); return n; })}
                        className={`absolute left-1.5 top-1.5 size-4 accent-primary transition-opacity ${isChk || selecting ? "opacity-100" : "opacity-0 group-hover:opacity-100 focus:opacity-100"}`}
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className={`min-w-0 flex-1 truncate text-[15px] ${isSel ? "font-bold" : "font-semibold"}`}>{prompt || "(no prompt)"}</p>
                        {tab !== "trash" && (
                          <button
                            type="button"
                            aria-label={r.favorite ? "Remove favorite" : "Favorite"}
                            onClick={(e) => { e.stopPropagation(); toggleFavs([r.id], !r.favorite); }}
                            className={`grid size-6 shrink-0 place-items-center rounded-lg transition hover:bg-background ${r.favorite ? "text-warning" : "text-subtle-foreground opacity-0 focus:opacity-100 group-hover:opacity-100"}`}
                          >
                            <Star className="size-4" fill={r.favorite ? "currentColor" : "none"} />
                          </button>
                        )}
                        <StatusDot status={r.status} />
                        <span className="shrink-0 text-[13px] text-subtle-foreground">{timeLabel(r.created_at)}</span>
                      </div>
                      <p className="mt-0.5 truncate text-[13px] text-muted-foreground">
                        {[r.model ?? r.kind, b["ratio"] as string | undefined, r.credits_estimated != null ? `${r.credits_estimated} credits` : null].filter(Boolean).join(" · ")}
                      </p>
                      {tab === "trash" && r.deleted_at ? (
                        <p className="mt-0.5 truncate text-[13px] text-subtle-foreground">Deletes in {Math.max(0, TRASH_DAYS - Math.floor((Date.now() - new Date(r.deleted_at).getTime()) / 86400000))} days</p>
                      ) : preview && <p className={`mt-0.5 truncate text-sm ${r.error ? "text-destructive" : "text-subtle-foreground"}`}>{preview}</p>}
                      {r.project_id && projectById[r.project_id] && (
                        <span className="mt-1 inline-flex items-center gap-1.5 rounded-full bg-muted px-2 py-0.5 text-[11px] text-muted-foreground">
                          <span className="size-1.5 rounded-full" style={{ background: projectById[r.project_id]!.color }} /> {projectById[r.project_id]!.name}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Detail */}
        <section className={`${mobileDetail ? "flex" : "hidden"} min-w-0 flex-1 flex-col overflow-hidden rounded-[20px] border md:flex`}>
          <button type="button" onClick={() => setMobileDetail(false)} className="flex items-center gap-2 border-b px-4 py-3 text-sm md:hidden">
            <ArrowLeft className="size-4" /> Back
          </button>
          <div className="flex min-h-0 flex-1 flex-col">
            {list.isLoading ? (
              <div className="space-y-5 p-6">
                <div className="flex gap-2">{Array.from({ length: 6 }, (_, i) => <div key={i} className="size-10 animate-pulse rounded-xl bg-muted" />)}</div>
                <div className="h-[50vh] animate-pulse rounded-[20px] bg-muted" />
                <div className="h-6 w-2/3 animate-pulse rounded bg-muted" />
              </div>
            ) : selected ? (
              <Detail
                key={selected.id}
                g={selected}
                fav={selected.favorite}
                onFav={() => toggleFavs([selected.id], !selected.favorite)}
                trashed={!!selected.deleted_at}
                onRestore={() => restore([selected.id])}
                projects={projects.data ?? []}
                project={selected.project_id ? projectById[selected.project_id] : undefined}
                onMove={(pid) => moveTo([selected.id], pid)}
                onVariation={() => variation(selected)}
                onEdit={onEdit ? async () => {
                  const url = await firstImageUrl(selected);
                  if (!url) return void toast.info("No image to edit");
                  onEdit(url);
                } : async () => {
                  const url = await firstImageUrl(selected);
                  if (!url) return void toast.info("No image to edit");
                  handoff.set("edit", url);
                  navigate({ to: "/image" });
                }}
                onDownload={() => downloadPaths(selected.output_paths)}
                onDelete={() => remove([selected.id])}
                onRerun={() => reRun(selected)}
                onRef={async () => {
                  const url = await firstImageUrl(selected);
                  if (!url) { toast.info("No image to use"); return; }
                  if (onUseAsRef) onUseAsRef(url);
                  else {
                    handoff.set("ref", url);
                    navigate({ to: "/image" });
                  }
                  toast.success("Added as reference");
                }}
                onVideo={async () => {
                  const url = await firstImageUrl(selected);
                  if (!url) { toast.info("No image to animate"); return; }
                  handoff.set("videoStart", url);
                  navigate({ to: "/video" });
                }}
                onLoad={
                  onLoadSettings
                    ? () => { onLoadSettings(selected); setComposerOpen(true); }
                    : () => {
                        handoff.set("loadGen", selected.id);
                        navigate({ to: selected.kind === "video" ? "/video" : selected.kind === "audio" ? "/audio" : "/image" });
                      }
                }
                onOpen={(url, urls) => setLightbox({ urls: urls ?? [url], i: Math.max(0, (urls ?? [url]).indexOf(url)) })}
                onUseAsRef={onUseAsRef}
              />
            ) : editor ? (
              <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">{editor}</div>
            ) : (
              <div className="flex flex-1 flex-col items-center justify-center p-10 text-center">
                <div className="grid size-12 place-items-center rounded-2xl bg-muted"><ImageIcon className="size-5 text-muted-foreground" /></div>
                <p className="mt-3 text-sm font-medium">Select a generation</p>
                <p className="text-[13px] text-muted-foreground">Pick one from the list to see its results and settings.</p>
              </div>
            )}
          </div>
          {composer && (
            <div className="shrink-0 border-t bg-background">
              <button
                type="button"
                aria-expanded={composerOpen}
                onClick={() => setComposerOpen(!composerOpen)}
                className="flex w-full items-center justify-center gap-1.5 py-1.5 text-[12px] text-muted-foreground transition hover:text-foreground"
              >
                {composerOpen ? <ChevronDown className="size-3.5" /> : <ChevronUp className="size-3.5" />}
                {composerOpen ? "Hide generator" : "Show generator"}
              </button>
              {composerOpen && <div className="px-4 pb-4 sm:px-5">{composer}</div>}
            </div>
          )}
        </section>
      </div>

      <Dialog open={!!lightbox} onOpenChange={(o) => !o && setLightbox(null)}>
        <DialogContent
          className="max-w-5xl rounded-[24px] p-2"
          onKeyDown={(e) => {
            if (!lightbox) return;
            if (e.key === "ArrowRight") setLightbox({ ...lightbox, i: (lightbox.i + 1) % lightbox.urls.length });
            if (e.key === "ArrowLeft") setLightbox({ ...lightbox, i: (lightbox.i - 1 + lightbox.urls.length) % lightbox.urls.length });
          }}
        >
          <DialogTitle className="sr-only">Image preview</DialogTitle>
          {lightbox && (
            <div className="relative">
              <img src={lightbox.urls[lightbox.i]} alt="Generated output" className="max-h-[85vh] w-full rounded-[18px] object-contain" />
              {lightbox.urls.length > 1 && (
                <>
                  <button type="button" aria-label="Previous image" onClick={() => setLightbox({ ...lightbox, i: (lightbox.i - 1 + lightbox.urls.length) % lightbox.urls.length })} className="absolute left-3 top-1/2 grid size-10 -translate-y-1/2 place-items-center rounded-full bg-background/90 shadow-pill">
                    <ChevronLeft className="size-5" />
                  </button>
                  <button type="button" aria-label="Next image" onClick={() => setLightbox({ ...lightbox, i: (lightbox.i + 1) % lightbox.urls.length })} className="absolute right-3 top-1/2 grid size-10 -translate-y-1/2 place-items-center rounded-full bg-background/90 shadow-pill">
                    <ChevronRight className="size-5" />
                  </button>
                  <span className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-background/90 px-2.5 py-0.5 text-xs">{lightbox.i + 1} / {lightbox.urls.length}</span>
                </>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Detail({
  g,
  fav,
  onFav,
  onDownload,
  onDelete,
  onRerun,
  onRef,
  onVideo,
  onLoad,
  onOpen,
  onUseAsRef,
  trashed,
  onRestore,
  projects,
  project,
  onMove,
  onVariation,
  onEdit,
}: {
  g: GenRow;
  fav: boolean;
  onFav: () => void;
  trashed: boolean;
  onRestore: () => void;
  projects: Project[];
  project: Project | undefined;
  onMove: (pid: string | null | "new") => void;
  onVariation: () => void;
  onEdit: () => void;
  onDownload: () => void;
  onDelete: () => void;
  onRerun: () => void;
  onRef: () => void;
  onVideo: () => void;
  onLoad: () => void;
  onOpen: (url: string, urls?: string[]) => void;
  onUseAsRef?: ((url: string) => void) | undefined;
}) {
  const p = paramsOf(g);
  const b = p.body ?? {};
  const prompt = promptOf(g);
  const refs = (Array.isArray(b["referenceImages"]) ? b["referenceImages"] : []) as { uri?: string; tag?: string }[];
  const meta = [
    g.model,
    b["ratio"] && `ratio ${b["ratio"]}`,
    b["quality"] && `quality ${b["quality"]}`,
    `${p.count ?? b["outputCount"] ?? 1} output(s)`,
    g.credits_estimated != null && `${g.credits_estimated} credits`,
    new Date(g.created_at).toLocaleString(),
  ].filter(Boolean);
  const { promptText: _p, referenceImages: _r, ...settings } = b;
  const isImage = g.kind === "image";

  return (
    <div className="min-h-0 flex-1 overflow-y-auto p-5 sm:p-7">
      {trashed && (
        <div className="mb-4 flex flex-wrap items-center gap-3 rounded-[16px] border bg-muted/60 px-4 py-3 text-sm">
          <Trash2 className="size-4 text-muted-foreground" /> In Trash — deleted permanently after {TRASH_DAYS} days.
          <button type="button" onClick={onRestore} className="ml-auto inline-flex h-8 items-center gap-1.5 rounded-full bg-primary px-3 text-[13px] text-primary-foreground"><Undo2 className="size-3.5" /> Restore</button>
        </div>
      )}
      <div className="flex flex-wrap gap-2">
        <IconAction label="Download" onClick={onDownload}><Download className="size-5" strokeWidth={1.75} /></IconAction>
        <IconAction label={fav ? "Remove favorite" : "Favorite"} onClick={onFav} active={fav}><Star className="size-5" strokeWidth={1.75} fill={fav ? "currentColor" : "none"} /></IconAction>
        <IconAction label="Re-run" onClick={onRerun}><RotateCcw className="size-5" strokeWidth={1.75} /></IconAction>
        <IconAction label="Variations (new seed when supported)" onClick={onVariation}><Shuffle className="size-5" strokeWidth={1.75} /></IconAction>
        {isImage && <IconAction label="Edit this image" onClick={onEdit}><Pencil className="size-5" strokeWidth={1.75} /></IconAction>}
        {isImage && <IconAction label="Use as reference" onClick={onRef}><ImagePlus className="size-5" strokeWidth={1.75} /></IconAction>}
        {isImage && <IconAction label="Make video" onClick={onVideo}><Clapperboard className="size-5" strokeWidth={1.75} /></IconAction>}
        <MoveMenu projects={projects} onMove={onMove} big current={project} />
        <IconAction label={trashed ? "Delete forever" : "Move to Trash"} onClick={onDelete} danger><Trash2 className="size-5" strokeWidth={1.75} /></IconAction>
      </div>

      <div className="mt-6">
        <GenerationResult id={g.id} onUseAsRef={onUseAsRef} onOpen={onOpen} expected={p.count ?? 1} large />
      </div>

      <div className="mt-6 flex items-start gap-3">
        <h2 className="min-w-0 flex-1 text-[23px] font-semibold leading-snug">{prompt || "(no prompt)"}</h2>
        {prompt && (
          <IconAction label="Copy prompt" onClick={() => { navigator.clipboard.writeText(prompt); toast.success("Prompt copied"); }}>
            <Copy className="size-4" strokeWidth={1.75} />
          </IconAction>
        )}
      </div>
      <p className="mt-1.5 text-[13px] text-muted-foreground">{meta.join(" · ")}</p>
      {!FINAL.includes(g.status) && <p className="mt-1 text-[13px] text-warning">Still working — this updates automatically.</p>}

      {refs.length > 0 && (
        <div className="mt-6">
          <h3 className="text-sm font-semibold">References</h3>
          <div className="mt-2.5 flex flex-wrap gap-2">
            {refs.map((r, i) => {
              const m = /\((\d+) chars\)/.exec(r.uri ?? "");
              const size = m ? `${Math.round((Number(m[1]) * 0.75) / 1024)} KB` : r.uri?.startsWith("http") ? "linked" : "—";
              return (
                <div key={i} className="flex items-center gap-3 rounded-xl border p-2 pr-4">
                  <div className="grid size-10 place-items-center overflow-hidden rounded-lg bg-muted">
                    {r.uri?.startsWith("http") ? <img src={r.uri} alt="" className="size-full object-cover" /> : <ImageIcon className="size-4 text-muted-foreground" />}
                  </div>
                  <div>
                    <p className="text-sm font-medium">@{r.tag ?? `ref${i + 1}`}</p>
                    <p className="text-[13px] text-muted-foreground">{size}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="mt-6">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-sm font-semibold">Settings used</h3>
          <button type="button" onClick={onLoad} className="inline-flex h-9 items-center gap-2 rounded-full bg-primary px-4 text-sm text-primary-foreground transition hover:opacity-90">
            <SlidersHorizontal className="size-4" /> Load settings into generator
          </button>
        </div>
        <Json value={{ endpoint: p.endpoint, ...settings }} className="mt-2.5 max-h-64" />
      </div>
    </div>
  );
}

function MoveMenu({ projects, onMove, big, current }: { projects: Project[]; onMove: (pid: string | null | "new") => void; big?: boolean; current?: Project | undefined }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={current ? `Project: ${current.name} — move` : "Move to project"}
          title={current ? `Project: ${current.name}` : "Move to project"}
          className={big ? "grid size-10 place-items-center rounded-xl border bg-background transition hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" : "grid size-8 place-items-center rounded-xl hover:bg-muted"}
        >
          <FolderInput className={big ? "size-5" : "size-4"} strokeWidth={1.75} style={current ? { color: current.color } : undefined} />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-52 rounded-[16px]">
        {projects.map((p) => (
          <DropdownMenuItem key={p.id} onSelect={() => onMove(p.id)}>
            <span className="size-2 rounded-full" style={{ background: p.color }} /> {p.name}
            {current?.id === p.id && <Check className="ml-auto size-3.5" />}
          </DropdownMenuItem>
        ))}
        {current && <DropdownMenuItem onSelect={() => onMove(null)}>Remove from project</DropdownMenuItem>}
        {projects.length > 0 && <DropdownMenuSeparator />}
        <DropdownMenuItem onSelect={() => onMove("new")}><FolderPlus className="size-4" /> New project</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
