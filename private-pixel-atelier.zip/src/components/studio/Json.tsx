import { useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { AlertCircle } from "lucide-react";

export function Json({ value, className = "" }: { value: unknown; className?: string }) {
  return (
    <pre className={`max-h-96 overflow-auto rounded-xl border bg-muted/80 p-3 font-mono text-xs leading-relaxed ${className}`}>
      {typeof value === "string" ? value : JSON.stringify(value, null, 2)}
    </pre>
  );
}

export type AppError = { code: string; message: string; hint: string };
const SETUP_CODES = ["MISSING_SECRET", "NOT_ALLOWED_USER", "MISSING_TABLE", "DB_ERROR", "RUNWAY_ERROR"];

/** Finds a structured {error:{code,message,hint}} inside an error string (may have a text prefix). */
export function parseAppError(text: string): { prefix: string; err: AppError } | null {
  const i = text.indexOf('{"error"');
  if (i < 0) return null;
  try {
    const e = JSON.parse(text.slice(i))?.error;
    if (e && typeof e.code === "string" && typeof e.message === "string") return { prefix: text.slice(0, i), err: e };
  } catch { /* not structured */ }
  return null;
}

/** Plain message text for toasts. */
export function errorText(text: string) {
  const p = parseAppError(text);
  return p ? `${p.prefix}${p.err.message} ${p.err.hint}`.trim() : text;
}

/** Soft red banner; optional raw details toggle. Renders structured errors as message + hint. */
export function ErrorBox({ children, details }: { children: ReactNode; details?: unknown }) {
  const [open, setOpen] = useState(false);
  const flat = Array.isArray(children) ? children.join("") : children;
  const parsed = typeof flat === "string" ? parseAppError(flat) : null;
  return (
    <div role="alert" className="rounded-2xl border border-destructive/20 bg-destructive/8 p-3 text-sm text-destructive">
      <div className="flex items-start gap-2">
        <AlertCircle className="mt-0.5 size-4 shrink-0" />
        <div className="min-w-0 flex-1 whitespace-pre-wrap break-words">
          {parsed ? (
            <>
              <p className="font-medium">{parsed.prefix}{parsed.err.message}</p>
              {parsed.err.hint && <p className="mt-0.5 opacity-90">{parsed.err.hint}</p>}
              {SETUP_CODES.includes(parsed.err.code) && (
                <Link to="/setup-check" className="mt-1 inline-block font-medium underline">Open Setup Check</Link>
              )}
            </>
          ) : children}
        </div>
        {details !== undefined && (
          <button type="button" className="shrink-0 text-xs underline" onClick={() => setOpen(!open)}>
            {open ? "Hide details" : "Show details"}
          </button>
        )}
      </div>
      {open && details !== undefined && <Json value={details} className="mt-2 text-foreground" />}
    </div>
  );
}
