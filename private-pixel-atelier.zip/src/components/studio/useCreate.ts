import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { runwayCreate, type Attempt } from "@/lib/runway.functions";
import { errorText } from "@/components/studio/Json";

type Input = {
  kind: "image" | "video" | "audio" | "tool";
  endpoint: string;
  body: Record<string, unknown>;
  count?: number;
  credits_estimated?: number | null;
};

export function useCreate() {
  const fn = useServerFn(runwayCreate);
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const [generationId, setGenerationId] = useState<string | null>(null);
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function create(input: Input) {
    setBusy(true);
    setError(null);
    try {
      const res = await fn({ data: input });
      setAttempts(res.attempts);
      if (!res.ok) {
        setError(res.error);
        toast.error(errorText(res.error), { duration: 10000 });
        return { generationId: null, attempts: res.attempts };
      }
      setGenerationId(res.generation_id);
      qc.invalidateQueries({ queryKey: ["library"] });
      return { generationId: res.generation_id as string, attempts: res.attempts };
    } catch (e) {
      const msg = (e as Error).message;
      setError(msg);
      toast.error(errorText(msg));
      return { generationId: null, attempts: [] as Attempt[] };
    } finally {
      setBusy(false);
    }
  }
  return { create, busy, generationId, setGenerationId, attempts, error };
}
