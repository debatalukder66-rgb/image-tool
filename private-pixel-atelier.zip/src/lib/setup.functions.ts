import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { runwayFetch } from "./runway.server";

export const REQUIRED_SECRETS = ["RUNWAYML_API_SECRET", "ALLOWED_EMAIL", "SUPABASE_URL", "SUPABASE_PUBLISHABLE_KEY", "SUPABASE_SERVICE_ROLE_KEY"] as const;
export const OPTIONAL_SECRETS = ["LOVABLE_API_KEY"] as const;
export const TABLES = ["generations", "model_config", "model_checks", "saved_prompts", "style_presets", "projects", "app_settings"] as const;
/** This app has no Supabase Edge Functions; these server functions run inside the deployed app. */
export const SERVER_FUNCTIONS = [
  "runwayCreate", "runwayStatus", "runwayBalance", "runwayVoices", "deleteGeneration", "prepareRepair",
  "enhancePrompt", "sendSetupLink", "getSetupStatus", "createAdminAccount", "healthCheck",
];

export type HealthReport = {
  limited: boolean;
  serverHost: string | null;
  secrets: { name: string; set: boolean; optional: boolean }[];
  emailMatches: boolean | null;
  runway: { ok: boolean; status: number; message: string } | null;
  tables: { name: string; ok: boolean; message: string | null }[];
  bucket: { ok: boolean; message: string | null } | null;
  edgeFunctions: string[];
  serverFunctions: string[];
};

/** Signed-in only. Never returns secret values, only set/missing. */
export const healthCheck = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<HealthReport> => {
    const env = (n: string) => !!process.env[n]?.trim();
    let serverHost: string | null = null;
    try { serverHost = new URL(process.env["SUPABASE_URL"] ?? "").host; } catch { /* unset */ }
    const secrets = [
      ...REQUIRED_SECRETS.map((name) => ({ name, set: env(name), optional: false })),
      ...OPTIONAL_SECRETS.map((name) => ({ name, set: env(name), optional: true })),
    ];
    const allowed = process.env["ALLOWED_EMAIL"]?.trim().toLowerCase();
    const email = String((context.claims as { email?: string }).email ?? "").toLowerCase();
    const emailMatches = allowed ? email === allowed : null;
    const base = { serverHost, secrets, emailMatches, edgeFunctions: [] as string[], serverFunctions: SERVER_FUNCTIONS };
    // Fail closed: without a matching ALLOWED_EMAIL only show secret presence.
    if (!emailMatches) return { ...base, limited: true, runway: null, tables: [], bucket: null };

    const r = await runwayFetch("/organization");
    const b = r.body as { error?: unknown; message?: unknown } | string | null;
    const message = r.ok ? "Connected" : typeof b === "string" ? b : String((b as { error?: unknown })?.error ?? (b as { message?: unknown })?.message ?? JSON.stringify(b));

    const tables = await Promise.all(
      TABLES.map(async (name) => {
        const { error } = await context.supabase.from(name).select("*", { head: true, count: "exact" }).limit(1);
        return { name, ok: !error, message: error?.message ?? null };
      }),
    );
    const { error: bErr } = await context.supabase.storage.from("generations").list(context.userId, { limit: 1 });
    return {
      ...base,
      limited: false,
      runway: { ok: r.ok, status: r.status, message },
      tables,
      bucket: { ok: !bErr, message: bErr?.message ?? null },
    };
  });

export function problems(h: HealthReport | undefined): string[] {
  if (!h) return [];
  const out = h.secrets.filter((s) => !s.set && !s.optional).map((s) => `secret ${s.name}`);
  if (h.emailMatches === false) out.push("your email doesn't match ALLOWED_EMAIL");
  if (h.runway && !h.runway.ok) out.push("Runway connection");
  const t = h.tables.filter((x) => !x.ok).map((x) => x.name);
  if (t.length) out.push(`tables ${t.join(", ")}`);
  if (h.bucket && !h.bucket.ok) out.push("storage bucket generations");
  return out;
}
