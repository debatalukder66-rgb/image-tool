export const IMAGE_MODELS = [
  { id: "gpt_image_2_5_sunburst", label: "GPT Image 2.5 Sunburst" },
  { id: "gpt_image_2_5_flare", label: "GPT Image 2.5 Flare" },
  { id: "gpt_image_2", label: "GPT Image 2" },
  { id: "gemini_image3.1_flash", label: "Nano Banana 2" },
  { id: "gemini_image3_pro", label: "Nano Banana Pro" },
  { id: "gemini_2.5_flash", label: "Nano Banana" },
  { id: "seedream5_pro", label: "Seedream 5 Pro" },
  { id: "seedream5_lite", label: "Seedream 5 Lite" },
  { id: "grok_imagine_image_2", label: "Grok Imagine Image 2" },
  { id: "muse_image", label: "Muse Image" },
  { id: "gen4_image_turbo", label: "Gen-4 Image Turbo" },
  { id: "gen4_image", label: "Gen-4 Image" },
];

export const isGpt25 = (m: string) => m.startsWith("gpt_image_2_5_");
export const isGpt = (m: string) => m === "gpt_image_2" || isGpt25(m);

export function imageResolutions(model: string): string[] {
  if (isGpt(model)) return ["1K", "2K", "4K"];
  if (model === "gen4_image") return ["720p", "1080p"];
  if (model === "gemini_image3.1_flash") return ["512px", "1K", "2K", "4K"];
  if (model === "gemini_image3_pro") return ["1K", "2K", "4K"];
  if (model === "seedream5_pro") return ["1K", "2K"];
  return ["1K"];
}

export function imageQualities(model: string): string[] {
  if (isGpt25(model)) return ["low", "medium", "high", "xhigh", "max"];
  if (isGpt(model)) return ["low", "medium", "high"];
  return [];
}

export const ASPECTS = ["1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3", "21:9"];

const LONG_SIDE: Record<string, number> = { "512px": 512, "720p": 1280, "1080p": 1920, "1K": 1024, "2K": 2048, "4K": 4096 };

/** Convert aspect + resolution into Runway's "W:H" ratio string. */
export function ratioFor(aspect: string, res: string) {
  const [a = 1, b = 1] = aspect.split(":").map(Number);
  const long = LONG_SIDE[res] ?? 1024;
  const r = (n: number) => Math.round(n / 8) * 8;
  return a >= b ? `${long}:${r((long * b) / a)}` : `${r((long * a) / b)}:${long}`;
}

/** Returns credits for ONE image, or [min,max] range. */
export function imageCost(model: string, res: string, quality: string, refs: number, count: number): string {
  let per: number | [number, number] | null = null;
  const is4k = res === "4K";
  if (model === "gpt_image_2") {
    per = (is4k ? { low: 2, medium: 11, high: 41 } : { low: 1, medium: 5, high: 20 })[quality as "low"] ?? null;
  } else if (isGpt25(model)) {
    per = (is4k
      ? { low: 2, medium: 11, high: 19, xhigh: 34, max: 76 }
      : { low: 1, medium: 5, high: 16, xhigh: 28, max: 63 })[quality as "low"] ?? null;
  } else if (model === "gen4_image") per = res === "1080p" || res === "2K" || res === "4K" ? 8 : 5;
  else if (model === "gen4_image_turbo") per = 2;
  else if (model === "muse_image") per = 1;
  else if (model === "seedream5_pro") per = res === "2K" ? 9 : 5;
  else if (model === "seedream5_lite") per = 4;
  else if (model === "gemini_image3_pro") per = is4k ? 40 : 20;
  else if (model === "gemini_image3.1_flash") per = { "512px": 5, "1K": 7, "2K": 11, "4K": 16 }[res] ?? null;
  else if (model === "gemini_2.5_flash") per = 5;
  else if (model === "grok_imagine_image_2") per = [4, 8];
  if (per === null) return "?";
  const extra = isGpt25(model) ? refs : 0;
  if (Array.isArray(per)) return `${per[0] * count + extra}–${per[1] * count + extra}`;
  return String(per * count + extra);
}

export const VIDEO_MODELS = [
  "seedance2_5", "seedance2", "seedance2_fast", "seedance2_mini", "gen4.5", "gen4_turbo",
  "veo3.1", "veo3.1_fast", "wan3", "wan3_prime", "hailuo3", "h3_max", "grok_imagine_1_5",
  "happyhorse_1_0", "gemini_omni_flash_1.1", "gemini_omni_flash",
];

export function videoRatios(model: string, mode: "t2v" | "i2v") {
  if (model === "gen4.5") {
    return mode === "t2v"
      ? ["1280:720", "720:1280"]
      : ["1280:720", "720:1280", "1584:672", "1104:832", "832:1104", "672:1584", "960:960"];
  }
  return ["1280:720", "720:1280", "1920:1080", "1080:1920", "960:960", "1584:672", "1104:832", "832:1104"];
}

export function videoCostPerSec(model: string, res: string, audio: boolean): number | null {
  switch (model) {
    case "gen4.5": return 12;
    case "gen4_turbo": return 5;
    case "seedance2_5": return res === "1080p" ? 68 : 30;
    case "seedance2": return 36;
    case "seedance2_fast": return 29;
    case "seedance2_mini": return 16;
    case "veo3.1": return audio ? 40 : 20;
    case "veo3.1_fast": return audio ? 15 : 10;
    case "wan3": return 10;
    case "grok_imagine_1_5": return 16;
    case "h3_max": return 8;
    case "hailuo3": return 10;
    case "happyhorse_1_0": return 15;
    case "gemini_omni_flash": return 10;
    case "aleph2": return 28;
    default: return null;
  }
}

export const TTS_MODELS = ["eleven_v4", "eleven_v3", "eleven_multilingual_v2", "seed_audio"];

export function ttsCost(model: string, chars: number): string {
  if (model === "eleven_v4") return ((chars / 1000) * 2.2).toFixed(1);
  if (model === "eleven_v3" || model === "eleven_multilingual_v2") return String(Math.ceil(chars / 50));
  return "?";
}
export const sfxCost = (duration?: number) => (duration ? Math.ceil(duration) : 2);

export function mediaType(path: string): "image" | "video" | "audio" | "other" {
  const ext = path.split(".").pop()?.toLowerCase() ?? "";
  if (["png", "jpg", "jpeg", "webp"].includes(ext)) return "image";
  if (["mp4", "webm", "mov"].includes(ext)) return "video";
  if (["mp3", "wav", "ogg", "m4a"].includes(ext)) return "audio";
  return "other";
}

// ---------- Image ratio handling (exact pixel strings per model) ----------

export const SIZE_TIERS = ["Small", "Medium", "Large"] as const;
export type SizeTier = (typeof SIZE_TIERS)[number];
export const SIZE_LABELS: Record<SizeTier, string> = { Small: "Small (~2MP)", Medium: "Medium (~4MP)", Large: "Large (~8MP / 4K)" };
/** Cost tier: Large = 4K price, Small/Medium = 1K/2K price. */
export const tierToRes = (t: SizeTier) => (t === "Large" ? "4K" : t === "Medium" ? "2K" : "1K");

export const RATIO_TABLE: Record<string, [string, string, string]> = {
  "1:1": ["1920:1920", "2560:2560", "2880:2880"],
  "16:9": ["1920:1088", "2560:1440", "3840:2160"],
  "9:16": ["1088:1920", "1440:2560", "2160:3840"],
  "3:2": ["1920:1280", "2560:1712", "3504:2336"],
  "2:3": ["1280:1920", "1712:2560", "2336:3504"],
  "4:3": ["1920:1440", "2560:1920", "3264:2448"],
  "3:4": ["1440:1920", "1920:2560", "2448:3264"],
  "5:4": ["1920:1536", "2560:2048", "3200:2560"],
  "4:5": ["1536:1920", "2048:2560", "2560:3200"],
  "ultra-wide": ["2048:880", "2912:1248", "3840:1648"],
};
export const TABLE_ASPECTS = ["auto", ...Object.keys(RATIO_TABLE)];

export function tableRatio(aspect: string, tier: SizeTier): string {
  if (aspect === "auto") return "auto";
  const row = RATIO_TABLE[aspect] ?? RATIO_TABLE["1:1"]!;
  return row[SIZE_TIERS.indexOf(tier)]!;
}

const GEN4_RATIOS = [
  "1920:1080", "1080:1920", "1024:1024", "1360:768", "1080:1080", "1168:880", "1440:1080", "1080:1440",
  "1808:768", "2112:912", "1280:720", "720:1280", "720:720", "960:720", "720:960", "1680:720",
];

export type ImageModelConfig = {
  /** Exact allowed ratio strings. If absent, the aspect × size table is used. */
  ratios?: string[];
  qualities: string[];
  maxOutputs: number;
};

export function baseImageConfig(model: string): ImageModelConfig {
  const qualities = imageQualities(model);
  if (model === "gen4_image" || model === "gen4_image_turbo") return { ratios: GEN4_RATIOS, qualities, maxOutputs: 4 };
  return { qualities, maxOutputs: 4 };
}

/** Ratios learned from Runway 400 responses, kept for this browser session. */
export const learnedRatios = {
  get(model: string): string[] | null {
    if (typeof sessionStorage === "undefined") return null;
    const v = sessionStorage.getItem(`ratios:${model}`);
    return v ? (JSON.parse(v) as string[]) : null;
  },
  set(model: string, values: string[]) {
    sessionStorage.setItem(`ratios:${model}`, JSON.stringify(values));
  },
};

type Issue = { path?: (string | number)[]; values?: unknown[]; message?: string; code?: string };

function issuesOf(response: unknown): Issue[] {
  const r = response as { issues?: Issue[] } | null;
  return Array.isArray(r?.issues) ? r!.issues! : [];
}

/** Returns allowed values Runway listed for the `ratio` field, if any. */
export function ratioValuesFromError(response: unknown): string[] | null {
  const issue = issuesOf(response).find((i) => i.path?.join(".") === "ratio" && Array.isArray(i.values));
  return issue ? issue.values!.map(String) : null;
}

/** Short human summary: "ratio: message (allowed: a, b, …)". */
export function summarizeRunwayError(status: number, response: unknown): string {
  const issues = issuesOf(response);
  const head = `Runway ${status}${(response as { error?: string })?.error ? `: ${(response as { error: string }).error}` : ""}`;
  if (!issues.length) return typeof response === "string" ? `${head}\n${response}` : head;
  const lines = issues.map((i) => {
    const path = i.path?.join(".") || "(body)";
    const allowed = Array.isArray(i.values) ? ` — allowed: ${i.values.map(String).join(", ")}` : "";
    return `• ${path}: ${i.message ?? i.code ?? "invalid"}${allowed}`;
  });
  return [head, ...lines].join("\n");
}
