import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertAllowed, missingSecret } from "./runway.server";

const input = z.object({
  idea: z.string().min(1).max(2000),
  model: z.string().max(100),
  modelLabel: z.string().max(200).optional(),
  refTags: z.array(z.string().max(40)).max(4).optional(),
});

export type PromptOption = { title: string; prompt: string; why: string };
export type EnhanceResult =
  | { ok: true; options: PromptOption[] }
  | { ok: false; status: number; error: string };

const schema = {
  type: "object",
  additionalProperties: false,
  required: ["options"],
  properties: {
    options: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["title", "prompt", "why"],
        properties: { title: { type: "string" }, prompt: { type: "string" }, why: { type: "string" } },
      },
    },
  },
};

function modelGuidance(model: string) {
  if (model.startsWith("gpt_image")) return "GPT Image: understands long natural-language descriptions, exact text in quotes, layout and composition instructions.";
  if (model.startsWith("gen4")) return "Runway Gen-4 Image: concise, visual, cinematic descriptions; subject, setting, lighting, lens/camera, mood. Refer to reference images with @tag.";
  if (model.includes("gemini") || model.includes("nano")) return "Gemini image: clear natural-language scene descriptions, good with edits and reference images.";
  if (model.includes("seedream")) return "Seedream: detailed descriptive prompts with style, materials, lighting and composition keywords.";
  if (model.includes("flux")) return "FLUX: descriptive sentences, specific styles, lighting and camera details; no negative prompts.";
  return "Write a clear, vivid, visual prompt with subject, setting, style, lighting and composition.";
}

export const enhancePrompt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => input.parse(d))
  .handler(async ({ data, context }): Promise<EnhanceResult> => {
    assertAllowed(context.claims);
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) return { ok: false, status: 401, error: missingSecret("LOVABLE_API_KEY") };

    const refs = data.refTags?.length ? `Reference image tags available: ${data.refTags.map((t) => "@" + t).join(", ")}. Use them where they fit.` : "No reference images.";
    const instructions = `You are an expert prompt writer for image generation. Turn the user's rough idea into exactly 3 distinct polished prompt options tailored to the target model.
Target model: ${data.modelLabel ?? data.model} (${data.model}). ${modelGuidance(data.model)}
${refs}
Each option: a short title (2-4 words), the full prompt (under 900 characters), and a one-sentence "why" describing its angle. Vary the options (e.g. faithful, cinematic, stylized). Keep the user's core intent.`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "fetch" },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        instructions,
        input: [{ role: "user", content: data.idea }],
        stream: true,
        store: false,
        reasoning: { effort: "low", summary: "auto" },
        include: ["reasoning.encrypted_content"],
        text: { format: { type: "json_schema", name: "prompt_options", strict: true, schema } },
      }),
    });
    if (!res.ok || !res.body) {
      const body = await res.text().catch(() => "");
      let msg = body;
      try { msg = JSON.parse(body)?.error?.message ?? JSON.parse(body)?.message ?? body; } catch { /* raw */ }
      if (res.status === 402) msg ||= "Out of AI credits. Add credits in Settings → Plans & credits.";
      if (res.status === 429) msg ||= "Rate limited. Try again in a moment.";
      return { ok: false, status: res.status, error: msg || `AI request failed (${res.status})` };
    }

    // Consume SSE stream server-side.
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "", text = "", refusal = "", failed = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf("\n\n")) >= 0) {
        const frame = buf.slice(0, i);
        buf = buf.slice(i + 2);
        for (const line of frame.split("\n")) {
          if (!line.startsWith("data:")) continue;
          const d = line.slice(5).trim();
          if (!d || d === "[DONE]") continue;
          try {
            const ev = JSON.parse(d);
            if (ev.type === "response.output_text.delta") text += ev.delta;
            else if (ev.type === "response.refusal.delta") refusal += ev.delta;
            else if (ev.type === "response.failed" || ev.type === "error")
              failed = ev.response?.error?.message ?? ev.error?.message ?? ev.message ?? "AI request failed";
          } catch { /* partial */ }
        }
      }
    }
    if (failed) return { ok: false, status: 500, error: failed };
    if (refusal) return { ok: false, status: 200, error: `The model declined: ${refusal}` };
    try {
      const parsed = JSON.parse(text) as { options: PromptOption[] };
      return { ok: true, options: (parsed.options ?? []).slice(0, 3) };
    } catch {
      return { ok: false, status: 500, error: "Could not read the AI response." };
    }
  });
