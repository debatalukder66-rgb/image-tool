const MAX_BYTES = 3 * 1024 * 1024;

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not read image"));
    img.src = src;
  });
}

const dataUriBytes = (uri: string) => Math.ceil(((uri.length - uri.indexOf(",") - 1) * 3) / 4);

/**
 * Resize to max 2048px and compress to < 3MB, returning a data URI.
 * JPEG/PNG/WebP are native; GIF/AVIF/HEIC are converted when the browser can decode them.
 */
export async function fileToDataUri(file: File | Blob): Promise<string> {
  const type = file.type || "";
  if (type && !type.startsWith("image/")) throw new Error(`Unsupported file type ${type} (use JPEG, PNG or WebP)`);
  const url = URL.createObjectURL(file);
  try {
    let img: HTMLImageElement;
    try {
      img = await loadImage(url);
    } catch {
      const label = type.replace("image/", "").toUpperCase() || "this file";
      throw new Error(`Your browser can't read ${label}. Convert it to JPEG, PNG or WebP and try again.`);
    }
    const scale = Math.min(1, 2048 / Math.max(img.width, img.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(img.width * scale);
    canvas.height = Math.round(img.height * scale);
    canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
    if (type === "image/png") {
      const png = canvas.toDataURL("image/png");
      if (dataUriBytes(png) < MAX_BYTES) return png;
    }
    const out = type === "image/webp" ? "image/webp" : "image/jpeg";
    for (const q of [0.9, 0.82, 0.72, 0.6, 0.5, 0.4]) {
      const d = canvas.toDataURL(out, q);
      if (dataUriBytes(d) < MAX_BYTES) return d;
    }
    throw new Error("Image too large even after compression (limit 3MB)");
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** Cross-page hand-off ("use as reference", "make video from this"). */
export const handoff = {
  set(key: "ref" | "videoStart" | "loadGen" | "edit", url: string) {
    sessionStorage.setItem(`handoff:${key}`, url);
  },
  take(key: "ref" | "videoStart" | "loadGen" | "edit") {
    const v = sessionStorage.getItem(`handoff:${key}`);
    sessionStorage.removeItem(`handoff:${key}`);
    return v;
  },
};
