import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/** UTC midnight today — the same boundary the server uses for the daily limit. */
export const utcDayStart = () => {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  return d;
};

export function useSpendLimit() {
  return useQuery({
    queryKey: ["library", "spend-limit"],
    refetchInterval: 30000,
    queryFn: async () => {
      const [{ data: settings }, { data: today }] = await Promise.all([
        supabase.from("app_settings").select("daily_credit_limit").maybeSingle(),
        supabase.from("generations").select("credits_estimated").gte("created_at", utcDayStart().toISOString()),
      ]);
      const used = (today ?? []).reduce((n, r) => n + (Number(r.credits_estimated) || 0), 0);
      const limit = settings?.daily_credit_limit != null ? Number(settings.daily_credit_limit) : null;
      return { used, limit };
    },
  });
}
