import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { appErrorText, assertAllowed, dbErrorText, extFor, redact, runwayErrorText, runwayFetch } from "./runway.server";

export const FINAL = ["SUCCEEDED", "FAILED", "CANCELLED"];

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type Attempt = { endpoint: string; request: any; status: number; response: any };

const createInput = z.object({
  kind: z.enum(["image", "video", "audio", "tool"]),
  endpoint: z.string().regex(/^[a-z0-9_]+(\/[a-z0-9_]+)*$/i),
  body: z.record(z.string(), z.any()),
  count: z.number().int().min(1).max(4).optional(),
  credits_estimated: z.number().nullable().optional(),
});

export const runwayCreate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => createInput.parse(d))
  .handler(async ({ data, context }) => {
    assertAllowed(context.claims);
    const attempts: Attempt[] = [];

    // Daily spend limit (server-side): today's estimated credits + this request must stay within the limit.
    const { data: settings } = await context.supabase.from("app_settings").select("daily_credit_limit").eq("user_id", context.userId).maybeSingle();
    const limit = settings?.daily_credit_limit != null ? Number(settings.daily_credit_limit) : null;
    if (limit != null && limit > 0) {
      const start = new Date();
      start.setUTCHours(0, 0, 0, 0);
      const { data: today } = await context.supabase.from("generations").select("credits_estimated").eq("user_id", context.userId).gte("created_at", start.toISOString());
      const used = (today ?? []).reduce((n, r) => n + (Number(r.credits_estimated) || 0), 0);
      const next = Number(data.credits_estimated) || 0;
      if (used + next > limit) {
        return {
          ok: false as const,
          attempts,
          error: appErrorText("SPEND_LIMIT", `Daily spend limit reached: ${used} of ${limit} credits used today (UTC), this request needs about ${next}.`, "Raise the limit on the Usage page or try tomorrow."),
        };
      }
    }
    const path = `/${data.endpoint}`;
    const send = async (body: Record<string, unknown>) => {
      const r = await runwayFetch(path, { method: "POST", body });
      attempts.push({ endpoint: path, request: redact(body), status: r.status, response: r.body });
      return r;
    };

    let taskIds: string[] = [];
    const first = await send(data.body);
    if (first.ok) {
      taskIds = [(first.body as { id: string }).id];
    } else if (data.body["outputCount"] && (data.count ?? 1) > 1 && first.status >= 400 && first.status < 500) {
      // Fallback: model rejected outputCount → N parallel tasks.
      const { outputCount: _drop, ...rest } = data.body;
      const n = data.count ?? Number(data.body["outputCount"]);
      const results = await Promise.all(Array.from({ length: n }, () => send(rest)));
      taskIds = results.filter((r) => r.ok).map((r) => (r.body as { id: string }).id);
    }

    if (taskIds.length === 0) {
      const last = attempts[attempts.length - 1]!;
      return {
        ok: false as const,
        attempts,
        error: runwayErrorText(last.status, last.response),
      };
    }

    const { data: row, error } = await context.supabase
      .from("generations")
      .insert({
        user_id: context.userId,
        kind: data.kind,
        model: (data.body["model"] as string) ?? null,
        endpoint: data.endpoint,
        params: redact({ endpoint: data.endpoint, body: data.body, count: data.count ?? 1 }),
        runway_task_ids: taskIds,
        status: "PENDING",
        credits_estimated: data.credits_estimated ?? null,
      })
      .select("id")
      .single();
    if (error) return { ok: false as const, attempts, error: dbErrorText("Saving the generation failed", error.message) };
    return { ok: true as const, attempts, generation_id: row.id, task_ids: taskIds };
  });

type TaskEntry = {
  status: string;
  progress?: number | undefined;
  failure?: string | undefined;
  failureCode?: string | undefined;
  saved?: boolean;
  paths?: string[];
  error?: string;
};

export const runwayStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ generation_id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    assertAllowed(context.claims);
    const { data: row, error } = await context.supabase
      .from("generations")
      .select("*")
      .eq("id", data.generation_id)
      .single();
    if (error || !row) throw new Error(error ? dbErrorText("Generation not found", error.message) : appErrorText("NOT_FOUND", "Generation not found.", "It may have been deleted."));

    const ts = { ...((row.task_statuses as Record<string, TaskEntry>) ?? {}) };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const raw: { task_id: string; status: number; response: any }[] = [];

    for (const id of row.runway_task_ids) {
      const prev = ts[id];
      if (prev && FINAL.includes(prev.status) && (prev.status !== "SUCCEEDED" || prev.saved)) continue;
      const r = await runwayFetch(`/tasks/${id}`);
      raw.push({ task_id: id, status: r.status, response: r.body });
      if (!r.ok) {
        const gone = r.status === 404 ? " — task no longer exists at Runway (expired), can't be recovered" : "";
        ts[id] = { ...(prev ?? {}), status: prev?.status ?? "PENDING", error: `Runway ${r.status}: ${JSON.stringify(r.body)}${gone}` };
        continue;
      }
      const t = r.body as { status: string; progress?: number; failure?: string; failureCode?: string; output?: string[] };
      const entry: TaskEntry = { status: t.status, progress: t.progress, failure: t.failure, failureCode: t.failureCode };
      if (t.status === "SUCCEEDED") {
        const paths: string[] = [];
        let failed: string | undefined;
        for (const [i, url] of (t.output ?? []).entries()) {
          try {
            const f = await fetch(url);
            if (!f.ok) {
              throw new Error(
                [403, 404, 410].includes(f.status)
                  ? `download ${f.status} — Runway output no longer available (outputs expire after 24–48h), can't be recovered`
                  : `download ${f.status}`,
              );
            }
            const ct = f.headers.get("content-type");
            const buf = await f.arrayBuffer();
            const path = `${context.userId}/${row.id}/${id}_${i}.${extFor(ct, url)}`;
            const up = await context.supabase.storage
              .from("generations")
              .upload(path, buf, { contentType: ct ?? "application/octet-stream", upsert: true });
            if (up.error) throw new Error(`upload: ${up.error.message}`);
            paths.push(path);
          } catch (e) {
            failed = `Saving output ${i} failed: ${(e as Error).message}`;
          }
        }
        entry.saved = !failed;
        entry.paths = paths;
        if (failed) entry.error = failed;
      }
      ts[id] = entry;
    }

    const entries = row.runway_task_ids.map((id) => ts[id]).filter(Boolean) as TaskEntry[];
    const statuses = entries.map((e) => e.status);
    const allFinal =
      entries.length === row.runway_task_ids.length &&
      entries.every((e) => FINAL.includes(e.status) && (e.status !== "SUCCEEDED" || e.saved));
    let status: string;
    if (allFinal) {
      status = statuses.includes("SUCCEEDED") ? "SUCCEEDED" : statuses.includes("FAILED") ? "FAILED" : "CANCELLED";
    } else if (statuses.includes("RUNNING")) status = "RUNNING";
    else if (statuses.includes("THROTTLED")) status = "THROTTLED";
    else status = "PENDING";

    const errors = entries
      .map((e) => e.error ?? (e.failure ? `${e.failureCode ?? "FAILED"}: ${e.failure}` : null))
      .filter(Boolean);
    const output_paths = row.runway_task_ids.flatMap((id) => ts[id]?.paths ?? []);

    const { data: updated, error: upErr } = await context.supabase
      .from("generations")
      .update({ task_statuses: ts as never, status, output_paths, error: errors.length ? errors.join("\n") : null })
      .eq("id", row.id)
      .select("*")
      .single();
    if (upErr) throw new Error(dbErrorText("Updating the generation failed", upErr.message));
    const progress = entries.length ? entries.reduce((a, e) => a + (e.progress ?? 0), 0) / row.runway_task_ids.length : 0;
    return { generation: updated, raw, progress };
  });

export const runwayBalance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    assertAllowed(context.claims);
    return runwayFetch("/organization");
  });

export const runwayVoices = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    assertAllowed(context.claims);
    return runwayFetch("/voices");
  });

export const deleteGeneration = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    assertAllowed(context.claims);
    const { data: row } = await context.supabase.from("generations").select("output_paths").eq("id", data.id).single();
    if (row?.output_paths?.length) await context.supabase.storage.from("generations").remove(row.output_paths);
    const { error } = await context.supabase.from("generations").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Public: sends a password setup/reset link, but only ever to ALLOWED_EMAIL. */
export const sendSetupLink = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ email: z.string().email().max(255), redirectTo: z.string().url() }).parse(d))
  .handler(async ({ data }) => {
    const allowed = process.env["ALLOWED_EMAIL"]?.trim().toLowerCase();
    // Same response either way so the allowed address isn't revealed.
    const generic = { ok: true, message: "If this email is allowed, a link has been sent." };
    if (!allowed || data.email.trim().toLowerCase() !== allowed) return generic;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const created = await supabaseAdmin.auth.admin.createUser({
      email: allowed,
      email_confirm: true,
      password: crypto.randomUUID() + crypto.randomUUID(),
    });
    if (created.error && !/already/i.test(created.error.message)) {
      console.error("createUser failed", created.error.message);
    }
    const { error } = await supabaseAdmin.auth.resetPasswordForEmail(allowed, { redirectTo: data.redirectTo });
    if (error) console.error("reset email failed", error.message);
    return generic;
  });

/** Public: whether the one-time "Create admin account" button should show. */
export const getSetupStatus = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin.from("app_setup").select("admin_created").eq("id", 1).maybeSingle();
  return { needsSetup: !data?.admin_created };
});

/** Public, one-time: creates (or sets the password of) the ALLOWED_EMAIL account, then locks itself. */
export const createAdminAccount = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ email: z.string().email().max(255), password: z.string().min(8).max(72) }).parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: setup } = await supabaseAdmin.from("app_setup").select("admin_created").eq("id", 1).maybeSingle();
    if (setup?.admin_created) return { ok: false, error: "Admin account already created." };
    const allowed = process.env["ALLOWED_EMAIL"]?.trim().toLowerCase();
    const email = data.email.trim().toLowerCase();
    if (!allowed || email !== allowed) return { ok: false, error: "This email is not allowed." };

    // Lock first so two simultaneous requests can't both succeed.
    const { data: locked } = await supabaseAdmin
      .from("app_setup").update({ admin_created: true }).eq("id", 1).eq("admin_created", false).select("id");
    if (!locked?.length) return { ok: false, error: "Admin account already created." };

    const created = await supabaseAdmin.auth.admin.createUser({ email, password: data.password, email_confirm: true });
    let err = created.error?.message;
    if (created.error && /already/i.test(created.error.message)) {
      const { data: list } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 200 });
      const user = list?.users.find((u) => u.email?.toLowerCase() === email);
      if (user) {
        const upd = await supabaseAdmin.auth.admin.updateUserById(user.id, { password: data.password, email_confirm: true });
        err = upd.error?.message;
      }
    }
    if (err) {
      await supabaseAdmin.from("app_setup").update({ admin_created: false }).eq("id", 1);
      return { ok: false, error: err };
    }
    return { ok: true, error: null };
  });

/**
 * Repair: for each of the user's rows, check that every output file really exists in storage.
 * Rows with missing/empty outputs get their task "saved" flags cleared so the next runwayStatus
 * call re-downloads from Runway (works only while Runway still has the files).
 */
export const prepareRepair = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    assertAllowed(context.claims);
    const { data: rows, error } = await context.supabase
      .from("generations")
      .select("id, status, runway_task_ids, output_paths, task_statuses")
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    const report: { id: string; action: string }[] = [];
    for (const row of rows ?? []) {
      if (!row.runway_task_ids.length) continue;
      const { data: files, error: lErr } = await context.supabase.storage
        .from("generations")
        .list(`${context.userId}/${row.id}`, { limit: 100 });
      if (lErr) { report.push({ id: row.id, action: `storage list failed: ${lErr.message}` }); continue; }
      const names = new Set((files ?? []).map((f) => `${context.userId}/${row.id}/${f.name}`));
      const missing = row.output_paths.filter((p) => !names.has(p));
      const needs = row.status !== "FAILED" && row.status !== "CANCELLED" && (missing.length > 0 || row.output_paths.length === 0);
      if (!needs) continue;
      const ts = { ...((row.task_statuses as Record<string, TaskEntry>) ?? {}) };
      for (const k of Object.keys(ts)) if (ts[k]) ts[k] = { ...ts[k]!, saved: false, paths: [] };
      const { error: uErr } = await context.supabase
        .from("generations")
        .update({ task_statuses: ts as never, output_paths: row.output_paths.filter((p) => names.has(p)), status: "RUNNING" })
        .eq("id", row.id);
      report.push({ id: row.id, action: uErr ? `reset failed: ${uErr.message}` : `missing ${missing.length || "all"} file(s) — re-fetching` });
    }
    return { report };
  });
