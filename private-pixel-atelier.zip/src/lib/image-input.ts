/** Browser-only helpers for the universal image input (drop, paste, URL import). */
export const INTERNAL_IMAGE_TYPE = "application/x-studio-image";
export const REORDER_TYPE = "application/x-studio-reorder";

export const BLOCKED_MSG =
  "This site blocks direct import. Right-click the image, choose Copy image, then paste here with Ctrl+V, or save it and drop the file.";

export type Source =
  | { kind: "file"; file: File }
  | { kind: "url"; url: string }
  | { kind: "internal"; url: string };

export const isImageUrl = (s: string) =>
  /^https?:\/\/\S+$/i.test(s.trim()) && (/\.(jpe?g|png|webp|gif|avif)(\?\S*)?$/i.test(s.trim()) || s.trim().startsWith("https://"));

/** Mark an <img> as draggable into any image input. */
export function dragImageProps(url: string | null | undefined) {
  if (!url) return {};
  return {
    draggable: true,
    onDragStart: (e: React.DragEvent) => {
      e.dataTransfer.setData(INTERNAL_IMAGE_TYPE, url);
      e.dataTransfer.setData("text/uri-list", url);
      e.dataTransfer.effectAllowed = "copy";
    },
  };
}

export const hasDroppable = (dt: DataTransfer | null) =>
  !!dt && !dt.types.includes(REORDER_TYPE) &&
  (dt.types.includes("Files") || dt.types.includes(INTERNAL_IMAGE_TYPE) || dt.types.includes("text/uri-list") || dt.types.includes("text/html"));

/** Files first, then in-app images, then uri-list / <img src>. */
export function sourcesFromDataTransfer(dt: DataTransfer): Source[] {
  const files = Array.from(dt.files ?? []);
  if (files.length) return files.map((file) => ({ kind: "file", file }));
  const internal = dt.getData(INTERNAL_IMAGE_TYPE);
  if (internal) return [{ kind: "internal", url: internal }];
  const uris = (dt.getData("text/uri-list") || "").split(/\r?\n/).filter((l) => l && !l.startsWith("#"));
  const html = dt.getData("text/html");
  const fromHtml = html ? new DOMParser().parseFromString(html, "text/html").querySelector("img")?.getAttribute("src") : null;
  const url = fromHtml || uris[0];
  return url ? [{ kind: "url", url }] : [];
}

/** Fetch a remote image as a Blob; throws BLOCKED_MSG on CORS/hotlink failure. */
export async function urlToBlob(url: string): Promise<Blob> {
  if (url.startsWith("data:")) return (await fetch(url)).blob();
  let res: Response;
  try {
    res = await fetch(url, { mode: "cors", credentials: "omit" });
  } catch {
    throw new Error(BLOCKED_MSG);
  }
  if (!res.ok) throw new Error(`${BLOCKED_MSG} (HTTP ${res.status})`);
  const blob = await res.blob();
  if (!blob.type.startsWith("image/")) throw new Error("That link is not an image.");
  return blob;
}

export const nameFromUrl = (url: string) => {
  try {
    return decodeURIComponent(new URL(url).pathname.split("/").pop() || "image");
  } catch {
    return "image";
  }
};

export function slugTag(name: string) {
  return name.replace(/\.[a-z0-9]+$/i, "").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 16);
}
