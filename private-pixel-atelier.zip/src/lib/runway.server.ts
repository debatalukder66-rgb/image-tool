const BASE = "https://api.dev.runwayml.com/v1";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type RunwayResult = { ok: boolean; status: number; body: any };

export async function runwayFetch(path: string, init?: { method?: string; body?: unknown }): Promise<RunwayResult> {
  const key = process.env["RUNWAYML_API_SECRET"];
  if (!key) return { ok: false, status: 0, body: { error: "RUNWAYML_API_SECRET secret is not set" } };
  try {
    const res = await fetch(BASE + path, {
      method: init?.method ?? "GET",
      headers: {
        Authorization: `Bearer ${key}`,
        "X-Runway-Version": "2024-11-06",
        "Content-Type": "application/json",
      },
      body: init?.body !== undefined ? JSON.stringify(init.body) : null,
    });
    const text = await res.text();
    let body: any = text; // eslint-disable-line @typescript-eslint/no-explicit-any
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      /* keep raw text */
    }
    return { ok: res.ok, status: res.status, body };
  } catch (e) {
    return { ok: false, status: 0, body: { error: `Network error: ${(e as Error).message}` } };
  }
}

export type AppErrorInfo = { code: string; message: string; hint: string };

/** Structured error text: JSON {error:{code,message,hint}}; the UI's ErrorBox renders it. */
export function appErrorText(code: string, message: string, hint: string) {
  return JSON.stringify({ error: { code, message, hint } satisfies AppErrorInfo });
}
export function appError(code: string, message: string, hint: string) {
  return new Error(appErrorText(code, message, hint));
}
export const SECRET_WHERE = "your host's secrets (Cloudflare: Worker → Settings → Variables and Secrets), then redeploy";
export function missingSecret(name: string) {
  return appErrorText("MISSING_SECRET", `Server secret ${name} is not set.`, `Add secret ${name} in ${SECRET_WHERE}.`);
}

/** Runway failure → structured error text. */
export function runwayErrorText(status: number, body: unknown) {
  const b = body as { error?: unknown; message?: unknown } | null;
  if (status === 0 && typeof b?.error === "string" && b.error.includes("RUNWAYML_API_SECRET")) return missingSecret("RUNWAYML_API_SECRET");
  const msg = typeof body === "string" ? body : typeof b?.error === "string" ? b.error : typeof b?.message === "string" ? b.message : JSON.stringify(body);
  const hint =
    status === 401 ? "The Runway key is wrong or revoked. Replace RUNWAYML_API_SECRET with a valid Dev API key."
    : status === 0 ? "The server could not reach Runway. Try again; check the host's network."
    : status === 429 ? "Runway is rate limiting. Wait a moment and try again."
    : "See the raw Runway response in the details.";
  return appErrorText("RUNWAY_ERROR", `Runway ${status}: ${msg}`, hint);
}

/** DB error → MISSING_TABLE when the table isn't there, else DB_ERROR. */
export function dbErrorText(what: string, message: string) {
  if (/does not exist|schema cache|relation/i.test(message))
    return appErrorText("MISSING_TABLE", `${what}: ${message}`, "Run SETUP.sql in your Supabase SQL Editor, then Run again in Setup Check.");
  return appErrorText("DB_ERROR", `${what}: ${message}`, "Open Setup Check to see which part of the setup fails.");
}

export function assertAllowed(claims: { email?: string } | Record<string, unknown>) {
  const allowed = process.env["ALLOWED_EMAIL"]?.trim().toLowerCase();
  // Fail closed: no ALLOWED_EMAIL means nobody is allowed.
  if (!allowed) throw new Error(missingSecret("ALLOWED_EMAIL"));
  const email = String((claims as { email?: string }).email ?? "").toLowerCase();
  if (email !== allowed)
    throw appError("NOT_ALLOWED_USER", "This account is not allowed to use the studio.", "Sign in with the email set in ALLOWED_EMAIL, or change that secret.");
}

/** Replace long data URIs with a short marker so logs / DB rows stay small. */
export function redact<T>(value: T): T {
  if (typeof value === "string") {
    return (value.startsWith("data:") && value.length > 200
      ? `${value.slice(0, 40)}…(${value.length} chars)`
      : value) as T;
  }
  if (Array.isArray(value)) return value.map(redact) as T;
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, redact(v)])) as T;
  }
  return value;
}

export function extFor(contentType: string | null, url: string) {
  const map: Record<string, string> = {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/webp": "webp",
    "video/mp4": "mp4",
    "video/webm": "webm",
    "audio/mpeg": "mp3",
    "audio/mp3": "mp3",
    "audio/wav": "wav",
    "audio/x-wav": "wav",
  };
  const ct = (contentType ?? "").split(";")[0]!.trim();
  if (map[ct]) return map[ct]!;
  const m = new URL(url).pathname.match(/\.([a-z0-9]{2,5})$/i);
  return m ? m[1]!.toLowerCase() : "bin";
}
