import { useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { FINAL, runwayStatus } from "./runway.functions";

const MAX_FAILURES = 3;

/** Polls every 3s; stops and surfaces the error after 3 consecutive failures. */
export function useGenerationPoll(id: string | null) {
  const fn = useServerFn(runwayStatus);
  const fails = useRef(0);
  const stopped = useRef(false);
  return useQuery({
    queryKey: ["generation", id],
    queryFn: async () => {
      try {
        const res = await fn({ data: { generation_id: id! } });
        // A poll where every Runway check failed counts as a failure too.
        const allFailed = res.raw.length > 0 && res.raw.every((r) => r.status < 200 || r.status >= 300);
        if (allFailed && !FINAL.includes(res.generation.status)) {
          fails.current += 1;
          if (fails.current >= MAX_FAILURES) {
            stopped.current = true;
            throw new Error(`Stopped after ${MAX_FAILURES} failed checks. ${res.generation.error ?? ""}`.trim());
          }
        } else fails.current = 0;
        stopped.current = false;
        return res;
      } catch (e) {
        if (!stopped.current) fails.current += 1;
        if (fails.current >= MAX_FAILURES) stopped.current = true;
        throw e;
      }
    },
    enabled: !!id,
    retry: false,
    refetchInterval: (q) =>
      stopped.current || (q.state.data && FINAL.includes(q.state.data.generation.status)) ? false : 3000,
  });
}

export function useSignedUrls(paths: string[] | null | undefined) {
  const key = (paths ?? []).join("|");
  return useQuery({
    queryKey: ["signed", key],
    enabled: !!paths?.length,
    staleTime: 50 * 60 * 1000,
    queryFn: async () => {
      const { data, error } = await supabase.storage.from("generations").createSignedUrls(paths!, 3600);
      if (error) throw error;
      return Object.fromEntries(data.map((d) => [d.path ?? "", d.signedUrl]));
    },
  });
}
