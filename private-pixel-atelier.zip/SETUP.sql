-- SETUP.sql — full schema for this app. Paste into Supabase → SQL Editor → Run (safe to re-run).

-- 1. generations
CREATE TABLE IF NOT EXISTS public.generations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  kind text NOT NULL,
  model text,
  endpoint text,
  params jsonb NOT NULL DEFAULT '{}'::jsonb,
  runway_task_ids text[] NOT NULL DEFAULT '{}',
  task_statuses jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'PENDING',
  output_paths text[] NOT NULL DEFAULT '{}',
  credits_estimated numeric,
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  favorite boolean NOT NULL DEFAULT false,
  deleted_at timestamptz,
  project_id uuid
);
ALTER TABLE public.generations ADD COLUMN IF NOT EXISTS favorite boolean NOT NULL DEFAULT false;
ALTER TABLE public.generations ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE public.generations ADD COLUMN IF NOT EXISTS project_id uuid;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.generations TO authenticated;
GRANT ALL ON public.generations TO service_role;
ALTER TABLE public.generations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own generations" ON public.generations;
CREATE POLICY "own generations" ON public.generations FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS generations_user_created ON public.generations (user_id, created_at DESC);

-- 2. app_setup (one row; server-only, no policies on purpose)
CREATE TABLE IF NOT EXISTS public.app_setup (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  admin_created boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.app_setup TO service_role;
ALTER TABLE public.app_setup ENABLE ROW LEVEL SECURITY;
INSERT INTO public.app_setup (id, admin_created) VALUES (1, false) ON CONFLICT (id) DO NOTHING;

-- 3. model_checks
CREATE TABLE IF NOT EXISTS public.model_checks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  model text NOT NULL,
  status text NOT NULL,
  ratio text,
  quality text,
  duration_ms integer,
  credits_estimated numeric,
  generation_id uuid,
  thumbnail_path text,
  error text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.model_checks TO authenticated;
GRANT ALL ON public.model_checks TO service_role;
ALTER TABLE public.model_checks ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own model checks" ON public.model_checks;
CREATE POLICY "own model checks" ON public.model_checks FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS model_checks_user_model ON public.model_checks (user_id, model, created_at DESC);

-- 4. model_config
CREATE TABLE IF NOT EXISTS public.model_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  model text NOT NULL,
  ratios text[] NOT NULL DEFAULT '{}',
  quality text,
  size text,
  max_outputs integer,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, model)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.model_config TO authenticated;
GRANT ALL ON public.model_config TO service_role;
ALTER TABLE public.model_config ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own model config" ON public.model_config;
CREATE POLICY "own model config" ON public.model_config FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
-- 5. projects, saved_prompts, style_presets, app_settings
CREATE TABLE IF NOT EXISTS public.projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  name text NOT NULL,
  color text NOT NULL DEFAULT '#71717a',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.projects TO authenticated;
GRANT ALL ON public.projects TO service_role;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own projects" ON public.projects;
CREATE POLICY "own projects" ON public.projects FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS public.saved_prompts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  title text NOT NULL,
  prompt text NOT NULL,
  model text,
  settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.saved_prompts TO authenticated;
GRANT ALL ON public.saved_prompts TO service_role;
ALTER TABLE public.saved_prompts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own saved prompts" ON public.saved_prompts;
CREATE POLICY "own saved prompts" ON public.saved_prompts FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS public.style_presets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  name text NOT NULL,
  phrase text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.style_presets TO authenticated;
GRANT ALL ON public.style_presets TO service_role;
ALTER TABLE public.style_presets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own style presets" ON public.style_presets;
CREATE POLICY "own style presets" ON public.style_presets FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS public.app_settings (
  user_id uuid PRIMARY KEY DEFAULT auth.uid(),
  daily_credit_limit numeric,
  default_image_model text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.app_settings TO authenticated;
GRANT ALL ON public.app_settings TO service_role;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own app settings" ON public.app_settings;
CREATE POLICY "own app settings" ON public.app_settings FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS generations_user_created_idx ON public.generations (user_id, created_at DESC);
-- 6. Storage: private "generations" bucket, files under <user_id>/...
INSERT INTO storage.buckets (id, name, public) VALUES ('generations', 'generations', false)
ON CONFLICT (id) DO NOTHING;
DROP POLICY IF EXISTS "own files read" ON storage.objects;
CREATE POLICY "own files read" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'generations' AND (storage.foldername(name))[1] = auth.uid()::text);
DROP POLICY IF EXISTS "own files insert" ON storage.objects;
CREATE POLICY "own files insert" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'generations' AND (storage.foldername(name))[1] = auth.uid()::text);
DROP POLICY IF EXISTS "own files delete" ON storage.objects;
CREATE POLICY "own files delete" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'generations' AND (storage.foldername(name))[1] = auth.uid()::text);

-- No database functions or triggers are used by this app.
