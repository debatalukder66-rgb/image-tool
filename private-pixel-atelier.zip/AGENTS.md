<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- All Runway calls go through server functions in `src/lib/runway.functions.ts` (auth + ALLOWED_EMAIL check on every call); the Runway key never reaches the browser.
- Runway outputs are copied into the private `generations` storage bucket under `<user_id>/<generation_id>/`; the UI only shows signed URLs from our storage, because Runway URLs expire.
- Public signups are disabled; the only account is created via the email-gated setup link (`sendSetupLink`), so only the inbox owner can set the password.
- Runway errors are returned as data (status + raw body), never swallowed, so the UI and Test Console can show them.
- The Library finalizes any non-final generation on load (calls runwayStatus per row), so closing a tab mid-poll never leaves rows stuck.
- Model Check runs image models sequentially from the browser through the same runwayCreate/runwayStatus path as the Image tab; results go to `model_checks`, proven settings to `model_config` (opt-in for the Image tab via localStorage flag).

- Generation browsing uses the shared list+detail `Workspace` component (Image and Library pages); favorites, Trash (`deleted_at`, purged after 30 days on load) and projects are columns on `generations`.
- All image inputs (drop, paste, URL, in-app drag, file picker) go through the shared `useImageInput` + `ImageTray`/`GlobalDropOverlay` in `src/components/studio/ImageInput.tsx`; images stay in the browser until Generate.
- The daily spend limit is enforced inside `runwayCreate` (UTC day, sum of `credits_estimated`) before any Runway call; the UI banner only warns.
- Compare runs reuse runwayCreate/runwayStatus; results not kept are moved to Trash when the dialog closes.
- Prompt Lab geometry follows the browser visual viewport, including resize and scroll events, and avoids automatic input focus on touch devices so the keyboard cannot hide the composer.
- External hosting targets Cloudflare Workers via root wrangler.jsonc (nitro cloudflare-module output in .output/); migration/sql holds migrations Lovable can't place in supabase/migrations — keep it in sync with drizzle/migrations.

- Server-function errors use structured text {error:{code,message,hint}} (helpers in runway.server.ts), parsed by ErrorBox; `healthCheck` in setup.functions.ts powers /setup-check and the app-start banner — keeps deployment problems self-diagnosing.
