-- Private "generations" bucket (was created through the UI). Policies live in 20261006205645_*.sql.
INSERT INTO storage.buckets (id, name, public) VALUES ('generations', 'generations', false)
ON CONFLICT (id) DO NOTHING;
