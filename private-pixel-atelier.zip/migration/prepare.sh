#!/usr/bin/env sh
# Copies the extra migrations into supabase/migrations so `supabase db push` builds the full schema.
set -e
cd "$(dirname "$0")/.."
cp migration/sql/*.sql supabase/migrations/
ls supabase/migrations
