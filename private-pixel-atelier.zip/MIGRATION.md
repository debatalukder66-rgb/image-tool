# Migrating to your own Supabase project + external host

## What this app is
A **TanStack Start** full-stack app (SSR + server functions), not a static React + Vite SPA.
It needs a server runtime. There are **no Supabase Edge Functions**: all backend logic
(Runway calls, Enhance prompt, admin setup) runs as server functions inside the deployed app.
Each server function checks the signed-in user (`requireSupabaseAuth`) and `ALLOWED_EMAIL`
(`assertAllowed`) itself; the three public ones (`sendSetupLink`, `getSetupStatus`,
`createAdminAccount`) only ever act on `ALLOWED_EMAIL`.

| Host | Free tier | Works? |
|---|---|---|
| **Cloudflare Workers** (recommended) | yes | Yes, default build target; `wrangler.jsonc` included |
| Netlify | yes | Yes, build with `NITRO_PRESET=netlify` |
| Vercel | yes (Hobby) | Yes, build with `NITRO_PRESET=vercel` |

## 1. Supabase project
```bash
npm i -g supabase
supabase login
supabase link --project-ref <YOUR_REF>    # replaces the project_id in supabase/config.toml locally
./migration/prepare.sh                     # copies migration/sql/*.sql into supabase/migrations
supabase db push                           # applies the full schema
```
After `prepare.sh`, `supabase/migrations` contains the full schema: generations, app_setup (+ seed row), model_checks,
model_config, projects, saved_prompts, style_presets, app_settings, all RLS policies, indexes,
the private `generations` bucket and its storage policies (owner folder `<user_id>/...`).
Lovable locks `supabase/migrations`, so the two newer files (studio features, bucket) live in
`migration/sql/`. `drizzle/migrations` is Lovable's copy; ignore it.
`supabase/config.toml` still names the old project id (Lovable-managed); `supabase link` overrides it.

No edge functions to deploy, so `supabase/config.toml` has no `[functions.*]` entries.

### Auth settings (Dashboard → Authentication)
- Sign In / Providers → **Allow new users to sign up: OFF**. Email provider ON. Confirm email ON.
- URL Configuration → Site URL: `https://<your-domain>`; Redirect URLs: `https://<your-domain>/reset-password`.
- First login: open `/auth`, use "Create admin account" (one-time) or "Send setup link" with ALLOWED_EMAIL.

### Data (optional)
Export/import table rows with `pg_dump --data-only -t public.*`; copy storage files separately
(the old bucket is private, download via the app's Download/zip).

## 2. Secrets (names only)
Server runtime (host secrets):
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SERVICE_ROLE_KEY` (Dashboard → Settings → API keys, secret key)
- `ALLOWED_EMAIL`
- `RUNWAYML_API_SECRET`
- `LOVABLE_API_KEY` (only for Enhance / Prompt helper, which calls the Lovable AI Gateway)

Build-time (public, browser): `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`.
See `.env.example`. Never commit a real `.env`.

## 3. Deploy — Cloudflare Workers (recommended)
```bash
npm ci
VITE_SUPABASE_URL=... VITE_SUPABASE_PUBLISHABLE_KEY=... npm run build
npx wrangler login
for s in SUPABASE_URL SUPABASE_PUBLISHABLE_KEY SUPABASE_SERVICE_ROLE_KEY ALLOWED_EMAIL RUNWAYML_API_SECRET LOVABLE_API_KEY; do npx wrangler secret put $s; done
npx wrangler deploy
```
Git-connected (Workers Builds): Build command `npm run build`, Deploy command `npx wrangler deploy`,
Node 20+, add the two `VITE_*` as build variables and the six above as secrets.

### Netlify
Build command `NITRO_PRESET=netlify npm run build`, publish dir `.output/public` (auto-detected).
Add all 8 variables in Site settings → Environment variables.

### Vercel
Framework preset "Other", Build command `NITRO_PRESET=vercel npm run build`, output auto-detected.
Add all 8 variables in Project → Settings → Environment Variables.

## 4. Verify with Setup Check
After deploying, sign in and open Tools → Setup Check (`/setup-check`). It calls the `healthCheck` server function (signed-in only; full report only when your email matches ALLOWED_EMAIL) and shows: frontend vs server Supabase host, each secret set/missing (never values), ALLOWED_EMAIL match, a Runway `/organization` test, table readability, the `generations` bucket, and the expected functions (no Edge Functions). Errors from all server functions are structured `{error:{code,message,hint}}` (MISSING_SECRET, NOT_ALLOWED_USER, RUNWAY_ERROR, MISSING_TABLE, DB_ERROR, SPEND_LIMIT) and the UI links to Setup Check.

## Schema history
- `0000_studio_features`: generations.favorite / deleted_at (Trash, purged after 30 days by the app) / project_id; projects, saved_prompts, style_presets, app_settings tables. Daily limit enforced in `runwayCreate` (UTC day).
- Earlier: generations, app_setup, model_checks, model_config, storage bucket `generations` (private).
