CREATE TABLE public.app_setup (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  admin_created boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.app_setup TO service_role;
ALTER TABLE public.app_setup ENABLE ROW LEVEL SECURITY;
INSERT INTO public.app_setup (id, admin_created) VALUES (1, false);