CREATE TABLE public.model_checks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  model text NOT NULL,
  status text NOT NULL,
  ratio text,
  quality text,
  duration_ms integer,
  credits_estimated numeric,
  generation_id uuid,
  thumbnail_path text,
  error text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.model_checks TO authenticated;
GRANT ALL ON public.model_checks TO service_role;
ALTER TABLE public.model_checks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own model checks" ON public.model_checks FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX model_checks_user_model ON public.model_checks(user_id, model, created_at DESC);

CREATE TABLE public.model_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  model text NOT NULL,
  ratios text[] NOT NULL DEFAULT '{}',
  quality text,
  size text,
  max_outputs integer,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, model)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.model_config TO authenticated;
GRANT ALL ON public.model_config TO service_role;
ALTER TABLE public.model_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own model config" ON public.model_config FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);