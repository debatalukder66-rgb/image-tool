# Prompt Lab page with the MorphOrb component

## Blocker
The uploaded brief does not contain the component itself. Before building, paste:
- `ai-thiking-orb-and-input.tsx`
- all of its CSS: every `.mo-*` rule, `@property --angle`, and the keyframes

Without these the build stops, as the brief says: no invented CSS.

## What gets built (once the code is provided)
1. Save the component as `src/components/ui/ai-thinking-orb-and-input.tsx`, without its `index.css` import.
2. Copy its CSS unchanged into the global stylesheet (`src/styles.css`, which this project uses instead of `index.css`), with no extra Tailwind imports.
3. Add optional props that are backward compatible: `copy`, `maxLength` (default 200), `statusLabel`, an `onSubmit` that returns a string or `{ card, detail }`, `onAnswered(detail)` and `onExit()`. Animation timings, geometry, canvas drawing, `?debug` and reduced-motion behavior stay unchanged.
4. A new full-screen `/prompt-lab` page: no icon rail or padding, and a small close button at the top right that goes back to Image. It is listed under Tools.
5. Submitting reuses the existing Enhance prompt helper (`enhancePrompt`), so there are no new keys or functions. It uses the first suggested prompt and shows "Prompt ready · N words" on the card.
6. When the answer appears, a panel fades in with the editable full prompt, Copy, Send to Image and Send to Video. Sending opens that tab with its prompt box filled. "New idea" hides the panel.
7. Errors show a message and the card text "Something went wrong".

## Technical details
- The prompt is passed between pages with the existing session hand-off (new `prompt` key), read once when the Image or Video page opens.
- The Prompt Lab page does not use AppShell, which keeps the window-height animation math correct.
- No changes to the database, server functions or other pages.
